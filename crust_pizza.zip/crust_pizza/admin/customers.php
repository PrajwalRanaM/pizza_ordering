<?php
// admin/customers.php - Customers Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$customer_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'edit') {
            // Edit customer data
            $edit_id = (int)($_POST['customer_id'] ?? 0);
            $username = sanitizeInput($_POST['username'] ?? '');
            $first_name = sanitizeInput($_POST['first_name'] ?? '');
            $last_name = sanitizeInput($_POST['last_name'] ?? '');
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $phone = sanitizeInput($_POST['phone'] ?? '');
            $address = sanitizeInput($_POST['address'] ?? '');
            $city = sanitizeInput($_POST['city'] ?? '');
            $state = $_POST['state'] ?? '';
            $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Validation
            $errors = [];
            if (empty($username)) $errors[] = 'Username is required.';
            if (empty($first_name)) $errors[] = 'First name is required.';
            if (empty($last_name)) $errors[] = 'Last name is required.';
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
            if (empty($phone)) $errors[] = 'Phone number is required.';
            
            // Check for duplicate username/email (excluding current customer)
            if (empty($errors)) {
                try {
                    $check_stmt = $conn->prepare("SELECT customer_id FROM customers WHERE (username = ? OR email = ?) AND customer_id != ?");
                    $check_stmt->bind_param("ssi", $username, $email, $edit_id);
                    $check_stmt->execute();
                    if ($check_stmt->get_result()->num_rows > 0) {
                        $errors[] = 'Username or email already exists.';
                    }
                } catch (Exception $e) {
                    $errors[] = 'Database error during validation.';
                }
            }
            
            if (empty($errors)) {
                try {
                    $stmt = $conn->prepare("
                        UPDATE customers 
                        SET username = ?, first_name = ?, last_name = ?, email = ?, phone = ?, 
                            address = ?, city = ?, state = ?, postal_code = ?, is_active = ?, updated_at = NOW()
                        WHERE customer_id = ?
                    ");
                    $stmt->bind_param("sssssssssii", $username, $first_name, $last_name, $email, $phone, 
                                    $address, $city, $state, $postal_code, $is_active, $edit_id);
                    
                    if ($stmt->execute()) {
                        $message = 'Customer updated successfully!';
                        $action = 'list';
                    } else {
                        $error = 'Failed to update customer. Please try again.';
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = implode('<br>', $errors);
            }
        } elseif ($form_action === 'toggle_status') {
            $toggle_id = (int)($_POST['customer_id'] ?? 0);
            $new_status = (int)($_POST['new_status'] ?? 0);
            
            if ($toggle_id > 0) {
                try {
                    $stmt = $conn->prepare("UPDATE customers SET is_active = ?, updated_at = NOW() WHERE customer_id = ?");
                    $stmt->bind_param("ii", $new_status, $toggle_id);
                    
                    if ($stmt->execute()) {
                        $message = 'Customer status updated successfully!';
                    } else {
                        $error = 'Failed to update customer status.';
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        } elseif ($form_action === 'reset_password') {
            $reset_id = (int)($_POST['customer_id'] ?? 0);
            $new_password = $_POST['new_password'] ?? '';
            
            if ($reset_id > 0 && !empty($new_password)) {
                $password_errors = validatePassword($new_password);
                if (empty($password_errors)) {
                    try {
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $stmt = $conn->prepare("UPDATE customers SET password = ?, updated_at = NOW() WHERE customer_id = ?");
                        $stmt->bind_param("si", $hashed_password, $reset_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Customer password reset successfully!';
                        } else {
                            $error = 'Failed to reset password.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                } else {
                    $error = implode('<br>', $password_errors);
                }
            } else {
                $error = 'Invalid data for password reset.';
            }
        }
    }
}

// Get customer data for editing/viewing
$customer_data = null;
$customer_orders = [];
if (($action === 'edit' || $action === 'view') && $customer_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM customers WHERE customer_id = ?");
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $customer_data = $stmt->get_result()->fetch_assoc();
        
        if ($customer_data) {
            // Get customer orders
            $orders_stmt = $conn->prepare("
                SELECT o.order_id, o.order_number, o.total_amount, o.created_at, o.order_type,
                       os.status_name, l.store_name
                FROM orders o
                JOIN order_statuses os ON o.order_status_id = os.status_id
                JOIN locations l ON o.location_id = l.location_id
                WHERE o.customer_id = ?
                ORDER BY o.created_at DESC
                LIMIT 10
            ");
            $orders_stmt->bind_param("i", $customer_id);
            $orders_stmt->execute();
            $customer_orders = $orders_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        } else {
            $error = 'Customer not found.';
            $action = 'list';
        }
    } catch (Exception $e) {
        $error = 'Failed to load customer data.';
        $action = 'list';
    }
}

// Get customers list with filters
$customers = [];
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$state_filter = $_GET['state'] ?? '';
$sort = $_GET['sort'] ?? 'created_at';
$order = $_GET['order'] ?? 'DESC';

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;
$total_customers = 0;

if ($action === 'list') {
    try {
        // Count total customers for pagination
        $count_sql = "SELECT COUNT(*) as total FROM customers WHERE 1=1";
        $count_params = [];
        $count_types = '';
        
        if (!empty($search)) {
            $count_sql .= " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ? OR phone LIKE ?)";
            $search_param = "%$search%";
            $count_params = array_fill(0, 5, $search_param);
            $count_types = str_repeat('s', 5);
        }
        
        if ($status_filter !== '') {
            $count_sql .= " AND is_active = ?";
            $count_params[] = (int)$status_filter;
            $count_types .= 'i';
        }
        
        if (!empty($state_filter)) {
            $count_sql .= " AND state = ?";
            $count_params[] = $state_filter;
            $count_types .= 's';
        }
        
        $count_stmt = $conn->prepare($count_sql);
        if (!empty($count_params)) {
            $count_stmt->bind_param($count_types, ...$count_params);
        }
        $count_stmt->execute();
        $total_customers = $count_stmt->get_result()->fetch_assoc()['total'];
        
        // Get customers with filters and pagination
        $sql = "
            SELECT c.*, 
                   (SELECT COUNT(*) FROM orders WHERE customer_id = c.customer_id) as order_count,
                   (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE customer_id = c.customer_id AND payment_status = 'completed') as total_spent
            FROM customers c
            WHERE 1=1
        ";
        
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ? OR c.username LIKE ? OR c.phone LIKE ?)";
            $search_param = "%$search%";
            $params = array_fill(0, 5, $search_param);
            $types = str_repeat('s', 5);
        }
        
        if ($status_filter !== '') {
            $sql .= " AND c.is_active = ?";
            $params[] = (int)$status_filter;
            $types .= 'i';
        }
        
        if (!empty($state_filter)) {
            $sql .= " AND c.state = ?";
            $params[] = $state_filter;
            $types .= 's';
        }
        
        // Add sorting
        $allowed_sorts = ['first_name', 'last_name', 'email', 'created_at', 'order_count', 'total_spent'];
        $allowed_orders = ['ASC', 'DESC'];
        
        if (in_array($sort, $allowed_sorts) && in_array($order, $allowed_orders)) {
            $sql .= " ORDER BY " . ($sort === 'order_count' || $sort === 'total_spent' ? $sort : "c.$sort") . " $order";
        } else {
            $sql .= " ORDER BY c.created_at DESC";
        }
        
        $sql .= " LIMIT ? OFFSET ?";
        $params[] = $per_page;
        $params[] = $offset;
        $types .= 'ii';
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $customers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
    } catch (Exception $e) {
        $error = 'Failed to load customers: ' . $e->getMessage();
    }
}

$total_pages = ceil($total_customers / $per_page);
$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/customers.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link active">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'view': echo 'Customer Details'; break;
                        case 'edit': echo 'Edit Customer'; break;
                        default: echo 'Customers Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Customers List View -->
                <div class="page-header">
                    <h2 class="page-title">Customers (<?php echo number_format($total_customers); ?>)</h2>
                </div>

                <!-- Stats Row -->
                <div class="stats-row">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo number_format($total_customers); ?></div>
                        <div class="stat-label">Total Customers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">
                            <?php 
                            $active_count = array_sum(array_column($customers, 'is_active'));
                            echo number_format($active_count);
                            ?>
                        </div>
                        <div class="stat-label">Active Customers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">
                            <?php 
                            $total_orders = array_sum(array_column($customers, 'order_count'));
                            echo number_format($total_orders);
                            ?>
                        </div>
                        <div class="stat-label">Total Orders</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">
                            <?php 
                            $total_revenue = array_sum(array_column($customers, 'total_spent'));
                            echo formatPrice($total_revenue);
                            ?>
                        </div>
                        <div class="stat-label">Total Revenue</div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Search customers..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">State</label>
                        <select class="form-select" id="stateFilter">
                            <option value="">All States</option>
                            <?php foreach (AU_STATES as $code => $name): ?>
                            <option value="<?php echo $code; ?>" <?php echo $state_filter === $code ? 'selected' : ''; ?>>
                                <?php echo e($name); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="customers.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Customers Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th class="sortable" onclick="sortTable('first_name')">
                                Name
                                <?php if ($sort === 'first_name'): ?>
                                    <span class="sort-indicator"><?php echo $order === 'ASC' ? '▲' : '▼'; ?></span>
                                <?php endif; ?>
                            </th>
                            <th class="sortable" onclick="sortTable('email')">
                                Email
                                <?php if ($sort === 'email'): ?>
                                    <span class="sort-indicator"><?php echo $order === 'ASC' ? '▲' : '▼'; ?></span>
                                <?php endif; ?>
                            </th>
                            <th>Phone</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th class="sortable" onclick="sortTable('order_count')">
                                Orders
                                <?php if ($sort === 'order_count'): ?>
                                    <span class="sort-indicator"><?php echo $order === 'ASC' ? '▲' : '▼'; ?></span>
                                <?php endif; ?>
                            </th>
                            <th class="sortable" onclick="sortTable('total_spent')">
                                Total Spent
                                <?php if ($sort === 'total_spent'): ?>
                                    <span class="sort-indicator"><?php echo $order === 'ASC' ? '▲' : '▼'; ?></span>
                                <?php endif; ?>
                            </th>
                            <th class="sortable" onclick="sortTable('created_at')">
                                Joined
                                <?php if ($sort === 'created_at'): ?>
                                    <span class="sort-indicator"><?php echo $order === 'ASC' ? '▲' : '▼'; ?></span>
                                <?php endif; ?>
                            </th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($customers)): ?>
                        <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?php echo $customer['customer_id']; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--admin-accent); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 14px;">
                                        <?php echo strtoupper(substr($customer['first_name'], 0, 1) . substr($customer['last_name'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <strong><?php echo e($customer['first_name'] . ' ' . $customer['last_name']); ?></strong>
                                        <br>
                                        <small style="color: #6c757d;">@<?php echo e($customer['username']); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($customer['email']); ?></td>
                            <td><?php echo e($customer['phone']); ?></td>
                            <td>
                                <?php echo e($customer['city']); ?>, <?php echo e($customer['state']); ?>
                                <br>
                                <small style="color: #6c757d;"><?php echo e($customer['postal_code']); ?></small>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $customer['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $customer['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <strong><?php echo number_format($customer['order_count']); ?></strong>
                                <?php if ($customer['order_count'] > 0): ?>
                                    <br><small style="color: #6c757d;">orders</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: var(--admin-success);"><?php echo formatPrice($customer['total_spent']); ?></strong>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($customer['created_at'])); ?></td>
                            <td>
                                <a href="customers.php?action=view&id=<?php echo $customer['customer_id']; ?>" 
                                   class="btn btn-primary btn-sm" title="View Details">👁️</a>
                                <a href="customers.php?action=edit&id=<?php echo $customer['customer_id']; ?>" 
                                   class="btn btn-warning btn-sm" title="Edit">✏️</a>
                                <button onclick="toggleStatus(<?php echo $customer['customer_id']; ?>, <?php echo $customer['is_active'] ? '0' : '1'; ?>)" 
                                        class="btn btn-<?php echo $customer['is_active'] ? 'danger' : 'success'; ?> btn-sm" 
                                        title="<?php echo $customer['is_active'] ? 'Deactivate' : 'Activate'; ?>">
                                    <?php echo $customer['is_active'] ? '🚫' : '✅'; ?>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="10" style="text-align: center; padding: 40px; color: #6c757d;">
                                No customers found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="<?php echo buildPaginationUrl($page - 1); ?>">&laquo; Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="<?php echo buildPaginationUrl($i); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="<?php echo buildPaginationUrl($page + 1); ?>">Next &raquo;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php elseif ($action === 'view'): ?>
                <!-- Customer Details View -->
                <div class="page-header">
                    <h2 class="page-title">Customer Details</h2>
                    <div>
                        <a href="customers.php?action=edit&id=<?php echo $customer_data['customer_id']; ?>" class="btn btn-warning">Edit Customer</a>
                        <a href="customers.php" class="btn btn-secondary">Back to Customers</a>
                    </div>
                </div>

                <div class="customer-details">
                    <div class="customer-header">
                        <div style="display: flex; align-items: center;">
                            <div class="customer-avatar">
                                <?php echo strtoupper(substr($customer_data['first_name'], 0, 1) . substr($customer_data['last_name'], 0, 1)); ?>
                            </div>
                            <div>
                                <h2 style="margin: 0; color: var(--admin-primary);">
                                    <?php echo e($customer_data['first_name'] . ' ' . $customer_data['last_name']); ?>
                                </h2>
                                <p style="margin: 5px 0; color: #6c757d;">@<?php echo e($customer_data['username']); ?></p>
                                <span class="status-badge status-<?php echo $customer_data['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $customer_data['is_active'] ? 'Active Account' : 'Inactive Account'; ?>
                                </span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <p style="margin: 0; color: #6c757d;">Customer since</p>
                            <p style="margin: 0; font-weight: 600; color: var(--admin-primary);">
                                <?php echo date('F j, Y', strtotime($customer_data['created_at'])); ?>
                            </p>
                        </div>
                    </div>

                    <div class="customer-info-grid">
                        <div class="info-group">
                            <div class="info-label">Email Address</div>
                            <div class="info-value"><?php echo e($customer_data['email']); ?></div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Phone Number</div>
                            <div class="info-value"><?php echo e($customer_data['phone']); ?></div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Address</div>
                            <div class="info-value">
                                <?php echo e($customer_data['address']); ?><br>
                                <?php echo e($customer_data['city']); ?>, <?php echo e($customer_data['state']); ?> <?php echo e($customer_data['postal_code']); ?>
                            </div>
                        </div>
                        <div class="info-group">
                            <div class="info-label">Account Status</div>
                            <div class="info-value">
                                <span class="status-badge status-<?php echo $customer_data['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $customer_data['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Statistics -->
                    <div class="stats-row">
                        <div class="stat-card">
                            <div class="stat-number"><?php echo count($customer_orders); ?></div>
                            <div class="stat-label">Total Orders</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-number">
                                <?php 
                                $total_spent = array_sum(array_column($customer_orders, 'total_amount'));
                                echo formatPrice($total_spent);
                                ?>
                            </div>
                            <div class="stat-label">Total Spent</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-number">
                                <?php 
                                if (!empty($customer_orders)) {
                                    echo formatPrice($total_spent / count($customer_orders));
                                } else {
                                    echo formatPrice(0);
                                }
                                ?>
                            </div>
                            <div class="stat-label">Average Order</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-number">
                                <?php 
                                if (!empty($customer_orders)) {
                                    $last_order = reset($customer_orders);
                                    $days_ago = (time() - strtotime($last_order['created_at'])) / (24 * 60 * 60);
                                    echo round($days_ago);
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </div>
                            <div class="stat-label"><?php echo !empty($customer_orders) ? 'Days Since Last Order' : 'No Orders'; ?></div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button onclick="resetPassword(<?php echo $customer_data['customer_id']; ?>)" class="btn btn-warning">
                            🔑 Reset Password
                        </button>
                        <button onclick="toggleStatus(<?php echo $customer_data['customer_id']; ?>, <?php echo $customer_data['is_active'] ? '0' : '1'; ?>)" 
                                class="btn btn-<?php echo $customer_data['is_active'] ? 'danger' : 'success'; ?>">
                            <?php echo $customer_data['is_active'] ? '🚫 Deactivate Account' : '✅ Activate Account'; ?>
                        </button>
                    </div>
                </div>

                <!-- Recent Orders -->
                <?php if (!empty($customer_orders)): ?>
                <div class="orders-section">
                    <h3 class="section-title">Recent Orders</h3>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Location</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($customer_orders as $order): ?>
                            <tr>
                                <td><strong><?php echo e($order['order_number']); ?></strong></td>
                                <td><?php echo date('M j, Y H:i', strtotime($order['created_at'])); ?></td>
                                <td><?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?></td>
                                <td><?php echo e($order['store_name']); ?></td>
                                <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                <td>
                                    <span class="status-badge">
                                        <?php echo e($order['status_name']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="order-details.php?id=<?php echo $order['order_id']; ?>" 
                                       class="btn btn-primary btn-sm">View Order</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>

                <?php elseif ($action === 'edit'): ?>
                <!-- Edit Customer Form -->
                <div class="page-header">
                    <h2 class="page-title">Edit Customer</h2>
                    <div>
                        <a href="customers.php?action=view&id=<?php echo $customer_data['customer_id']; ?>" class="btn btn-primary">View Details</a>
                        <a href="customers.php" class="btn btn-secondary">Back to Customers</a>
                    </div>
                </div>

                <div class="form-container">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="customer_id" value="<?php echo $customer_id; ?>">

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="form-input" required
                                       value="<?php echo e($customer_data['username']); ?>"
                                       placeholder="Enter username">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email Address *</label>
                                <input type="email" name="email" class="form-input" required
                                       value="<?php echo e($customer_data['email']); ?>"
                                       placeholder="Enter email address">
                            </div>

                            <div class="form-group">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="first_name" class="form-input" required
                                       value="<?php echo e($customer_data['first_name']); ?>"
                                       placeholder="Enter first name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="last_name" class="form-input" required
                                       value="<?php echo e($customer_data['last_name']); ?>"
                                       placeholder="Enter last name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" name="phone" class="form-input" required
                                       value="<?php echo e($customer_data['phone']); ?>"
                                       placeholder="Enter phone number">
                            </div>

                            <div class="form-group">
                                <label class="form-label">State</label>
                                <select name="state" class="form-select">
                                    <option value="">Select State</option>
                                    <?php foreach (AU_STATES as $code => $name): ?>
                                    <option value="<?php echo $code; ?>" <?php echo $customer_data['state'] === $code ? 'selected' : ''; ?>>
                                        <?php echo e($name); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Address</label>
                                <input type="text" name="address" class="form-input"
                                       value="<?php echo e($customer_data['address']); ?>"
                                       placeholder="Enter street address">
                            </div>

                            <div class="form-group">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-input"
                                       value="<?php echo e($customer_data['city']); ?>"
                                       placeholder="Enter city">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Postal Code</label>
                                <input type="text" name="postal_code" class="form-input" maxlength="4"
                                       value="<?php echo e($customer_data['postal_code']); ?>"
                                       placeholder="Enter postal code">
                            </div>

                            <div class="form-group full-width">
                                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="is_active" <?php echo $customer_data['is_active'] ? 'checked' : ''; ?>>
                                    <span class="form-label" style="margin: 0;">Active Account</span>
                                </label>
                                <small style="color: #6c757d;">Unchecking this will prevent the customer from logging in</small>
                            </div>
                        </div>

                        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6;">
                            <button type="submit" class="btn btn-primary">Update Customer</button>
                            <a href="customers.php?action=view&id=<?php echo $customer_id; ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Status Toggle Modal -->
    <div id="statusModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 400px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-warning);">Confirm Status Change</h3>
            <p style="margin-bottom: 20px;" id="statusModalText">Are you sure you want to change this customer's status?</p>
            <form method="POST" id="statusForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="toggle_status">
                <input type="hidden" name="customer_id" id="statusCustomerId">
                <input type="hidden" name="new_status" id="newStatus">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeStatusModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-warning">Confirm Change</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div id="passwordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 500px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-danger);">Reset Customer Password</h3>
            <p style="margin-bottom: 20px;">Enter a new password for this customer. They will need to use this password to log in.</p>
            <form method="POST" id="passwordForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="customer_id" id="passwordCustomerId">
                
                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-input" required
                           minlength="8" placeholder="Enter new password">
                    <small style="color: #6c757d;">Password must be at least 8 characters with uppercase, lowercase, number, and special character.</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" onclick="closePasswordModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const status = document.getElementById('statusFilter').value;
        const state = document.getElementById('stateFilter').value;
        
        let url = 'customers.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (status !== '') params.push('status=' + encodeURIComponent(status));
        if (state) params.push('state=' + encodeURIComponent(state));
        
        // Preserve current sort
        const currentSort = '<?php echo $sort; ?>';
        const currentOrder = '<?php echo $order; ?>';
        if (currentSort) params.push('sort=' + currentSort);
        if (currentOrder) params.push('order=' + currentOrder);
        
        window.location.href = url + params.join('&');
    }

    function sortTable(column) {
        const currentSort = '<?php echo $sort; ?>';
        const currentOrder = '<?php echo $order; ?>';
        
        let newOrder = 'ASC';
        if (column === currentSort && currentOrder === 'ASC') {
            newOrder = 'DESC';
        }
        
        let url = 'customers.php?sort=' + column + '&order=' + newOrder;
        
        // Preserve current filters
        const search = '<?php echo $search; ?>';
        const status = '<?php echo $status_filter; ?>';
        const state = '<?php echo $state_filter; ?>';
        
        if (search) url += '&search=' + encodeURIComponent(search);
        if (status !== '') url += '&status=' + encodeURIComponent(status);
        if (state) url += '&state=' + encodeURIComponent(state);
        
        window.location.href = url;
    }

    function toggleStatus(customerId, newStatus) {
        const statusText = newStatus === '1' ? 'activate' : 'deactivate';
        document.getElementById('statusModalText').textContent = 
            `Are you sure you want to ${statusText} this customer's account?`;
        document.getElementById('statusCustomerId').value = customerId;
        document.getElementById('newStatus').value = newStatus;
        document.getElementById('statusModal').style.display = 'block';
    }

    function closeStatusModal() {
        document.getElementById('statusModal').style.display = 'none';
    }

    function resetPassword(customerId) {
        document.getElementById('passwordCustomerId').value = customerId;
        document.getElementById('passwordModal').style.display = 'block';
    }

    function closePasswordModal() {
        document.getElementById('passwordModal').style.display = 'none';
    }

    // Close modals when clicking outside
    document.getElementById('statusModal').addEventListener('click', function(e) {
        if (e.target === this) closeStatusModal();
    });

    document.getElementById('passwordModal').addEventListener('click', function(e) {
        if (e.target === this) closePasswordModal();
    });

    // Auto-search on Enter
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);
    </script>
</body>
</html>

<?php
// Helper function for pagination URLs
function buildPaginationUrl($page) {
    global $search, $status_filter, $state_filter, $sort, $order;
    
    $params = ['page' => $page];
    if ($search) $params['search'] = $search;
    if ($status_filter !== '') $params['status'] = $status_filter;
    if ($state_filter) $params['state'] = $state_filter;
    if ($sort) $params['sort'] = $sort;
    if ($order) $params['order'] = $order;
    
    return 'customers.php?' . http_build_query($params);
}
?>