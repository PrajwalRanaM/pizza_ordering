<?php
// admin/dashboard.php - Admin Dashboard
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

// Get dashboard statistics
$stats = [];

try {
    // Total customers
    $result = $conn->query("SELECT COUNT(*) as count FROM customers WHERE is_active = 1");
    $stats['customers'] = $result->fetch_assoc()['count'];
    
    // Total orders
    $result = $conn->query("SELECT COUNT(*) as count FROM orders");
    $stats['total_orders'] = $result->fetch_assoc()['count'];
    
    // Today's orders
    $result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()");
    $stats['today_orders'] = $result->fetch_assoc()['count'];
    
    // Pending orders
    $result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE order_status_id = " . ORDER_STATUS_PENDING);
    $stats['pending_orders'] = $result->fetch_assoc()['count'];
    
    // Revenue today
    $result = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as revenue FROM orders WHERE DATE(created_at) = CURDATE() AND payment_status = 'completed'");
    $stats['today_revenue'] = $result->fetch_assoc()['revenue'];
    
    // Total revenue
    $result = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as revenue FROM orders WHERE payment_status = 'completed'");
    $stats['total_revenue'] = $result->fetch_assoc()['revenue'];
    
    // Active products
    $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE is_active = 1");
    $stats['active_products'] = $result->fetch_assoc()['count'];
    
    // Active employees
    $result = $conn->query("SELECT COUNT(*) as count FROM employees WHERE is_active = 1");
    $stats['active_employees'] = $result->fetch_assoc()['count'];
    
} catch (Exception $e) {
    logError('Dashboard stats error: ' . $e->getMessage());
}

// Get recent orders
$recent_orders = [];
try {
    $stmt = $conn->prepare("
        SELECT o.order_id, o.order_number, o.total_amount, o.created_at, o.order_type,
               c.first_name, c.last_name, os.status_name, l.store_name
        FROM orders o
        JOIN customers c ON o.customer_id = c.customer_id
        JOIN order_statuses os ON o.order_status_id = os.status_id
        JOIN locations l ON o.location_id = l.location_id
        ORDER BY o.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Recent orders error: ' . $e->getMessage());
}

// Get low stock items (for future implementation)
$low_stock_items = [];

$current_page = 'admin_dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">Dashboard</h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">👥</div>
                        <div class="stat-number"><?php echo number_format($stats['customers']); ?></div>
                        <div class="stat-label">Total Customers</div>
                    </div>
                    
                    <div class="stat-card warning">
                        <div class="stat-icon">📋</div>
                        <div class="stat-number"><?php echo number_format($stats['pending_orders']); ?></div>
                        <div class="stat-label">Pending Orders</div>
                    </div>
                    
                    <div class="stat-card success">
                        <div class="stat-icon">📈</div>
                        <div class="stat-number"><?php echo number_format($stats['today_orders']); ?></div>
                        <div class="stat-label">Today's Orders</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">💰</div>
                        <div class="stat-number"><?php echo formatPrice($stats['today_revenue']); ?></div>
                        <div class="stat-label">Today's Revenue</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">🍕</div>
                        <div class="stat-number"><?php echo number_format($stats['active_products']); ?></div>
                        <div class="stat-label">Active Products</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">👨‍💼</div>
                        <div class="stat-number"><?php echo number_format($stats['active_employees']); ?></div>
                        <div class="stat-label">Active Staff</div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <a href="products.php?action=add" class="quick-action">
                        <div class="quick-action-icon">➕</div>
                        <div class="quick-action-title">Add Product</div>
                        <div class="quick-action-desc">Create new pizza or menu item</div>
                    </a>
                    
                    <a href="ingredients.php?action=add" class="quick-action">
                        <div class="quick-action-icon">🥬</div>
                        <div class="quick-action-title">Add Ingredient</div>
                        <div class="quick-action-desc">Add new pizza ingredient</div>
                    </a>
                    
                    <a href="employees.php?action=add" class="quick-action">
                        <div class="quick-action-icon">👨‍💼</div>
                        <div class="quick-action-title">Add Employee</div>
                        <div class="quick-action-desc">Register new staff member</div>
                    </a>
                    
                    <a href="orders.php?status=pending" class="quick-action">
                        <div class="quick-action-icon">📋</div>
                        <div class="quick-action-title">Pending Orders</div>
                        <div class="quick-action-desc">Manage current orders</div>
                    </a>
                </div>

                <!-- Recent Orders -->
                <div class="data-section">
                    <div class="section-header">
                        <h2 class="section-title">Recent Orders</h2>
                        <a href="orders.php" class="btn btn-primary">View All Orders</a>
                    </div>
                    
                    <?php if (!empty($recent_orders)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td><strong><?php echo e($order['order_number']); ?></strong></td>
                                <td><?php echo e($order['first_name'] . ' ' . $order['last_name']); ?></td>
                                <td>
                                    <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                </td>
                                <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $order['status_name'])); ?>">
                                        <?php echo e($order['status_name']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, H:i', strtotime($order['created_at'])); ?></td>
                                <td>
                                    <a href="orders.php?id=<?php echo $order['order_id']; ?>" 
                                       class="btn btn-primary btn-sm">View</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="padding: 40px; text-align: center; color: #6c757d;">
                        No recent orders found.
                    </div>
                    <?php endif; ?>
                </div>

                <!-- System Information -->
                <div class="data-section">
                    <div class="section-header">
                        <h2 class="section-title">System Overview</h2>
                    </div>
                    <div style="padding: 25px;">
                        <div class="stats-grid" style="margin-bottom: 0;">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo number_format($stats['total_orders']); ?></div>
                                <div class="stat-label">Total Orders</div>
                            </div>
                            <div class="stat-card success">
                                <div class="stat-number"><?php echo formatPrice($stats['total_revenue']); ?></div>
                                <div class="stat-label">Total Revenue</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo date('H:i'); ?></div>
                                <div class="stat-label">Current Time</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo isStoreOpen() ? 'OPEN' : 'CLOSED'; ?></div>
                                <div class="stat-label">Store Status</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
    // Auto-refresh dashboard every 30 seconds
    setInterval(function() {
        // Only refresh if page is visible
        if (!document.hidden) {
            location.reload();
        }
    }, 30000);

    // Mobile sidebar toggle (if needed)
    function toggleSidebar() {
        const sidebar = document.querySelector('.admin-sidebar');
        sidebar.classList.toggle('open');
    }

    // Add click handlers for better UX
    document.addEventListener('DOMContentLoaded', function() {
        // Highlight current nav item
        const currentPage = window.location.pathname.split('/').pop();
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            if (link.getAttribute('href') === currentPage) {
                link.classList.add('active');
            }
        });
    });
    </script>
</body>
</html>