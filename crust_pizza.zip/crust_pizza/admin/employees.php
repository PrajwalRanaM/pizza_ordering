<?php
// admin/employees.php - Employees Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$employee_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'add' || $form_action === 'edit') {
            // Validate and process employee data
            $username = sanitizeInput($_POST['username'] ?? '');
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $first_name = sanitizeInput($_POST['first_name'] ?? '');
            $last_name = sanitizeInput($_POST['last_name'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            $role_id = (int)($_POST['role_id'] ?? 0);
            $location_id = (int)($_POST['location_id'] ?? 0);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            $password = $_POST['password'] ?? '';
            
            // Validation
            $errors = [];
            if (empty($username)) $errors[] = 'Username is required.';
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
            if (empty($first_name)) $errors[] = 'First name is required.';
            if (empty($last_name)) $errors[] = 'Last name is required.';
            if (empty($phone)) $errors[] = 'Phone number is required.';
            if ($role_id <= 0) $errors[] = 'Please select a role.';
            if ($location_id <= 0) $errors[] = 'Please select a location.';
            
            // Username validation
            if (!preg_match(REGEX_USERNAME, $username)) {
                $errors[] = 'Username must be 3-20 characters and contain only letters, numbers, and underscores.';
            }
            
            // Phone validation
            $phone_clean = preg_replace('/[^0-9]/', '', $phone);
            if (strlen($phone_clean) !== 10) {
                $errors[] = 'Please enter a valid 10-digit phone number.';
            }
            
            // Password validation for new employees
            if ($form_action === 'add') {
                if (empty($password)) {
                    $errors[] = 'Password is required for new employees.';
                } else {
                    $password_errors = validatePassword($password);
                    $errors = array_merge($errors, $password_errors);
                }
            } elseif (!empty($password)) {
                // Validate password only if provided for edit
                $password_errors = validatePassword($password);
                $errors = array_merge($errors, $password_errors);
            }
            
            // Check for existing username/email
            if (empty($errors)) {
                try {
                    // Check username
                    $check_sql = "SELECT employee_id FROM employees WHERE username = ?";
                    if ($form_action === 'edit') {
                        $check_sql .= " AND employee_id != ?";
                    }
                    $stmt = $conn->prepare($check_sql);
                    if ($form_action === 'edit') {
                        $edit_id = (int)($_POST['employee_id'] ?? 0);
                        $stmt->bind_param("si", $username, $edit_id);
                    } else {
                        $stmt->bind_param("s", $username);
                    }
                    $stmt->execute();
                    if ($stmt->get_result()->num_rows > 0) {
                        $errors[] = 'Username already exists.';
                    }
                    
                    // Check email
                    $check_sql = "SELECT employee_id FROM employees WHERE email = ?";
                    if ($form_action === 'edit') {
                        $check_sql .= " AND employee_id != ?";
                    }
                    $stmt = $conn->prepare($check_sql);
                    if ($form_action === 'edit') {
                        $stmt->bind_param("si", $email, $edit_id);
                    } else {
                        $stmt->bind_param("s", $email);
                    }
                    $stmt->execute();
                    if ($stmt->get_result()->num_rows > 0) {
                        $errors[] = 'Email already exists.';
                    }
                } catch (Exception $e) {
                    $errors[] = 'Database error during validation.';
                }
            }
            
            if (empty($errors)) {
                try {
                    $formatted_phone = formatPhoneNumber($phone_clean);
                    
                    if ($form_action === 'add') {
                        // Add new employee
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        
                        $stmt = $conn->prepare("
                            INSERT INTO employees (username, password, email, first_name, last_name, 
                                                 phone, role_id, location_id, is_active, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->bind_param("ssssssiii", $username, $hashed_password, $email, 
                                        $first_name, $last_name, $formatted_phone, $role_id, 
                                        $location_id, $is_active);
                        
                        if ($stmt->execute()) {
                            $message = 'Employee added successfully!';
                            $action = 'list';
                        } else {
                            $error = 'Failed to add employee. Please try again.';
                        }
                    } else {
                        // Edit existing employee
                        $edit_id = (int)($_POST['employee_id'] ?? 0);
                        if ($edit_id > 0) {
                            if (!empty($password)) {
                                // Update with new password
                                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                                $stmt = $conn->prepare("
                                    UPDATE employees 
                                    SET username = ?, password = ?, email = ?, first_name = ?, last_name = ?, 
                                        phone = ?, role_id = ?, location_id = ?, is_active = ?, updated_at = NOW()
                                    WHERE employee_id = ?
                                ");
                                $stmt->bind_param("ssssssiiii", $username, $hashed_password, $email, 
                                                $first_name, $last_name, $formatted_phone, $role_id, 
                                                $location_id, $is_active, $edit_id);
                            } else {
                                // Update without changing password
                                $stmt = $conn->prepare("
                                    UPDATE employees 
                                    SET username = ?, email = ?, first_name = ?, last_name = ?, 
                                        phone = ?, role_id = ?, location_id = ?, is_active = ?, updated_at = NOW()
                                    WHERE employee_id = ?
                                ");
                                $stmt->bind_param("sssssiiiii", $username, $email, $first_name, $last_name, 
                                                $formatted_phone, $role_id, $location_id, $is_active, $edit_id);
                            }
                            
                            if ($stmt->execute()) {
                                $message = 'Employee updated successfully!';
                                $action = 'list';
                            } else {
                                $error = 'Failed to update employee. Please try again.';
                            }
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = implode('<br>', $errors);
            }
        } elseif ($form_action === 'delete') {
            $delete_id = (int)($_POST['employee_id'] ?? 0);
            if ($delete_id > 0) {
                try {
                    // Check if employee has any delivery assignments
                    $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM delivery_assignments WHERE employee_id = ?");
                    $check_stmt->bind_param("i", $delete_id);
                    $check_stmt->execute();
                    $assignments_count = $check_stmt->get_result()->fetch_assoc()['count'];
                    
                    if ($assignments_count > 0) {
                        // Soft delete - just mark as inactive
                        $stmt = $conn->prepare("UPDATE employees SET is_active = 0, updated_at = NOW() WHERE employee_id = ?");
                        $stmt->bind_param("i", $delete_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Employee deactivated successfully (has existing delivery records).';
                        } else {
                            $error = 'Failed to deactivate employee. Please try again.';
                        }
                    } else {
                        // Hard delete if no delivery assignments
                        $stmt = $conn->prepare("DELETE FROM employees WHERE employee_id = ?");
                        $stmt->bind_param("i", $delete_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Employee deleted successfully!';
                        } else {
                            $error = 'Failed to delete employee. Please try again.';
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Get employee roles
$roles = [];
try {
    $result = $conn->query("SELECT * FROM employee_roles ORDER BY role_name");
    $roles = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Roles fetch error: ' . $e->getMessage());
}

// Get locations
$locations = [];
try {
    $result = $conn->query("SELECT * FROM locations WHERE is_active = 1 ORDER BY store_name");
    $locations = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Locations fetch error: ' . $e->getMessage());
}

// Get employee data for editing
$employee_data = null;
if ($action === 'edit' && $employee_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_id = ?");
        $stmt->bind_param("i", $employee_id);
        $stmt->execute();
        $employee_data = $stmt->get_result()->fetch_assoc();
        
        if (!$employee_data) {
            $error = 'Employee not found.';
            $action = 'list';
        }
    } catch (Exception $e) {
        $error = 'Failed to load employee data.';
        $action = 'list';
    }
}

// Get employees list
$employees = [];
$search = $_GET['search'] ?? '';
$role_filter = $_GET['role'] ?? '';
$location_filter = $_GET['location'] ?? '';
$status_filter = $_GET['status'] ?? '';

if ($action === 'list') {
    try {
        $sql = "
            SELECT e.*, er.role_name, l.store_name, l.city 
            FROM employees e
            JOIN employee_roles er ON e.role_id = er.role_id
            JOIN locations l ON e.location_id = l.location_id
            WHERE 1=1
        ";
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (e.first_name LIKE ? OR e.last_name LIKE ? OR e.username LIKE ? OR e.email LIKE ?)";
            $search_param = "%$search%";
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'ssss';
        }
        
        if (!empty($role_filter)) {
            $sql .= " AND e.role_id = ?";
            $params[] = $role_filter;
            $types .= 'i';
        }
        
        if (!empty($location_filter)) {
            $sql .= " AND e.location_id = ?";
            $params[] = $location_filter;
            $types .= 'i';
        }
        
        if ($status_filter !== '') {
            $sql .= " AND e.is_active = ?";
            $params[] = (int)$status_filter;
            $types .= 'i';
        }
        
        $sql .= " ORDER BY e.first_name, e.last_name";
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        $error = 'Failed to load employees: ' . $e->getMessage();
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/employees.css">
    
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link active">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'add': echo 'Add New Employee'; break;
                        case 'edit': echo 'Edit Employee'; break;
                        default: echo 'Employees Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Employees List View -->
                <div class="page-header">
                    <h2 class="page-title">Employees</h2>
                    <a href="employees.php?action=add" class="btn btn-primary">Add New Employee</a>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Search employees..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Role</label>
                        <select class="form-select" id="roleFilter">
                            <option value="">All Roles</option>
                            <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role['role_id']; ?>" 
                                    <?php echo $role_filter == $role['role_id'] ? 'selected' : ''; ?>>
                                <?php echo e($role['role_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Location</label>
                        <select class="form-select" id="locationFilter">
                            <option value="">All Locations</option>
                            <?php foreach ($locations as $location): ?>
                            <option value="<?php echo $location['location_id']; ?>" 
                                    <?php echo $location_filter == $location['location_id'] ? 'selected' : ''; ?>>
                                <?php echo e($location['store_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="employees.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Employees Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Employee</th>
                            <th>Contact</th>
                            <th>Role</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($employees)): ?>
                        <?php foreach ($employees as $employee): ?>
                        <tr>
                            <td><?php echo $employee['employee_id']; ?></td>
                            <td>
                                <strong><?php echo e($employee['first_name'] . ' ' . $employee['last_name']); ?></strong>
                                <br>
                                <small style="color: #6c757d;">@<?php echo e($employee['username']); ?></small>
                            </td>
                            <td>
                                <div><?php echo e($employee['email']); ?></div>
                                <small style="color: #6c757d;"><?php echo e($employee['phone']); ?></small>
                            </td>
                            <td>
                                <span class="role-badge role-<?php echo strtolower(str_replace(' ', '-', $employee['role_name'])); ?>">
                                    <?php echo e($employee['role_name']); ?>
                                </span>
                            </td>
                            <td>
                                <strong><?php echo e($employee['store_name']); ?></strong>
                                <br>
                                <small style="color: #6c757d;"><?php echo e($employee['city']); ?></small>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $employee['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $employee['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($employee['created_at'])); ?></td>
                            <td>
                                <a href="employees.php?action=edit&id=<?php echo $employee['employee_id']; ?>" 
                                   class="btn btn-primary btn-sm">Edit</a>
                                <button onclick="deleteEmployee(<?php echo $employee['employee_id']; ?>)" 
                                        class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #6c757d;">
                                No employees found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Add/Edit Employee Form -->
                <div class="page-header">
                    <h2 class="page-title"><?php echo $action === 'add' ? 'Add New Employee' : 'Edit Employee'; ?></h2>
                    <a href="employees.php" class="btn btn-secondary">Back to Employees</a>
                </div>

                <div class="form-container">
                    <form method="POST" action="" id="employeeForm">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <?php if ($action === 'edit'): ?>
                        <input type="hidden" name="employee_id" value="<?php echo $employee_id; ?>">
                        <?php endif; ?>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="form-input" required
                                       value="<?php echo e($employee_data['username'] ?? ''); ?>"
                                       placeholder="Enter username (3-20 characters)"
                                       pattern="[a-zA-Z0-9_]{3,20}"
                                       title="Username must be 3-20 characters and contain only letters, numbers, and underscores">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-input" required
                                       value="<?php echo e($employee_data['email'] ?? ''); ?>"
                                       placeholder="employee@crustpizza.com.au">
                            </div>

                            <div class="form-group">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="first_name" class="form-input" required
                                       value="<?php echo e($employee_data['first_name'] ?? ''); ?>"
                                       placeholder="Enter first name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="last_name" class="form-input" required
                                       value="<?php echo e($employee_data['last_name'] ?? ''); ?>"
                                       placeholder="Enter last name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" name="phone" class="form-input" required
                                       value="<?php echo e($employee_data['phone'] ?? ''); ?>"
                                       placeholder="04XX XXX XXX"
                                       pattern="[0-9\s\-\(\)\+]{10,15}">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Role *</label>
                                <select name="role_id" class="form-select" required>
                                    <option value="">Select Role</option>
                                    <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['role_id']; ?>"
                                            <?php echo ($employee_data['role_id'] ?? '') == $role['role_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($role['role_name']); ?>
                                        <?php if (!empty($role['description'])): ?>
                                            - <?php echo e($role['description']); ?>
                                        <?php endif; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Location *</label>
                                <select name="location_id" class="form-select" required>
                                    <option value="">Select Location</option>
                                    <?php foreach ($locations as $location): ?>
                                    <option value="<?php echo $location['location_id']; ?>"
                                            <?php echo ($employee_data['location_id'] ?? '') == $location['location_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($location['store_name'] . ' - ' . $location['city']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Status</label>
                                <div class="checkbox-group">
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_active" id="is_active"
                                               <?php echo ($employee_data['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                        <label for="is_active">Active Employee</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">
                                    Password <?php echo $action === 'add' ? '*' : ''; ?>
                                    <?php if ($action === 'edit'): ?>
                                        <small style="color: #6c757d;">(Leave blank to keep current password)</small>
                                    <?php endif; ?>
                                </label>
                                <input type="password" name="password" class="form-input" 
                                       <?php echo $action === 'add' ? 'required' : ''; ?>
                                       placeholder="<?php echo $action === 'add' ? 'Enter secure password' : 'Enter new password (optional)'; ?>"
                                       minlength="<?php echo PASSWORD_MIN_LENGTH; ?>"
                                       id="passwordInput">
                                
                                <?php if ($action === 'add'): ?>
                                <div class="password-requirements">
                                    <h4>Password Requirements:</h4>
                                    <ul>
                                        <li>At least <?php echo PASSWORD_MIN_LENGTH; ?> characters long</li>
                                        <li>One uppercase letter (A-Z)</li>
                                        <li>One lowercase letter (a-z)</li>
                                        <li>One number (0-9)</li>
                                        <li>One special character (!@#$%^&*)</li>
                                    </ul>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div style="margin-top: 30px;">
                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                <?php echo $action === 'add' ? 'Add Employee' : 'Update Employee'; ?>
                            </button>
                            <a href="employees.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 450px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-danger);">Confirm Delete</h3>
            <p style="margin-bottom: 20px;">Are you sure you want to delete this employee? If they have delivery assignments, their account will be deactivated instead of deleted.</p>
            <div style="background: #fff3cd; color: #856404; padding: 10px; border-radius: 4px; margin-bottom: 20px; font-size: 0.9rem;">
                <strong>Warning:</strong> This action cannot be undone. The employee will lose access to their account immediately.
            </div>
            <form method="POST" id="deleteForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="employee_id" id="deleteEmployeeId">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Employee</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Filter functionality
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const role = document.getElementById('roleFilter').value;
        const location = document.getElementById('locationFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        let url = 'employees.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (role) params.push('role=' + encodeURIComponent(role));
        if (location) params.push('location=' + encodeURIComponent(location));
        if (status !== '') params.push('status=' + encodeURIComponent(status));
        
        window.location.href = url + params.join('&');
    }

    // Delete employee
    function deleteEmployee(employeeId) {
        document.getElementById('deleteEmployeeId').value = employeeId;
        document.getElementById('deleteModal').style.display = 'block';
    }

    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('deleteModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDeleteModal();
        }
    });

    // Auto-search on Enter
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Form validation and phone formatting
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('employeeForm');
        const phoneInput = document.querySelector('input[name="phone"]');
        const passwordInput = document.getElementById('passwordInput');
        const submitBtn = document.getElementById('submitBtn');
        
        // Phone number formatting
        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                if (value.length >= 10) {
                    value = value.substring(0, 10);
                    value = value.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
                }
                this.value = value;
            });
        }

        // Form validation
        if (form) {
            form.addEventListener('submit', function(e) {
                const username = document.querySelector('input[name="username"]').value.trim();
                const email = document.querySelector('input[name="email"]').value.trim();
                const firstName = document.querySelector('input[name="first_name"]').value.trim();
                const lastName = document.querySelector('input[name="last_name"]').value.trim();
                const phone = phoneInput.value.replace(/\D/g, '');
                const roleId = document.querySelector('select[name="role_id"]').value;
                const locationId = document.querySelector('select[name="location_id"]').value;
                const password = passwordInput ? passwordInput.value : '';
                const isAddForm = <?php echo $action === 'add' ? 'true' : 'false'; ?>;
                
                let hasError = false;
                let errorMessages = [];
                
                // Validate required fields
                if (!username) {
                    errorMessages.push('Username is required');
                    hasError = true;
                } else if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
                    errorMessages.push('Username must be 3-20 characters and contain only letters, numbers, and underscores');
                    hasError = true;
                }
                
                if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    errorMessages.push('Please enter a valid email address');
                    hasError = true;
                }
                
                if (!firstName) {
                    errorMessages.push('First name is required');
                    hasError = true;
                }
                
                if (!lastName) {
                    errorMessages.push('Last name is required');
                    hasError = true;
                }
                
                if (phone.length !== 10) {
                    errorMessages.push('Please enter a valid 10-digit phone number');
                    hasError = true;
                }
                
                if (!roleId) {
                    errorMessages.push('Please select a role');
                    hasError = true;
                }
                
                if (!locationId) {
                    errorMessages.push('Please select a location');
                    hasError = true;
                }
                
                // Password validation for new employees or when password is provided
                if (isAddForm || password) {
                    if (!password && isAddForm) {
                        errorMessages.push('Password is required for new employees');
                        hasError = true;
                    } else if (password) {
                        const passwordErrors = validatePassword(password);
                        if (passwordErrors.length > 0) {
                            errorMessages = errorMessages.concat(passwordErrors);
                            hasError = true;
                        }
                    }
                }
                
                if (hasError) {
                    e.preventDefault();
                    alert('Please fix the following errors:\n\n' + errorMessages.join('\n'));
                    return false;
                }
                
                // Show loading state
                submitBtn.disabled = true;
                submitBtn.textContent = isAddForm ? 'Adding Employee...' : 'Updating Employee...';
            });
        }

        // Password strength indicator (for add form)
        if (passwordInput && <?php echo $action === 'add' ? 'true' : 'false'; ?>) {
            passwordInput.addEventListener('input', function() {
                validatePasswordRealTime(this.value);
            });
        }
    });

    // Password validation function
    function validatePassword(password) {
        const errors = [];
        const minLength = <?php echo PASSWORD_MIN_LENGTH; ?>;
        
        if (password.length < minLength) {
            errors.push(`Password must be at least ${minLength} characters long`);
        }
        if (!/[A-Z]/.test(password)) {
            errors.push('Password must contain at least one uppercase letter');
        }
        if (!/[a-z]/.test(password)) {
            errors.push('Password must contain at least one lowercase letter');
        }
        if (!/[0-9]/.test(password)) {
            errors.push('Password must contain at least one number');
        }
        if (!/[^A-Za-z0-9]/.test(password)) {
            errors.push('Password must contain at least one special character');
        }
        
        return errors;
    }

    // Real-time password validation visual feedback
    function validatePasswordRealTime(password) {
        const requirements = document.querySelector('.password-requirements');
        if (!requirements) return;
        
        const items = requirements.querySelectorAll('li');
        const checks = [
            password.length >= <?php echo PASSWORD_MIN_LENGTH; ?>,
            /[A-Z]/.test(password),
            /[a-z]/.test(password),
            /[0-9]/.test(password),
            /[^A-Za-z0-9]/.test(password)
        ];
        
        items.forEach((item, index) => {
            if (checks[index]) {
                item.style.color = '#155724';
                item.style.fontWeight = '600';
                item.innerHTML = '✓ ' + item.textContent.replace('✓ ', '');
            } else {
                item.style.color = '#721c24';
                item.style.fontWeight = 'normal';
                item.innerHTML = item.textContent.replace('✓ ', '');
            }
        });
    }

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            document.getElementById('searchInput').focus();
        }
        
        // Escape to close modal
        if (e.key === 'Escape') {
            closeDeleteModal();
        }
    });

    // Auto-complete suggestions for email domain
    document.addEventListener('DOMContentLoaded', function() {
        const emailInput = document.querySelector('input[name="email"]');
        if (emailInput) {
            emailInput.addEventListener('input', function() {
                const value = this.value;
                if (value.includes('@') && !value.includes('@crustpizza.com.au')) {
                    // Could add auto-suggestion logic here
                }
            });
        }
    });

    // Enhanced form submission with better UX
    function enhancedSubmit() {
        const form = document.getElementById('employeeForm');
        if (form) {
            // Add a subtle loading animation
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.style.position = 'relative';
            submitBtn.innerHTML = `
                <span style="opacity: 0.7;">${submitBtn.textContent}</span>
                <span style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%);">
                    ⏳
                </span>
            `;
        }
    }
    </script>
</body>
</html>