<?php
// admin/ingredients.php - Ingredients Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$ingredient_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'add' || $form_action === 'edit') {
            // Validate and process ingredient data
            $ingredient_name = sanitizeInput($_POST['ingredient_name'] ?? '');
            $description = sanitizeInput($_POST['description'] ?? '');
            $category = $_POST['category'] ?? '';
            $price = (float)($_POST['price'] ?? 0);
            $is_vegan = isset($_POST['is_vegan']) ? 1 : 0;
            $is_gluten_free = isset($_POST['is_gluten_free']) ? 1 : 0;
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Validation
            $errors = [];
            if (empty($ingredient_name)) $errors[] = 'Ingredient name is required.';
            if (empty($category)) $errors[] = 'Please select a category.';
            if ($price < 0) $errors[] = 'Price cannot be negative.';
            
            if (empty($errors)) {
                try {
                    if ($form_action === 'add') {
                        // Add new ingredient
                        $stmt = $conn->prepare("
                            INSERT INTO ingredients (ingredient_name, description, category, price, 
                                                   is_vegan, is_gluten_free, is_active, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->bind_param("sssdiiii", $ingredient_name, $description, $category, 
                                        $price, $is_vegan, $is_gluten_free, $is_active);
                        
                        if ($stmt->execute()) {
                            $message = 'Ingredient added successfully!';
                            $action = 'list';
                        } else {
                            $error = 'Failed to add ingredient. Please try again.';
                        }
                    } else {
                        // Edit existing ingredient
                        $edit_id = (int)($_POST['ingredient_id'] ?? 0);
                        if ($edit_id > 0) {
                            $stmt = $conn->prepare("
                                UPDATE ingredients 
                                SET ingredient_name = ?, description = ?, category = ?, price = ?, 
                                    is_vegan = ?, is_gluten_free = ?, is_active = ?, updated_at = NOW()
                                WHERE ingredient_id = ?
                            ");
                            $stmt->bind_param("sssdiiii", $ingredient_name, $description, $category, 
                                            $price, $is_vegan, $is_gluten_free, $is_active, $edit_id);
                            
                            if ($stmt->execute()) {
                                $message = 'Ingredient updated successfully!';
                                $action = 'list';
                            } else {
                                $error = 'Failed to update ingredient. Please try again.';
                            }
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = implode('<br>', $errors);
            }
        } elseif ($form_action === 'delete') {
            $delete_id = (int)($_POST['ingredient_id'] ?? 0);
            if ($delete_id > 0) {
                try {
                    // Check if ingredient is used in products
                    $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_ingredients WHERE ingredient_id = ?");
                    $check_stmt->bind_param("i", $delete_id);
                    $check_stmt->execute();
                    $usage_count = $check_stmt->get_result()->fetch_assoc()['count'];
                    
                    if ($usage_count > 0) {
                        $error = "Cannot delete ingredient. It is currently used in $usage_count product(s). Please remove it from all products first.";
                    } else {
                        // Safe to delete
                        $stmt = $conn->prepare("DELETE FROM ingredients WHERE ingredient_id = ?");
                        $stmt->bind_param("i", $delete_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Ingredient deleted successfully!';
                        } else {
                            $error = 'Failed to delete ingredient. Please try again.';
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Get ingredient data for editing
$ingredient_data = null;
if ($action === 'edit' && $ingredient_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM ingredients WHERE ingredient_id = ?");
        $stmt->bind_param("i", $ingredient_id);
        $stmt->execute();
        $ingredient_data = $stmt->get_result()->fetch_assoc();
        
        if (!$ingredient_data) {
            $error = 'Ingredient not found.';
            $action = 'list';
        }
    } catch (Exception $e) {
        $error = 'Failed to load ingredient data.';
        $action = 'list';
    }
}

// Get ingredients list
$ingredients = [];
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$status_filter = $_GET['status'] ?? '';

if ($action === 'list') {
    try {
        $sql = "SELECT * FROM ingredients WHERE 1=1";
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (ingredient_name LIKE ? OR description LIKE ?)";
            $search_param = "%$search%";
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'ss';
        }
        
        if (!empty($category_filter)) {
            $sql .= " AND category = ?";
            $params[] = $category_filter;
            $types .= 's';
        }
        
        if ($status_filter !== '') {
            $sql .= " AND is_active = ?";
            $params[] = (int)$status_filter;
            $types .= 'i';
        }
        
        $sql .= " ORDER BY category, ingredient_name";
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $ingredients = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        $error = 'Failed to load ingredients: ' . $e->getMessage();
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingredients Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/ingredients.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link active">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'add': echo 'Add New Ingredient'; break;
                        case 'edit': echo 'Edit Ingredient'; break;
                        default: echo 'Ingredients Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Ingredients List View -->
                <div class="page-header">
                    <h2 class="page-title">Ingredients</h2>
                    <a href="ingredients.php?action=add" class="btn btn-primary">Add New Ingredient</a>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Search ingredients..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Category</label>
                        <select class="form-select" id="categoryFilter">
                            <option value="">All Categories</option>
                            <option value="vegetarian" <?php echo $category_filter === 'vegetarian' ? 'selected' : ''; ?>>Vegetarian</option>
                            <option value="non-vegetarian" <?php echo $category_filter === 'non-vegetarian' ? 'selected' : ''; ?>>Non-Vegetarian</option>
                            <option value="sauce" <?php echo $category_filter === 'sauce' ? 'selected' : ''; ?>>Sauce</option>
                            <option value="cheese" <?php echo $category_filter === 'cheese' ? 'selected' : ''; ?>>Cheese</option>
                            <option value="other" <?php echo $category_filter === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="ingredients.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Ingredients Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ingredient Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Properties</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($ingredients)): ?>
                        <?php foreach ($ingredients as $ingredient): ?>
                        <tr>
                            <td><?php echo $ingredient['ingredient_id']; ?></td>
                            <td>
                                <strong><?php echo e($ingredient['ingredient_name']); ?></strong>
                                <?php if (!empty($ingredient['description'])): ?>
                                <br>
                                <small style="color: #6c757d;">
                                    <?php echo e(substr($ingredient['description'], 0, 40)) . (strlen($ingredient['description']) > 40 ? '...' : ''); ?>
                                </small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="category-badge category-<?php echo str_replace(' ', '-', $ingredient['category']); ?>">
                                    <?php echo ucfirst(str_replace('-', ' ', $ingredient['category'])); ?>
                                </span>
                            </td>
                            <td class="price-display"><?php echo formatPrice($ingredient['price']); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $ingredient['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $ingredient['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($ingredient['is_vegan']): ?>
                                    <span style="background: #6f42c1; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-right: 3px;">VEGAN</span>
                                <?php endif; ?>
                                <?php if ($ingredient['is_gluten_free']): ?>
                                    <span style="background: #fd7e14; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px;">GF</span>
                                <?php endif; ?>
                                <?php if (!$ingredient['is_vegan'] && !$ingredient['is_gluten_free']): ?>
                                    <span style="color: #6c757d; font-size: 12px;">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($ingredient['created_at'])); ?></td>
                            <td>
                                <a href="ingredients.php?action=edit&id=<?php echo $ingredient['ingredient_id']; ?>" 
                                   class="btn btn-primary btn-sm">Edit</a>
                                <button onclick="deleteIngredient(<?php echo $ingredient['ingredient_id']; ?>)" 
                                        class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #6c757d;">
                                No ingredients found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Add/Edit Ingredient Form -->
                <div class="page-header">
                    <h2 class="page-title"><?php echo $action === 'add' ? 'Add New Ingredient' : 'Edit Ingredient'; ?></h2>
                    <a href="ingredients.php" class="btn btn-secondary">Back to Ingredients</a>
                </div>

                <div class="form-container">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <?php if ($action === 'edit'): ?>
                        <input type="hidden" name="ingredient_id" value="<?php echo $ingredient_id; ?>">
                        <?php endif; ?>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Ingredient Name *</label>
                                <input type="text" name="ingredient_name" class="form-input" required
                                       value="<?php echo e($ingredient_data['ingredient_name'] ?? ''); ?>"
                                       placeholder="Enter ingredient name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Category *</label>
                                <select name="category" class="form-select" required>
                                    <option value="">Select Category</option>
                                    <option value="vegetarian" <?php echo ($ingredient_data['category'] ?? '') === 'vegetarian' ? 'selected' : ''; ?>>Vegetarian</option>
                                    <option value="non-vegetarian" <?php echo ($ingredient_data['category'] ?? '') === 'non-vegetarian' ? 'selected' : ''; ?>>Non-Vegetarian</option>
                                    <option value="sauce" <?php echo ($ingredient_data['category'] ?? '') === 'sauce' ? 'selected' : ''; ?>>Sauce</option>
                                    <option value="cheese" <?php echo ($ingredient_data['category'] ?? '') === 'cheese' ? 'selected' : ''; ?>>Cheese</option>
                                    <option value="other" <?php echo ($ingredient_data['category'] ?? '') === 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Price (AUD)</label>
                                <input type="number" name="price" class="form-input" step="0.01" min="0"
                                       value="<?php echo $ingredient_data['price'] ?? '0.00'; ?>"
                                       placeholder="0.00">
                                <small style="color: #6c757d;">Leave as 0.00 for base ingredients included in price</small>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Properties</label>
                                <div class="checkbox-group">
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_vegan" id="is_vegan"
                                               <?php echo ($ingredient_data['is_vegan'] ?? 0) ? 'checked' : ''; ?>>
                                        <label for="is_vegan">Vegan</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_gluten_free" id="is_gluten_free"
                                               <?php echo ($ingredient_data['is_gluten_free'] ?? 1) ? 'checked' : ''; ?>>
                                        <label for="is_gluten_free">Gluten Free</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_active" id="is_active"
                                               <?php echo ($ingredient_data['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                        <label for="is_active">Active</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Description</label>
                                <textarea name="description" class="form-textarea"
                                          placeholder="Enter ingredient description (optional)"><?php echo e($ingredient_data['description'] ?? ''); ?></textarea>
                            </div>
                        </div>

                        <div style="margin-top: 30px;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $action === 'add' ? 'Add Ingredient' : 'Update Ingredient'; ?>
                            </button>
                            <a href="ingredients.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 400px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-danger);">Confirm Delete</h3>
            <p style="margin-bottom: 20px;">Are you sure you want to delete this ingredient? This action cannot be undone and will remove it from all products that use it.</p>
            <form method="POST" id="deleteForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="ingredient_id" id="deleteIngredientId">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Ingredient</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const category = document.getElementById('categoryFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        let url = 'ingredients.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (category) params.push('category=' + encodeURIComponent(category));
        if (status !== '') params.push('status=' + encodeURIComponent(status));
        
        window.location.href = url + params.join('&');
    }

    function deleteIngredient(ingredientId) {
        document.getElementById('deleteIngredientId').value = ingredientId;
        document.getElementById('deleteModal').style.display = 'block';
    }

    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('deleteModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDeleteModal();
        }
    });

    // Auto-search on Enter
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);

    // Form validation
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const ingredientName = document.querySelector('input[name="ingredient_name"]');
                const category = document.querySelector('select[name="category"]');
                const price = document.querySelector('input[name="price"]');
                
                let hasError = false;
                
                // Validate ingredient name
                if (ingredientName && ingredientName.value.trim() === '') {
                    alert('Please enter an ingredient name.');
                    ingredientName.focus();
                    hasError = true;
                }
                
                // Validate category
                if (!hasError && category && category.value === '') {
                    alert('Please select a category.');
                    category.focus();
                    hasError = true;
                }
                
                // Validate price
                if (!hasError && price && parseFloat(price.value) < 0) {
                    alert('Price cannot be negative.');
                    price.focus();
                    hasError = true;
                }
                
                if (hasError) {
                    e.preventDefault();
                }
            });
        }
    });
    </script>
</body>
</html>