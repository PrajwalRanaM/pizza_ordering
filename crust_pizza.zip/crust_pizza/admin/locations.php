<?php
// admin/locations.php - Store Locations Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$location_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'add' || $form_action === 'edit') {
            // Validate and process location data
            $store_name = sanitizeInput($_POST['store_name'] ?? '');
            $address = sanitizeInput($_POST['address'] ?? '');
            $city = sanitizeInput($_POST['city'] ?? '');
            $state = $_POST['state'] ?? '';
            $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
            $phone = sanitizeInput($_POST['phone'] ?? '');
            $email = sanitizeInput($_POST['email'] ?? '');
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Validation
            $errors = [];
            if (empty($store_name)) $errors[] = 'Store name is required.';
            if (empty($address)) $errors[] = 'Address is required.';
            if (empty($city)) $errors[] = 'City is required.';
            if (empty($state)) $errors[] = 'Please select a state.';
            if (empty($postal_code)) $errors[] = 'Postal code is required.';
            if (empty($phone)) $errors[] = 'Phone number is required.';
            
            // Validate postal code format (Australian)
            if (!empty($postal_code) && !preg_match('/^[0-9]{4}$/', $postal_code)) {
                $errors[] = 'Please enter a valid 4-digit postal code.';
            }
            
            // Validate email if provided
            if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'Please enter a valid email address.';
            }
            
            // Validate phone number (Australian format)
            $phone_clean = preg_replace('/[^0-9]/', '', $phone);
            if (!isValidAustralianPhone($phone_clean)) {
                $errors[] = 'Please enter a valid Australian phone number.';
            }
            
            // State validation
            if (!array_key_exists($state, AU_STATES)) {
                $errors[] = 'Please select a valid Australian state.';
            }
            
            if (empty($errors)) {
                try {
                    $formatted_phone = formatAustralianPhone($phone_clean);
                    
                    if ($form_action === 'add') {
                        // Add new location
                        $stmt = $conn->prepare("
                            INSERT INTO locations (store_name, address, city, state, postal_code, 
                                                 phone, email, is_active, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->bind_param("sssssssi", $store_name, $address, $city, $state, 
                                        $postal_code, $formatted_phone, $email, $is_active);
                        
                        if ($stmt->execute()) {
                            $message = 'Location added successfully!';
                            $action = 'list';
                        } else {
                            $error = 'Failed to add location. Please try again.';
                        }
                    } else {
                        // Edit existing location
                        $edit_id = (int)($_POST['location_id'] ?? 0);
                        if ($edit_id > 0) {
                            $stmt = $conn->prepare("
                                UPDATE locations 
                                SET store_name = ?, address = ?, city = ?, state = ?, 
                                    postal_code = ?, phone = ?, email = ?, is_active = ?, updated_at = NOW()
                                WHERE location_id = ?
                            ");
                            $stmt->bind_param("sssssssii", $store_name, $address, $city, $state, 
                                            $postal_code, $formatted_phone, $email, $is_active, $edit_id);
                            
                            if ($stmt->execute()) {
                                $message = 'Location updated successfully!';
                                $action = 'list';
                            } else {
                                $error = 'Failed to update location. Please try again.';
                            }
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = implode('<br>', $errors);
            }
        } elseif ($form_action === 'delete') {
            $delete_id = (int)($_POST['location_id'] ?? 0);
            if ($delete_id > 0) {
                try {
                    // Check if location has orders
                    $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE location_id = ?");
                    $check_stmt->bind_param("i", $delete_id);
                    $check_stmt->execute();
                    $order_count = $check_stmt->get_result()->fetch_assoc()['count'];
                    
                    // Check if location has employees
                    $emp_stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE location_id = ?");
                    $emp_stmt->bind_param("i", $delete_id);
                    $emp_stmt->execute();
                    $employee_count = $emp_stmt->get_result()->fetch_assoc()['count'];
                    
                    if ($order_count > 0 || $employee_count > 0) {
                        $error = "Cannot delete location. It has $order_count order(s) and $employee_count employee(s). Please transfer or remove them first, or deactivate the location instead.";
                    } else {
                        // Safe to delete
                        $stmt = $conn->prepare("DELETE FROM locations WHERE location_id = ?");
                        $stmt->bind_param("i", $delete_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Location deleted successfully!';
                        } else {
                            $error = 'Failed to delete location. Please try again.';
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Get location data for editing
$location_data = null;
if ($action === 'edit' && $location_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM locations WHERE location_id = ?");
        $stmt->bind_param("i", $location_id);
        $stmt->execute();
        $location_data = $stmt->get_result()->fetch_assoc();
        
        if (!$location_data) {
            $error = 'Location not found.';
            $action = 'list';
        }
    } catch (Exception $e) {
        $error = 'Failed to load location data.';
        $action = 'list';
    }
}

// Get locations list with statistics
$locations = [];
$search = $_GET['search'] ?? '';
$state_filter = $_GET['state'] ?? '';
$status_filter = $_GET['status'] ?? '';

if ($action === 'list') {
    try {
        $sql = "
            SELECT l.*, 
                   COUNT(DISTINCT o.order_id) as total_orders,
                   COUNT(DISTINCT e.employee_id) as employee_count,
                   COALESCE(SUM(CASE WHEN o.payment_status = 'completed' THEN o.total_amount ELSE 0 END), 0) as total_revenue
            FROM locations l
            LEFT JOIN orders o ON l.location_id = o.location_id
            LEFT JOIN employees e ON l.location_id = e.location_id AND e.is_active = 1
            WHERE 1=1
        ";
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (l.store_name LIKE ? OR l.city LIKE ? OR l.address LIKE ?)";
            $search_param = "%$search%";
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'sss';
        }
        
        if (!empty($state_filter)) {
            $sql .= " AND l.state = ?";
            $params[] = $state_filter;
            $types .= 's';
        }
        
        if ($status_filter !== '') {
            $sql .= " AND l.is_active = ?";
            $params[] = (int)$status_filter;
            $types .= 'i';
        }
        
        $sql .= " GROUP BY l.location_id ORDER BY l.store_name";
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $locations = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        $error = 'Failed to load locations: ' . $e->getMessage();
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/locations.css">
    
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link active">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'add': echo 'Add New Location'; break;
                        case 'edit': echo 'Edit Location'; break;
                        default: echo 'Locations Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Locations List View -->
                <div class="page-header">
                    <h2 class="page-title">Store Locations</h2>
                    <a href="locations.php?action=add" class="btn btn-primary">Add New Location</a>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Search locations..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">State</label>
                        <select class="form-select" id="stateFilter">
                            <option value="">All States</option>
                            <?php foreach (AU_STATES as $code => $name): ?>
                            <option value="<?php echo $code; ?>" 
                                    <?php echo $state_filter === $code ? 'selected' : ''; ?>>
                                <?php echo e($name); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="locations.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Locations Cards -->
                <?php if (!empty($locations)): ?>
                    <?php foreach ($locations as $location): ?>
                    <div class="location-card">
                        <div class="location-header">
                            <h3 class="location-name">
                                📍 <?php echo e($location['store_name']); ?>
                            </h3>
                            <div>
                                <span class="status-badge status-<?php echo $location['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $location['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </div>
                        </div>

                        <div class="location-details">
                            <div class="detail-group">
                                <h4>📍 Address</h4>
                                <p>
                                    <?php echo e($location['address']); ?><br>
                                    <?php echo e($location['city']); ?>, <?php echo e($location['state']); ?> <?php echo e($location['postal_code']); ?>
                                </p>
                            </div>
                            <div class="detail-group">
                                <h4>📞 Contact</h4>
                                <p>
                                    Phone: <?php echo e($location['phone']); ?><br>
                                    <?php if (!empty($location['email'])): ?>
                                    Email: <?php echo e($location['email']); ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>

                        <div class="location-stats">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo number_format($location['total_orders']); ?></div>
                                <div class="stat-label">Total Orders</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo number_format($location['employee_count']); ?></div>
                                <div class="stat-label">Staff Members</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo formatPrice($location['total_revenue']); ?></div>
                                <div class="stat-label">Total Revenue</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo date('M j, Y', strtotime($location['created_at'])); ?></div>
                                <div class="stat-label">Established</div>
                            </div>
                        </div>

                        <div style="margin-top: 20px; display: flex; gap: 10px;">
                            <a href="locations.php?action=edit&id=<?php echo $location['location_id']; ?>" 
                               class="btn btn-primary btn-sm">Edit Location</a>
                            <a href="employees.php?location=<?php echo $location['location_id']; ?>" 
                               class="btn btn-secondary btn-sm">View Staff</a>
                            <a href="orders.php?location=<?php echo $location['location_id']; ?>" 
                               class="btn btn-secondary btn-sm">View Orders</a>
                            <button onclick="deleteLocation(<?php echo $location['location_id']; ?>)" 
                                    class="btn btn-danger btn-sm">Delete</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div style="text-align: center; padding: 60px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h3 style="color: #6c757d; margin-bottom: 15px;">📍 No Locations Found</h3>
                    <p style="color: #6c757d; margin-bottom: 25px;">Get started by adding your first store location.</p>
                    <a href="locations.php?action=add" class="btn btn-primary">Add First Location</a>
                </div>
                <?php endif; ?>

                <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Add/Edit Location Form -->
                <div class="page-header">
                    <h2 class="page-title"><?php echo $action === 'add' ? 'Add New Location' : 'Edit Location'; ?></h2>
                    <a href="locations.php" class="btn btn-secondary">Back to Locations</a>
                </div>

                <div class="form-container">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <?php if ($action === 'edit'): ?>
                        <input type="hidden" name="location_id" value="<?php echo $location_id; ?>">
                        <?php endif; ?>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Store Name *</label>
                                <input type="text" name="store_name" class="form-input" required
                                       value="<?php echo e($location_data['store_name'] ?? ''); ?>"
                                       placeholder="Enter store name">
                                <div class="form-help">e.g., "Crust Pizza Melbourne CBD"</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" name="phone" class="form-input" required
                                       value="<?php echo e($location_data['phone'] ?? ''); ?>"
                                       placeholder="(03) 1234 5678">
                                <div class="form-help">Australian phone number format</div>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Street Address *</label>
                                <input type="text" name="address" class="form-input" required
                                       value="<?php echo e($location_data['address'] ?? ''); ?>"
                                       placeholder="123 Collins Street">
                            </div>

                            <div class="form-group">
                                <label class="form-label">City/Suburb *</label>
                                <input type="text" name="city" class="form-input" required
                                       value="<?php echo e($location_data['city'] ?? ''); ?>"
                                       placeholder="Melbourne">
                            </div>

                            <div class="form-group">
                                <label class="form-label">State *</label>
                                <select name="state" class="form-select" required>
                                    <option value="">Select State</option>
                                    <?php foreach (AU_STATES as $code => $name): ?>
                                    <option value="<?php echo $code; ?>" 
                                            <?php echo ($location_data['state'] ?? '') === $code ? 'selected' : ''; ?>>
                                        <?php echo e($name); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Postal Code *</label>
                                <input type="text" name="postal_code" class="form-input" required
                                       value="<?php echo e($location_data['postal_code'] ?? ''); ?>"
                                       placeholder="3000"
                                       pattern="[0-9]{4}"
                                       maxlength="4">
                                <div class="form-help">4-digit Australian postal code</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-input"
                                       value="<?php echo e($location_data['email'] ?? ''); ?>"
                                       placeholder="store@crustpizza.com.au">
                                <div class="form-help">Optional - store contact email</div>
                            </div>

                            <div class="form-group">
                                <div class="checkbox-item">
                                    <input type="checkbox" name="is_active" id="is_active"
                                           <?php echo ($location_data['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                    <label for="is_active" class="form-label">Active Location</label>
                                </div>
                                <div class="form-help">Inactive locations won't appear in customer location selection</div>
                            </div>
                        </div>

                        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $action === 'add' ? 'Add Location' : 'Update Location'; ?>
                            </button>
                            <a href="locations.php" class="btn btn-secondary">Cancel</a>
                            
                            <?php if ($action === 'edit'): ?>
                            <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 4px;">
                                <h4 style="margin-bottom: 10px; color: var(--admin-primary);">Location Information</h4>
                                <p style="margin: 0; color: #6c757d; font-size: 0.9rem;">
                                    <strong>Created:</strong> <?php echo date('F j, Y \a\t g:i A', strtotime($location_data['created_at'])); ?><br>
                                    <strong>Last Updated:</strong> <?php echo date('F j, Y \a\t g:i A', strtotime($location_data['updated_at'])); ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 450px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-danger);">⚠️ Confirm Delete</h3>
            <p style="margin-bottom: 20px; line-height: 1.5;">
                Are you sure you want to delete this location? This action cannot be undone and will:
            </p>
            <ul style="margin-bottom: 20px; color: #6c757d; padding-left: 20px;">
                <li>Remove the location from customer selection</li>
                <li>Affect any employees assigned to this location</li>
                <li>Impact order history and reporting</li>
            </ul>
            <p style="margin-bottom: 20px; color: var(--admin-warning); font-weight: 600;">
                💡 Tip: Consider deactivating the location instead of deleting it.
            </p>
            <form method="POST" id="deleteForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="location_id" id="deleteLocationId">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Location</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const state = document.getElementById('stateFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        let url = 'locations.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (state) params.push('state=' + encodeURIComponent(state));
        if (status !== '') params.push('status=' + encodeURIComponent(status));
        
        window.location.href = url + params.join('&');
    }

    function deleteLocation(locationId) {
        document.getElementById('deleteLocationId').value = locationId;
        document.getElementById('deleteModal').style.display = 'block';
    }

    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('deleteModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDeleteModal();
        }
    });

    // Auto-search on Enter
    document.getElementById('searchInput')?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Phone number formatting
    document.addEventListener('DOMContentLoaded', function() {
        const phoneInput = document.querySelector('input[name="phone"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                
                if (value.length >= 10) {
                    if (value.startsWith('04') || value.startsWith('05')) {
                        // Mobile number
                        value = value.substring(0, 10);
                        value = value.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
                    } else if (value.startsWith('02') || value.startsWith('03') || value.startsWith('07') || value.startsWith('08')) {
                        // Landline number
                        value = value.substring(0, 10);
                        value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2 $3');
                    }
                }
                
                this.value = value;
            });
        }

        // Postal code validation
        const postalInput = document.querySelector('input[name="postal_code"]');
        if (postalInput) {
            postalInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '').substring(0, 4);
            });
        }

        // Form validation
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const storeName = document.querySelector('input[name="store_name"]');
                const address = document.querySelector('input[name="address"]');
                const city = document.querySelector('input[name="city"]');
                const state = document.querySelector('select[name="state"]');
                const postalCode = document.querySelector('input[name="postal_code"]');
                const phone = document.querySelector('input[name="phone"]');
                
                let hasError = false;
                
                // Validate required fields
                if (storeName && storeName.value.trim() === '') {
                    alert('Please enter a store name.');
                    storeName.focus();
                    hasError = true;
                }
                
                if (!hasError && address && address.value.trim() === '') {
                    alert('Please enter the street address.');
                    address.focus();
                    hasError = true;
                }
                
                if (!hasError && city && city.value.trim() === '') {
                    alert('Please enter the city/suburb.');
                    city.focus();
                    hasError = true;
                }
                
                if (!hasError && state && state.value === '') {
                    alert('Please select a state.');
                    state.focus();
                    hasError = true;
                }
                
                if (!hasError && postalCode && !/^\d{4}$/.test(postalCode.value)) {
                    alert('Please enter a valid 4-digit postal code.');
                    postalCode.focus();
                    hasError = true;
                }
                
                if (!hasError && phone && phone.value.trim() === '') {
                    alert('Please enter a phone number.');
                    phone.focus();
                    hasError = true;
                }
                
                // Validate phone number format
                if (!hasError && phone) {
                    const phoneClean = phone.value.replace(/\D/g, '');
                    if (phoneClean.length !== 10) {
                        alert('Please enter a valid 10-digit Australian phone number.');
                        phone.focus();
                        hasError = true;
                    }
                }
                
                if (hasError) {
                    e.preventDefault();
                }
            });
        }
    });

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Press 'N' to add new location
        if (e.key === 'n' || e.key === 'N') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.target.matches('input, textarea, select')) {
                window.location.href = 'locations.php?action=add';
            }
        }
        
        // Press Escape to close modal
        if (e.key === 'Escape') {
            closeDeleteModal();
        }
    });

    // Add smooth scrolling to form sections
    function scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Add loading state to buttons on form submit
    document.addEventListener('DOMContentLoaded', function() {
        const forms = document.querySelectorAll('form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function() {
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    const originalText = submitBtn.textContent;
                    submitBtn.textContent = 'Processing...';
                    
                    // Re-enable after 5 seconds as fallback
                    setTimeout(() => {
                        submitBtn.disabled = false;
                        submitBtn.textContent = originalText;
                    }, 5000);
                }
            });
        });
    });
    </script>
</body>
</html>