<?php
// admin/orders.php - Orders Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$order_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'update_status') {
            $update_order_id = (int)($_POST['order_id'] ?? 0);
            $new_status = (int)($_POST['new_status'] ?? 0);
            $admin_notes = sanitizeInput($_POST['admin_notes'] ?? '');
            
            if ($update_order_id > 0 && $new_status > 0) {
                try {
                    $conn->begin_transaction();
                    
                    // Update order status
                    $stmt = $conn->prepare("UPDATE orders SET order_status_id = ?, updated_at = NOW() WHERE order_id = ?");
                    $stmt->bind_param("ii", $new_status, $update_order_id);
                    
                    if ($stmt->execute()) {
                        // Add status history
                        $admin_id = getCurrentUserId();
                        $history_stmt = $conn->prepare("
                            INSERT INTO order_status_history (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                            VALUES (?, ?, 'admin', ?, ?, NOW())
                        ");
                        $history_stmt->bind_param("iiss", $update_order_id, $new_status, $admin_id, $admin_notes);
                        $history_stmt->execute();
                        
                        $conn->commit();
                        $message = 'Order status updated successfully!';
                    } else {
                        $conn->rollback();
                        $error = 'Failed to update order status.';
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = 'Invalid order or status.';
            }
        } elseif ($form_action === 'add_order') {
            // Handle manual order creation (simplified)
            $customer_id = (int)($_POST['customer_id'] ?? 0);
            $location_id = (int)($_POST['location_id'] ?? 0);
            $order_type = $_POST['order_type'] ?? 'delivery';
            $total_amount = (float)($_POST['total_amount'] ?? 0);
            $payment_method = $_POST['payment_method'] ?? 'credit_card';
            
            if ($customer_id > 0 && $location_id > 0 && $total_amount > 0) {
                try {
                    // Generate order number
                    $order_number = 'CP' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                    
                    $subtotal = $total_amount / 1.1; // Remove tax
                    $tax_amount = $total_amount - $subtotal;
                    
                    $stmt = $conn->prepare("
                        INSERT INTO orders (order_number, customer_id, location_id, order_type, 
                                          order_status_id, subtotal, tax_amount, delivery_fee, total_amount,
                                          payment_method, payment_status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, 1, ?, ?, 0, ?, 'credit_card', 'completed', NOW(), NOW())
                    ");
                    $stmt->bind_param("siisddd", $order_number, $customer_id, $location_id, $order_type,
                                    $subtotal, $tax_amount, $total_amount);
                    
                    if ($stmt->execute()) {
                        $message = "Order $order_number created successfully!";
                    } else {
                        $error = 'Failed to create order.';
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = 'Please fill in all required fields.';
            }
        }
    }
}

// Get order statuses
$order_statuses = [];
try {
    $result = $conn->query("SELECT * FROM order_statuses ORDER BY display_order");
    $order_statuses = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Order statuses fetch error: ' . $e->getMessage());
}

// Get order details for viewing
$order_details = null;
$order_items = [];
$order_history = [];

if ($action === 'view' && $order_id) {
    try {
        // Get order details
        $stmt = $conn->prepare("
            SELECT o.*, c.first_name, c.last_name, c.email, c.phone,
                   l.store_name, l.address as store_address, l.city as store_city,
                   os.status_name
            FROM orders o
            JOIN customers c ON o.customer_id = c.customer_id
            JOIN locations l ON o.location_id = l.location_id
            JOIN order_statuses os ON o.order_status_id = os.status_id
            WHERE o.order_id = ?
        ");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $order_details = $stmt->get_result()->fetch_assoc();
        
        if ($order_details) {
            // Get order items
            $items_stmt = $conn->prepare("
                SELECT oi.*, p.image_url
                FROM order_items oi
                LEFT JOIN products p ON oi.product_id = p.product_id
                WHERE oi.order_id = ?
                ORDER BY oi.order_item_id
            ");
            $items_stmt->bind_param("i", $order_id);
            $items_stmt->execute();
            $order_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            // Get order history
            $history_stmt = $conn->prepare("
                SELECT osh.*, os.status_name,
                       CASE 
                           WHEN osh.changed_by_type = 'admin' THEN CONCAT('Admin: ', a.first_name, ' ', a.last_name)
                           WHEN osh.changed_by_type = 'employee' THEN CONCAT('Staff: ', e.first_name, ' ', e.last_name)
                           WHEN osh.changed_by_type = 'customer' THEN CONCAT('Customer: ', c.first_name, ' ', c.last_name)
                           ELSE 'System'
                       END as changed_by_name
                FROM order_status_history osh
                JOIN order_statuses os ON osh.status_id = os.status_id
                LEFT JOIN admins a ON osh.changed_by_id = a.admin_id AND osh.changed_by_type = 'admin'
                LEFT JOIN employees e ON osh.changed_by_id = e.employee_id AND osh.changed_by_type = 'employee'
                LEFT JOIN customers c ON osh.changed_by_id = c.customer_id AND osh.changed_by_type = 'customer'
                WHERE osh.order_id = ?
                ORDER BY osh.created_at DESC
            ");
            $history_stmt->bind_param("i", $order_id);
            $history_stmt->execute();
            $order_history = $history_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        }
    } catch (Exception $e) {
        $error = 'Failed to load order details.';
        $action = 'list';
    }
}

// Get orders list
$orders = [];
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$date_filter = $_GET['date'] ?? '';

if ($action === 'list') {
    try {
        $sql = "
            SELECT o.*, c.first_name, c.last_name, c.email, 
                   l.store_name, os.status_name
            FROM orders o
            JOIN customers c ON o.customer_id = c.customer_id
            JOIN locations l ON o.location_id = l.location_id
            JOIN order_statuses os ON o.order_status_id = os.status_id
            WHERE 1=1
        ";
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (o.order_number LIKE ? OR c.first_name LIKE ? OR c.last_name LIKE ? OR c.email LIKE ?)";
            $search_param = "%$search%";
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'ssss';
        }
        
        if (!empty($status_filter)) {
            $sql .= " AND o.order_status_id = ?";
            $params[] = $status_filter;
            $types .= 'i';
        }
        
        if (!empty($type_filter)) {
            $sql .= " AND o.order_type = ?";
            $params[] = $type_filter;
            $types .= 's';
        }
        
        if (!empty($date_filter)) {
            $sql .= " AND DATE(o.created_at) = ?";
            $params[] = $date_filter;
            $types .= 's';
        }
        
        $sql .= " ORDER BY o.created_at DESC LIMIT 100";
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        $error = 'Failed to load orders: ' . $e->getMessage();
    }
}

// Get customers and locations for forms
$customers = [];
$locations = [];
try {
    $customers = $conn->query("SELECT customer_id, first_name, last_name, email FROM customers WHERE is_active = 1 ORDER BY first_name, last_name")->fetch_all(MYSQLI_ASSOC);
    $locations = $conn->query("SELECT location_id, store_name, city FROM locations WHERE is_active = 1 ORDER BY store_name")->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Customers/Locations fetch error: ' . $e->getMessage());
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/orders.css">

</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link active">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'view': echo 'Order Details'; break;
                        case 'add': echo 'Add New Order'; break;
                        default: echo 'Orders Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Orders List View -->
                <div class="page-header">
                    <h2 class="page-title">Orders</h2>
                    <div>
                        <a href="orders.php?action=add" class="btn btn-primary">Add Manual Order</a>
                        <a href="orders.php" class="btn btn-secondary">Refresh</a>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="quick-stats">
                    <?php
                    $stats = ['pending' => 0, 'preparing' => 0, 'ready' => 0, 'completed' => 0];
                    foreach ($orders as $order) {
                        switch ($order['order_status_id']) {
                            case ORDER_STATUS_PENDING:
                                $stats['pending']++;
                                break;
                            case ORDER_STATUS_PREPARING:
                                $stats['preparing']++;
                                break;
                            case ORDER_STATUS_READY:
                            case ORDER_STATUS_OUT_FOR_DELIVERY:
                                $stats['ready']++;
                                break;
                            case ORDER_STATUS_DELIVERED:
                            case ORDER_STATUS_PICKED_UP:
                                $stats['completed']++;
                                break;
                        }
                    }
                    ?>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $stats['pending']; ?></div>
                        <div class="stat-label">Pending Orders</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $stats['preparing']; ?></div>
                        <div class="stat-label">Preparing</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $stats['ready']; ?></div>
                        <div class="stat-label">Ready/Out</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $stats['completed']; ?></div>
                        <div class="stat-label">Completed</div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Order #, customer name, email..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <?php foreach ($order_statuses as $status): ?>
                            <option value="<?php echo $status['status_id']; ?>" 
                                    <?php echo $status_filter == $status['status_id'] ? 'selected' : ''; ?>>
                                <?php echo e($status['status_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Type</label>
                        <select class="form-select" id="typeFilter">
                            <option value="">All Types</option>
                            <option value="delivery" <?php echo $type_filter === 'delivery' ? 'selected' : ''; ?>>Delivery</option>
                            <option value="pickup" <?php echo $type_filter === 'pickup' ? 'selected' : ''; ?>>Pickup</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Date</label>
                        <input type="date" class="form-input" value="<?php echo e($date_filter); ?>" id="dateFilter">
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="orders.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Orders Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Store</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <strong><?php echo e($order['order_number']); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e($order['first_name'] . ' ' . $order['last_name']); ?></strong>
                                <br>
                                <small style="color: #6c757d;"><?php echo e($order['email']); ?></small>
                            </td>
                            <td><?php echo e($order['store_name']); ?></td>
                            <td>
                                <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                            </td>
                            <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $order['status_name'])); ?>">
                                    <?php echo e($order['status_name']); ?>
                                </span>
                            </td>
                            <td>
                                <span style="color: <?php echo $order['payment_status'] === 'completed' ? '#28a745' : '#ffc107'; ?>;">
                                    <?php echo ucfirst($order['payment_status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo date('M j, H:i', strtotime($order['created_at'])); ?>
                                <br>
                                <small style="color: #6c757d;"><?php echo date('Y', strtotime($order['created_at'])); ?></small>
                            </td>
                            <td>
                                <a href="orders.php?action=view&id=<?php echo $order['order_id']; ?>" 
                                   class="btn btn-primary btn-sm">View</a>
                                <?php if ($order['order_status_id'] < ORDER_STATUS_DELIVERED): ?>
                                <button onclick="quickStatusUpdate(<?php echo $order['order_id']; ?>, <?php echo $order['order_status_id']; ?>)" 
                                        class="btn btn-success btn-sm">Update</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 40px; color: #6c757d;">
                                No orders found. Try adjusting your filters.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php elseif ($action === 'view' && $order_details): ?>
                <!-- Order Details View -->
                <div class="page-header">
                    <h2 class="page-title">Order #<?php echo e($order_details['order_number']); ?></h2>
                    <a href="orders.php" class="btn btn-secondary">Back to Orders</a>
                </div>

                <div class="order-details">
                    <div class="order-main">
                        <!-- Order Information -->
                        <div class="details-card">
                            <div class="details-header">📋 Order Information</div>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Order Number</div>
                                    <div class="info-value"><?php echo e($order_details['order_number']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Order Type</div>
                                    <div class="info-value">
                                        <?php echo $order_details['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Current Status</div>
                                    <div class="info-value">
                                        <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $order_details['status_name'])); ?>">
                                            <?php echo e($order_details['status_name']); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Total Amount</div>
                                    <div class="info-value"><?php echo formatPrice($order_details['total_amount']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Payment Method</div>
                                    <div class="info-value"><?php echo ucfirst(str_replace('_', ' ', $order_details['payment_method'])); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Payment Status</div>
                                    <div class="info-value" style="color: <?php echo $order_details['payment_status'] === 'completed' ? '#28a745' : '#ffc107'; ?>;">
                                        <?php echo ucfirst($order_details['payment_status']); ?>
                                    </div>
                                </div>
                            </div>

                            <?php if ($order_details['order_type'] === 'delivery'): ?>
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>📍 Delivery Address:</strong><br>
                                <?php echo e($order_details['delivery_address']); ?><br>
                                <?php echo e($order_details['delivery_city'] . ', ' . $order_details['delivery_state'] . ' ' . $order_details['delivery_postal_code']); ?>
                            </div>
                            <?php else: ?>
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>🏪 Pickup Location:</strong><br>
                                <?php echo e($order_details['store_name']); ?><br>
                                <?php echo e($order_details['store_address'] . ', ' . $order_details['store_city']); ?>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($order_details['special_instructions'])): ?>
                            <div style="background: #fff3cd; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>📝 Special Instructions:</strong><br>
                                <?php echo e($order_details['special_instructions']); ?>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Customer Information -->
                        <div class="details-card">
                            <div class="details-header">👤 Customer Information</div>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Name</div>
                                    <div class="info-value"><?php echo e($order_details['first_name'] . ' ' . $order_details['last_name']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Email</div>
                                    <div class="info-value"><?php echo e($order_details['email']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Phone</div>
                                    <div class="info-value"><?php echo e($order_details['phone']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Order Date</div>
                                    <div class="info-value"><?php echo date('M j, Y g:i A', strtotime($order_details['created_at'])); ?></div>
                                </div>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <div class="details-card">
                            <div class="details-header">🍕 Order Items</div>
                            
                            <?php foreach ($order_items as $item): ?>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #f8f9fa;">
                                <div>
                                    <strong><?php echo e($item['item_name']); ?></strong>
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        <span style="background: #17a2b8; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-left: 5px;">CUSTOM</span>
                                    <?php endif; ?>
                                    <div style="font-size: 0.9rem; color: #6c757d; margin-top: 3px;">
                                        Quantity: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['unit_price']); ?>
                                    </div>
                                </div>
                                <div style="font-weight: 600; color: var(--admin-primary);">
                                    <?php echo formatPrice($item['total_price']); ?>
                                </div>
                            </div>
                            <?php endforeach; ?>

                            <div style="margin-top: 20px; padding-top: 15px; border-top: 2px solid #f8f9fa;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Subtotal:</span>
                                    <span><?php echo formatPrice($order_details['subtotal']); ?></span>
                                </div>
                                <?php if ($order_details['delivery_fee'] > 0): ?>
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Delivery Fee:</span>
                                    <span><?php echo formatPrice($order_details['delivery_fee']); ?></span>
                                </div>
                                <?php endif; ?>
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <span>Tax (GST):</span>
                                    <span><?php echo formatPrice($order_details['tax_amount']); ?></span>
                                </div>
                                <div style="display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: 700; color: var(--admin-primary); border-top: 1px solid #ddd; padding-top: 10px;">
                                    <span>Total:</span>
                                    <span><?php echo formatPrice($order_details['total_amount']); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="order-sidebar">
                        <!-- Status Update -->
                        <div class="details-card">
                            <div class="details-header">⚡ Update Status</div>
                            
                            <form method="POST" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="order_id" value="<?php echo $order_details['order_id']; ?>">
                                
                                <div class="form-group">
                                    <label class="form-label">New Status</label>
                                    <select name="new_status" class="form-select" required>
                                        <?php foreach ($order_statuses as $status): ?>
                                        <option value="<?php echo $status['status_id']; ?>" 
                                                <?php echo $status['status_id'] == $order_details['order_status_id'] ? 'selected' : ''; ?>>
                                            <?php echo e($status['status_name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">Admin Notes</label>
                                    <textarea name="admin_notes" class="form-textarea" 
                                              placeholder="Add notes about this status change..."></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary" style="width: 100%;">
                                    Update Status
                                </button>
                            </form>
                        </div>

                        <!-- Order Timeline -->
                        <div class="details-card">
                            <div class="details-header">📅 Order Timeline</div>
                            
                            <div class="order-timeline">
                                <?php foreach ($order_history as $history): ?>
                                <div class="timeline-item">
                                    <div class="timeline-icon">
                                        <?php
                                        switch ($history['status_id']) {
                                            case ORDER_STATUS_PENDING: echo '📝'; break;
                                            case ORDER_STATUS_PREPARING: echo '👨‍🍳'; break;
                                            case ORDER_STATUS_READY: echo '✅'; break;
                                            case ORDER_STATUS_OUT_FOR_DELIVERY: echo '🚚'; break;
                                            case ORDER_STATUS_DELIVERED: echo '🎉'; break;
                                            case ORDER_STATUS_PICKED_UP: echo '🎉'; break;
                                            case ORDER_STATUS_CANCELLED: echo '❌'; break;
                                            default: echo '📋'; break;
                                        }
                                        ?>
                                    </div>
                                    <div class="timeline-content">
                                        <div class="timeline-title"><?php echo e($history['status_name']); ?></div>
                                        <div class="timeline-time"><?php echo date('M j, Y g:i A', strtotime($history['created_at'])); ?></div>
                                        <div style="font-size: 0.85rem; color: #6c757d; margin-bottom: 5px;">
                                            <?php echo e($history['changed_by_name']); ?>
                                        </div>
                                        <?php if (!empty($history['notes'])): ?>
                                        <div class="timeline-notes"><?php echo e($history['notes']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php elseif ($action === 'add'): ?>
                <!-- Add Manual Order Form -->
                <div class="page-header">
                    <h2 class="page-title">Add Manual Order</h2>
                    <a href="orders.php" class="btn btn-secondary">Back to Orders</a>
                </div>

                <div class="form-container">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="add_order">

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Customer *</label>
                                <select name="customer_id" class="form-select" required>
                                    <option value="">Select Customer</option>
                                    <?php foreach ($customers as $customer): ?>
                                    <option value="<?php echo $customer['customer_id']; ?>">
                                        <?php echo e($customer['first_name'] . ' ' . $customer['last_name'] . ' (' . $customer['email'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Location *</label>
                                <select name="location_id" class="form-select" required>
                                    <option value="">Select Location</option>
                                    <?php foreach ($locations as $location): ?>
                                    <option value="<?php echo $location['location_id']; ?>">
                                        <?php echo e($location['store_name'] . ' (' . $location['city'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Order Type *</label>
                                <select name="order_type" class="form-select" required>
                                    <option value="delivery">Delivery</option>
                                    <option value="pickup">Pickup</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Total Amount (AUD) *</label>
                                <input type="number" name="total_amount" class="form-input" step="0.01" min="0" required
                                       placeholder="0.00">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Payment Method *</label>
                                <select name="payment_method" class="form-select" required>
                                    <option value="credit_card">Credit Card</option>
                                    <option value="debit_card">Debit Card</option>
                                    <option value="internet_banking">Internet Banking</option>
                                    <option value="cash_on_delivery">Cash on Delivery</option>
                                </select>
                            </div>
                        </div>

                        <div style="margin-top: 30px;">
                            <button type="submit" class="btn btn-primary">Create Order</button>
                            <a href="orders.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>

                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Quick Status Update Modal -->
    <div id="statusModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 400px; width: 90%;">
            <h3 style="margin-bottom: 20px; color: var(--admin-primary);">Update Order Status</h3>
            <form method="POST" id="statusUpdateForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="order_id" id="modalOrderId">
                
                <div class="form-group">
                    <label class="form-label">New Status</label>
                    <select name="new_status" class="form-select" id="modalStatus" required>
                        <?php foreach ($order_statuses as $status): ?>
                        <option value="<?php echo $status['status_id']; ?>">
                            <?php echo e($status['status_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Notes</label>
                    <textarea name="admin_notes" class="form-textarea" placeholder="Optional notes..."></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeStatusModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Status</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const status = document.getElementById('statusFilter').value;
        const type = document.getElementById('typeFilter').value;
        const date = document.getElementById('dateFilter').value;
        
        let url = 'orders.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (status) params.push('status=' + encodeURIComponent(status));
        if (type) params.push('type=' + encodeURIComponent(type));
        if (date) params.push('date=' + encodeURIComponent(date));
        
        window.location.href = url + params.join('&');
    }

    function quickStatusUpdate(orderId, currentStatus) {
        document.getElementById('modalOrderId').value = orderId;
        
        // Set next logical status
        let nextStatus = currentStatus + 1;
        if (nextStatus > <?php echo ORDER_STATUS_DELIVERED; ?>) {
            nextStatus = <?php echo ORDER_STATUS_DELIVERED; ?>;
        }
        
        document.getElementById('modalStatus').value = nextStatus;
        document.getElementById('statusModal').style.display = 'block';
    }

    function closeStatusModal() {
        document.getElementById('statusModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('statusModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeStatusModal();
        }
    });

    // Auto-search on Enter
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Auto-refresh every 30 seconds for orders list
    <?php if ($action === 'list'): ?>
    setInterval(function() {
        if (!document.hidden) {
            // Only refresh if no modals are open
            if (!document.getElementById('statusModal').style.display || 
                document.getElementById('statusModal').style.display === 'none') {
                location.reload();
            }
        }
    }, 30000);
    <?php endif; ?>

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);

    // Form validation for manual order creation
    <?php if ($action === 'add'): ?>
    document.querySelector('form').addEventListener('submit', function(e) {
        const customer = document.querySelector('select[name="customer_id"]').value;
        const location = document.querySelector('select[name="location_id"]').value;
        const amount = document.querySelector('input[name="total_amount"]').value;
        
        if (!customer || !location || !amount || parseFloat(amount) <= 0) {
            e.preventDefault();
            alert('Please fill in all required fields with valid values.');
        }
    });
    <?php endif; ?>

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Press 'R' to refresh
        if (e.key === 'r' || e.key === 'R') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                location.reload();
            }
        }
        
        // Press 'F' to focus search
        if (e.key === 'f' || e.key === 'F') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
        }
    });
    </script>
</body>
</html>