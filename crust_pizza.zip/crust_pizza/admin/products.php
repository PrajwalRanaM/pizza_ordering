<?php
// admin/products.php - Products Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$action = $_GET['action'] ?? 'list';
$product_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        if ($form_action === 'add' || $form_action === 'edit') {
            // Validate and process product data
            $product_name = sanitizeInput($_POST['product_name'] ?? '');
            $description = sanitizeInput($_POST['description'] ?? '');
            $category_id = (int)($_POST['category_id'] ?? 0);
            $base_price = (float)($_POST['base_price'] ?? 0);
            $image_url = sanitizeInput($_POST['image_url'] ?? '');
            $is_customizable = isset($_POST['is_customizable']) ? 1 : 0;
            $is_vegetarian = isset($_POST['is_vegetarian']) ? 1 : 0;
            $is_vegan = isset($_POST['is_vegan']) ? 1 : 0;
            $is_gluten_free = isset($_POST['is_gluten_free']) ? 1 : 0;
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Validation
            $errors = [];
            if (empty($product_name)) $errors[] = 'Product name is required.';
            if (empty($description)) $errors[] = 'Description is required.';
            if ($category_id <= 0) $errors[] = 'Please select a category.';
            if ($base_price <= 0) $errors[] = 'Base price must be greater than 0.';
            
            if (empty($errors)) {
                try {
                    if ($form_action === 'add') {
                        // Add new product
                        $stmt = $conn->prepare("
                            INSERT INTO products (product_name, description, category_id, base_price, 
                                                image_url, is_customizable, is_vegetarian, is_vegan, 
                                                is_gluten_free, is_active, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                        ");
                        $stmt->bind_param("ssiisiiiii", $product_name, $description, $category_id, 
                                        $base_price, $image_url, $is_customizable, $is_vegetarian, 
                                        $is_vegan, $is_gluten_free, $is_active);
                        
                        if ($stmt->execute()) {
                            $new_product_id = $conn->insert_id;
                            
                            // Handle ingredients if provided
                            if (!empty($_POST['ingredients'])) {
                                $ingredients = $_POST['ingredients'];
                                foreach ($ingredients as $ingredient_id) {
                                    $ing_stmt = $conn->prepare("
                                        INSERT INTO product_ingredients (product_id, ingredient_id, quantity)
                                        VALUES (?, ?, 1)
                                    ");
                                    $ing_stmt->bind_param("ii", $new_product_id, $ingredient_id);
                                    $ing_stmt->execute();
                                }
                            }
                            
                            $message = 'Product added successfully!';
                            $action = 'list';
                        } else {
                            $error = 'Failed to add product. Please try again.';
                        }
                    } else {
                        // Edit existing product
                        $edit_id = (int)($_POST['product_id'] ?? 0);
                        if ($edit_id > 0) {
                            $stmt = $conn->prepare("
                                UPDATE products 
                                SET product_name = ?, description = ?, category_id = ?, base_price = ?, 
                                    image_url = ?, is_customizable = ?, is_vegetarian = ?, is_vegan = ?, 
                                    is_gluten_free = ?, is_active = ?, updated_at = NOW()
                                WHERE product_id = ?
                            ");
                            $stmt->bind_param("ssiisiiiiii", $product_name, $description, $category_id, 
                                            $base_price, $image_url, $is_customizable, $is_vegetarian, 
                                            $is_vegan, $is_gluten_free, $is_active, $edit_id);
                            
                            if ($stmt->execute()) {
                                // Update ingredients
                                $conn->query("DELETE FROM product_ingredients WHERE product_id = $edit_id");
                                
                                if (!empty($_POST['ingredients'])) {
                                    $ingredients = $_POST['ingredients'];
                                    foreach ($ingredients as $ingredient_id) {
                                        $ing_stmt = $conn->prepare("
                                            INSERT INTO product_ingredients (product_id, ingredient_id, quantity)
                                            VALUES (?, ?, 1)
                                        ");
                                        $ing_stmt->bind_param("ii", $edit_id, $ingredient_id);
                                        $ing_stmt->execute();
                                    }
                                }
                                
                                $message = 'Product updated successfully!';
                                $action = 'list';
                            } else {
                                $error = 'Failed to update product. Please try again.';
                            }
                        }
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            } else {
                $error = implode('<br>', $errors);
            }
        } elseif ($form_action === 'delete') {
            $delete_id = (int)($_POST['product_id'] ?? 0);
            if ($delete_id > 0) {
                try {
                    // Soft delete - just mark as inactive
                    $stmt = $conn->prepare("UPDATE products SET is_active = 0 WHERE product_id = ?");
                    $stmt->bind_param("i", $delete_id);
                    
                    if ($stmt->execute()) {
                        $message = 'Product deleted successfully!';
                    } else {
                        $error = 'Failed to delete product. Please try again.';
                    }
                } catch (Exception $e) {
                    $error = 'Database error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Get product categories
$categories = [];
try {
    $result = $conn->query("SELECT * FROM product_categories WHERE is_active = 1 ORDER BY category_name");
    $categories = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Categories fetch error: ' . $e->getMessage());
}

// Get ingredients for product form
$ingredients = [];
try {
    $result = $conn->query("SELECT * FROM ingredients WHERE is_active = 1 ORDER BY category, ingredient_name");
    $ingredients = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Ingredients fetch error: ' . $e->getMessage());
}

// Get product data for editing
$product_data = null;
$selected_ingredients = [];
if ($action === 'edit' && $product_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product_data = $stmt->get_result()->fetch_assoc();
        
        if ($product_data) {
            // Get selected ingredients
            $ing_stmt = $conn->prepare("SELECT ingredient_id FROM product_ingredients WHERE product_id = ?");
            $ing_stmt->bind_param("i", $product_id);
            $ing_stmt->execute();
            $ing_result = $ing_stmt->get_result();
            while ($row = $ing_result->fetch_assoc()) {
                $selected_ingredients[] = $row['ingredient_id'];
            }
        }
    } catch (Exception $e) {
        $error = 'Failed to load product data.';
    }
}

// Get products list
$products = [];
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$status_filter = $_GET['status'] ?? '';

if ($action === 'list') {
    try {
        $sql = "
            SELECT p.*, pc.category_name 
            FROM products p
            JOIN product_categories pc ON p.category_id = pc.category_id
            WHERE 1=1
        ";
        $params = [];
        $types = '';
        
        if (!empty($search)) {
            $sql .= " AND (p.product_name LIKE ? OR p.description LIKE ?)";
            $search_param = "%$search%";
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'ss';
        }
        
        if (!empty($category_filter)) {
            $sql .= " AND p.category_id = ?";
            $params[] = $category_filter;
            $types .= 'i';
        }
        
        if ($status_filter !== '') {
            $sql .= " AND p.is_active = ?";
            $params[] = (int)$status_filter;
            $types .= 'i';
        }
        
        $sql .= " ORDER BY p.product_name";
        
        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        $error = 'Failed to load products: ' . $e->getMessage();
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/products.css">
    
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link active">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">
                    <?php 
                    switch($action) {
                        case 'add': echo 'Add New Product'; break;
                        case 'edit': echo 'Edit Product'; break;
                        default: echo 'Products Management'; break;
                    }
                    ?>
                </h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                <!-- Products List View -->
                <div class="page-header">
                    <h2 class="page-title">Products</h2>
                    <a href="products.php?action=add" class="btn btn-primary">Add New Product</a>
                </div>

                <!-- Filters -->
                <div class="filters">
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-input" placeholder="Search products..." 
                               value="<?php echo e($search); ?>" id="searchInput">
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Category</label>
                        <select class="form-select" id="categoryFilter">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['category_id']; ?>" 
                                    <?php echo $category_filter == $category['category_id'] ? 'selected' : ''; ?>>
                                <?php echo e($category['category_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button class="btn btn-primary" onclick="applyFilters()">Filter</button>
                        <a href="products.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>

                <!-- Products Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Base Price</th>
                            <th>Status</th>
                            <th>Dietary</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($products)): ?>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo $product['product_id']; ?></td>
                            <td>
                                <strong><?php echo e($product['product_name']); ?></strong>
                                <br>
                                <small style="color: #6c757d;">
                                    <?php echo e(substr($product['description'], 0, 50)) . (strlen($product['description']) > 50 ? '...' : ''); ?>
                                </small>
                            </td>
                            <td><?php echo e($product['category_name']); ?></td>
                            <td><strong><?php echo formatPrice($product['base_price']); ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo $product['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $product['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($product['is_vegetarian']): ?><span style="background: #28a745; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-right: 3px;">VEG</span><?php endif; ?>
                                <?php if ($product['is_vegan']): ?><span style="background: #6f42c1; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-right: 3px;">VEGAN</span><?php endif; ?>
                                <?php if ($product['is_gluten_free']): ?><span style="background: #fd7e14; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px;">GF</span><?php endif; ?>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($product['created_at'])); ?></td>
                            <td>
                                <a href="products.php?action=edit&id=<?php echo $product['product_id']; ?>" 
                                   class="btn btn-primary btn-sm">Edit</a>
                                <button onclick="deleteProduct(<?php echo $product['product_id']; ?>)" 
                                        class="btn btn-danger btn-sm">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #6c757d;">
                                No products found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Add/Edit Product Form -->
                <div class="page-header">
                    <h2 class="page-title"><?php echo $action === 'add' ? 'Add New Product' : 'Edit Product'; ?></h2>
                    <a href="products.php" class="btn btn-secondary">Back to Products</a>
                </div>

                <div class="form-container">
                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="<?php echo $action; ?>">
                        <?php if ($action === 'edit'): ?>
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        <?php endif; ?>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Product Name *</label>
                                <input type="text" name="product_name" class="form-input" required
                                       value="<?php echo e($product_data['product_name'] ?? ''); ?>"
                                       placeholder="Enter product name">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Category *</label>
                                <select name="category_id" class="form-select" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['category_id']; ?>"
                                            <?php echo ($product_data['category_id'] ?? '') == $category['category_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($category['category_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Base Price * (AUD)</label>
                                <input type="number" name="base_price" class="form-input" step="0.01" min="0" required
                                       value="<?php echo $product_data['base_price'] ?? ''; ?>"
                                       placeholder="0.00">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Image URL</label>
                                <input type="url" name="image_url" class="form-input"
                                       value="<?php echo e($product_data['image_url'] ?? ''); ?>"
                                       placeholder="https://example.com/image.jpg">
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Description *</label>
                                <textarea name="description" class="form-textarea" required
                                          placeholder="Enter product description"><?php echo e($product_data['description'] ?? ''); ?></textarea>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Product Options</label>
                                <div class="checkbox-group">
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_customizable" id="is_customizable"
                                               <?php echo ($product_data['is_customizable'] ?? 0) ? 'checked' : ''; ?>>
                                        <label for="is_customizable">Customizable</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_vegetarian" id="is_vegetarian"
                                               <?php echo ($product_data['is_vegetarian'] ?? 0) ? 'checked' : ''; ?>>
                                        <label for="is_vegetarian">Vegetarian</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_vegan" id="is_vegan"
                                               <?php echo ($product_data['is_vegan'] ?? 0) ? 'checked' : ''; ?>>
                                        <label for="is_vegan">Vegan</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_gluten_free" id="is_gluten_free"
                                               <?php echo ($product_data['is_gluten_free'] ?? 0) ? 'checked' : ''; ?>>
                                        <label for="is_gluten_free">Gluten Free</label>
                                    </div>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="is_active" id="is_active"
                                               <?php echo ($product_data['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                        <label for="is_active">Active</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group full-width">
                                <label class="form-label">Ingredients (for pizzas)</label>
                                <div class="ingredients-grid">
                                    <?php foreach ($ingredients as $ingredient): ?>
                                    <div class="checkbox-item">
                                        <input type="checkbox" name="ingredients[]" 
                                               value="<?php echo $ingredient['ingredient_id']; ?>"
                                               id="ingredient_<?php echo $ingredient['ingredient_id']; ?>"
                                               <?php echo in_array($ingredient['ingredient_id'], $selected_ingredients) ? 'checked' : ''; ?>>
                                        <label for="ingredient_<?php echo $ingredient['ingredient_id']; ?>">
                                            <?php echo e($ingredient['ingredient_name']); ?>
                                            <small>(<?php echo formatPrice($ingredient['price']); ?>)</small>
                                        </label>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 30px;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $action === 'add' ? 'Add Product' : 'Update Product'; ?>
                            </button>
                            <a href="products.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000;">
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 30px; border-radius: 8px; max-width: 400px; width: 90%;">
            <h3 style="margin-bottom: 15px; color: var(--admin-danger);">Confirm Delete</h3>
            <p style="margin-bottom: 20px;">Are you sure you want to delete this product? This action cannot be undone.</p>
            <form method="POST" id="deleteForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="product_id" id="deleteProductId">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Product</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function applyFilters() {
        const search = document.getElementById('searchInput').value;
        const category = document.getElementById('categoryFilter').value;
        const status = document.getElementById('statusFilter').value;
        
        let url = 'products.php?';
        const params = [];
        
        if (search) params.push('search=' + encodeURIComponent(search));
        if (category) params.push('category=' + encodeURIComponent(category));
        if (status !== '') params.push('status=' + encodeURIComponent(status));
        
        window.location.href = url + params.join('&');
    }

    function deleteProduct(productId) {
        document.getElementById('deleteProductId').value = productId;
        document.getElementById('deleteModal').style.display = 'block';
    }

    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('deleteModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDeleteModal();
        }
    });

    // Auto-search on Enter
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            applyFilters();
        }
    });

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);
    </script>
</body>
</html>