<?php
// admin/reports.php - Reports and Analytics
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$report_type = $_GET['type'] ?? 'sales';
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$date_to = $_GET['date_to'] ?? date('Y-m-d'); // Today
$location_filter = $_GET['location'] ?? '';

// Get locations for filter
$locations = [];
try {
    $result = $conn->query("SELECT location_id, store_name, city FROM locations WHERE is_active = 1 ORDER BY store_name");
    $locations = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Locations fetch error: ' . $e->getMessage());
}

// Generate reports based on type
$report_data = [];
$chart_data = [];
$summary_stats = [];

try {
    switch ($report_type) {
        case 'sales':
            $report_data = generateSalesReport($conn, $date_from, $date_to, $location_filter);
            break;
        case 'orders':
            $report_data = generateOrdersReport($conn, $date_from, $date_to, $location_filter);
            break;
        case 'products':
            $report_data = generateProductsReport($conn, $date_from, $date_to, $location_filter);
            break;
        case 'customers':
            $report_data = generateCustomersReport($conn, $date_from, $date_to, $location_filter);
            break;
        default:
            $report_data = generateSalesReport($conn, $date_from, $date_to, $location_filter);
    }
} catch (Exception $e) {
    $error = 'Failed to generate report: ' . $e->getMessage();
    logError('Report generation error: ' . $e->getMessage());
}

// Report generation functions
function generateSalesReport($conn, $date_from, $date_to, $location_filter) {
    $report = ['data' => [], 'summary' => [], 'chart' => []];
    
    try {
        // Build query
        $sql = "
            SELECT 
                DATE(o.created_at) as order_date,
                l.store_name,
                l.city,
                COUNT(o.order_id) as order_count,
                SUM(o.total_amount) as revenue,
                AVG(o.total_amount) as avg_order_value,
                SUM(CASE WHEN o.order_type = 'delivery' THEN 1 ELSE 0 END) as delivery_orders,
                SUM(CASE WHEN o.order_type = 'pickup' THEN 1 ELSE 0 END) as pickup_orders
            FROM orders o
            JOIN locations l ON o.location_id = l.location_id
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $params = [$date_from, $date_to];
        $types = 'ss';
        
        if (!empty($location_filter)) {
            $sql .= " AND o.location_id = ?";
            $params[] = $location_filter;
            $types .= 'i';
        }
        
        $sql .= " GROUP BY DATE(o.created_at), o.location_id ORDER BY order_date DESC, l.store_name";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $report['data'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Generate summary statistics
        $summary_sql = "
            SELECT 
                COUNT(o.order_id) as total_orders,
                SUM(o.total_amount) as total_revenue,
                AVG(o.total_amount) as avg_order_value,
                COUNT(DISTINCT o.customer_id) as unique_customers,
                SUM(CASE WHEN o.order_type = 'delivery' THEN 1 ELSE 0 END) as delivery_orders,
                SUM(CASE WHEN o.order_type = 'pickup' THEN 1 ELSE 0 END) as pickup_orders
            FROM orders o
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $summary_params = [$date_from, $date_to];
        $summary_types = 'ss';
        
        if (!empty($location_filter)) {
            $summary_sql .= " AND o.location_id = ?";
            $summary_params[] = $location_filter;
            $summary_types .= 'i';
        }
        
        $stmt = $conn->prepare($summary_sql);
        if ($stmt === false) {
            throw new Exception("Summary prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($summary_types, ...$summary_params);
        $stmt->execute();
        $report['summary'] = $stmt->get_result()->fetch_assoc();
        
        // Chart data for daily revenue
        $chart_sql = "
            SELECT 
                DATE(created_at) as date,
                SUM(total_amount) as revenue,
                COUNT(order_id) as orders
            FROM orders
            WHERE payment_status = 'completed'
            AND DATE(created_at) BETWEEN ? AND ?
        ";
        
        if (!empty($location_filter)) {
            $chart_sql .= " AND location_id = ?";
        }
        
        $chart_sql .= " GROUP BY DATE(created_at) ORDER BY date";
        
        $stmt = $conn->prepare($chart_sql);
        if ($stmt !== false) {
            $stmt->bind_param($summary_types, ...$summary_params);
            $stmt->execute();
            $report['chart'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        }
        
    } catch (Exception $e) {
        logError('Sales report error: ' . $e->getMessage());
        // Return empty report on error
        $report['summary'] = [
            'total_orders' => 0,
            'total_revenue' => 0,
            'avg_order_value' => 0,
            'unique_customers' => 0,
            'delivery_orders' => 0,
            'pickup_orders' => 0
        ];
    }
    
    return $report;
}

function generateOrdersReport($conn, $date_from, $date_to, $location_filter) {
    $report = ['data' => [], 'summary' => [], 'chart' => []];
    
    try {
        // Orders by status
        $sql = "
            SELECT 
                os.status_name,
                COUNT(o.order_id) as order_count,
                ROUND((COUNT(o.order_id) * 100.0 / (
                    SELECT COUNT(*) 
                    FROM orders 
                    WHERE DATE(created_at) BETWEEN ? AND ?" . 
                    (!empty($location_filter) ? " AND location_id = ?" : "") . "
                )), 2) as percentage
            FROM orders o
            JOIN order_statuses os ON o.order_status_id = os.status_id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $params = [$date_from, $date_to];
        if (!empty($location_filter)) {
            $params[] = $location_filter;
        }
        $params = array_merge($params, [$date_from, $date_to]);
        
        $types = 'ss';
        if (!empty($location_filter)) {
            $types .= 'i';
        }
        $types .= 'ss';
        
        if (!empty($location_filter)) {
            $sql .= " AND o.location_id = ?";
            $params[] = $location_filter;
            $types .= 'i';
        }
        
        $sql .= " GROUP BY o.order_status_id, os.status_name ORDER BY order_count DESC";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $report['data'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Summary stats
        $summary_sql = "
            SELECT 
                COUNT(o.order_id) as total_orders,
                AVG(TIMESTAMPDIFF(MINUTE, o.created_at, o.updated_at)) as avg_processing_time,
                SUM(CASE WHEN o.order_status_id = ? THEN 1 ELSE 0 END) as delivered_orders,
                SUM(CASE WHEN o.order_status_id = ? THEN 1 ELSE 0 END) as cancelled_orders
            FROM orders o
            WHERE DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $summary_params = [ORDER_STATUS_DELIVERED, ORDER_STATUS_CANCELLED, $date_from, $date_to];
        $summary_types = 'iiss';
        
        if (!empty($location_filter)) {
            $summary_sql .= " AND o.location_id = ?";
            $summary_params[] = $location_filter;
            $summary_types .= 'i';
        }
        
        $stmt = $conn->prepare($summary_sql);
        if ($stmt === false) {
            throw new Exception("Summary prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($summary_types, ...$summary_params);
        $stmt->execute();
        $report['summary'] = $stmt->get_result()->fetch_assoc();
        
    } catch (Exception $e) {
        logError('Orders report error: ' . $e->getMessage());
        // Return empty report on error
        $report['summary'] = [
            'total_orders' => 0,
            'avg_processing_time' => 0,
            'delivered_orders' => 0,
            'cancelled_orders' => 0
        ];
    }
    
    return $report;
}

function generateProductsReport($conn, $date_from, $date_to, $location_filter) {
    $report = ['data' => [], 'summary' => [], 'chart' => []];
    
    try {
        // Top selling products
        $sql = "
            SELECT 
                oi.item_name,
                oi.item_type,
                COUNT(oi.order_item_id) as order_count,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.total_price) as total_revenue,
                AVG(oi.unit_price) as avg_price
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $params = [$date_from, $date_to];
        $types = 'ss';
        
        if (!empty($location_filter)) {
            $sql .= " AND o.location_id = ?";
            $params[] = $location_filter;
            $types .= 'i';
        }
        
        $sql .= " GROUP BY oi.item_name, oi.item_type ORDER BY total_quantity DESC LIMIT 20";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $report['data'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Summary stats
        $summary_sql = "
            SELECT 
                COUNT(DISTINCT oi.item_name) as unique_products,
                SUM(oi.quantity) as total_items_sold,
                SUM(oi.total_price) as total_product_revenue,
                AVG(oi.unit_price) as avg_product_price
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        if (!empty($location_filter)) {
            $summary_sql .= " AND o.location_id = ?";
        }
        
        $stmt = $conn->prepare($summary_sql);
        if ($stmt === false) {
            throw new Exception("Summary prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $report['summary'] = $stmt->get_result()->fetch_assoc();
        
    } catch (Exception $e) {
        logError('Products report error: ' . $e->getMessage());
        // Return empty report on error
        $report['summary'] = [
            'unique_products' => 0,
            'total_items_sold' => 0,
            'total_product_revenue' => 0,
            'avg_product_price' => 0
        ];
    }
    
    return $report;
}

function generateCustomersReport($conn, $date_from, $date_to, $location_filter) {
    $report = ['data' => [], 'summary' => [], 'chart' => []];
    
    try {
        // Customer analysis
        $sql = "
            SELECT 
                c.customer_id,
                c.first_name,
                c.last_name,
                c.email,
                c.city,
                COUNT(o.order_id) as order_count,
                SUM(o.total_amount) as total_spent,
                AVG(o.total_amount) as avg_order_value,
                MAX(o.created_at) as last_order_date,
                MIN(o.created_at) as first_order_date
            FROM customers c
            JOIN orders o ON c.customer_id = o.customer_id
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $params = [$date_from, $date_to];
        $types = 'ss';
        
        if (!empty($location_filter)) {
            $sql .= " AND o.location_id = ?";
            $params[] = $location_filter;
            $types .= 'i';
        }
        
        $sql .= " GROUP BY c.customer_id ORDER BY total_spent DESC LIMIT 50";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $report['data'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Summary stats - simplified query to avoid subquery issues
        $summary_sql = "
            SELECT 
                COUNT(DISTINCT o.customer_id) as total_customers,
                COUNT(DISTINCT CASE WHEN o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN o.customer_id END) as active_customers
            FROM orders o
            WHERE o.payment_status = 'completed'
            AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $summary_params = [$date_from, $date_to];
        $summary_types = 'ss';
        
        if (!empty($location_filter)) {
            $summary_sql .= " AND o.location_id = ?";
            $summary_params[] = $location_filter;
            $summary_types .= 'i';
        }
        
        $stmt = $conn->prepare($summary_sql);
        if ($stmt === false) {
            throw new Exception("Summary prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param($summary_types, ...$summary_params);
        $stmt->execute();
        $summary_result = $stmt->get_result()->fetch_assoc();
        
        // Calculate additional metrics separately
        $avg_sql = "
            SELECT 
                AVG(order_count) as avg_orders_per_customer,
                AVG(total_spent) as avg_customer_value
            FROM (
                SELECT 
                    COUNT(o.order_id) as order_count,
                    SUM(o.total_amount) as total_spent
                FROM orders o
                WHERE o.payment_status = 'completed'
                AND DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        if (!empty($location_filter)) {
            $avg_sql .= " AND o.location_id = ?";
        }
        
        $avg_sql .= " GROUP BY o.customer_id) as customer_stats";
        
        $stmt = $conn->prepare($avg_sql);
        if ($stmt !== false) {
            $stmt->bind_param($summary_types, ...$summary_params);
            $stmt->execute();
            $avg_result = $stmt->get_result()->fetch_assoc();
            
            // Merge results
            $report['summary'] = array_merge($summary_result, $avg_result ?: []);
        } else {
            $report['summary'] = $summary_result;
            $report['summary']['avg_orders_per_customer'] = 0;
            $report['summary']['avg_customer_value'] = 0;
        }
        
    } catch (Exception $e) {
        logError('Customer report error: ' . $e->getMessage());
        // Return empty report on error
        $report['summary'] = [
            'total_customers' => 0,
            'active_customers' => 0,
            'avg_orders_per_customer' => 0,
            'avg_customer_value' => 0
        ];
    }
    
    return $report;
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <link rel="stylesheet" href="css/reports.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link active">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">Reports & Analytics</h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="alert alert-success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <!-- Report Controls -->
                <div class="report-header">
                    <!-- Report Type Tabs -->
                    <div class="report-tabs">
                        <a href="reports.php?type=sales&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&location=<?php echo $location_filter; ?>" 
                           class="report-tab <?php echo $report_type === 'sales' ? 'active' : ''; ?>">
                            📊 Sales Report
                        </a>
                        <a href="reports.php?type=orders&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&location=<?php echo $location_filter; ?>" 
                           class="report-tab <?php echo $report_type === 'orders' ? 'active' : ''; ?>">
                            📋 Orders Report
                        </a>
                        <a href="reports.php?type=products&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&location=<?php echo $location_filter; ?>" 
                           class="report-tab <?php echo $report_type === 'products' ? 'active' : ''; ?>">
                            🍕 Products Report
                        </a>
                        <a href="reports.php?type=customers&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&location=<?php echo $location_filter; ?>" 
                           class="report-tab <?php echo $report_type === 'customers' ? 'active' : ''; ?>">
                            👥 Customers Report
                        </a>
                    </div>

                    <!-- Filters -->
                    <form method="GET" action="reports.php">
                        <input type="hidden" name="type" value="<?php echo $report_type; ?>">
                        
                        <div class="filters-container">
                            <div class="filter-group">
                                <label class="form-label">Date From</label>
                                <input type="date" name="date_from" class="form-input" 
                                       value="<?php echo $date_from; ?>" required>
                            </div>
                            
                            <div class="filter-group">
                                <label class="form-label">Date To</label>
                                <input type="date" name="date_to" class="form-input" 
                                       value="<?php echo $date_to; ?>" required>
                            </div>
                            
                            <div class="filter-group">
                                <label class="form-label">Location</label>
                                <select name="location" class="form-select">
                                    <option value="">All Locations</option>
                                    <?php foreach ($locations as $location): ?>
                                    <option value="<?php echo $location['location_id']; ?>" 
                                            <?php echo $location_filter == $location['location_id'] ? 'selected' : ''; ?>>
                                        <?php echo e($location['store_name'] . ' - ' . $location['city']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <button type="submit" class="btn btn-primary">Generate Report</button>
                            </div>
                        </div>
                    </form>
                </div>

                <?php if (!empty($report_data)): ?>

                <!-- Summary Cards -->
                <?php if (!empty($report_data['summary'])): ?>
                <div class="summary-cards">
                    <?php if ($report_type === 'sales'): ?>
                        <div class="summary-card success">
                            <div class="card-icon">💰</div>
                            <div class="card-value"><?php echo formatPrice($report_data['summary']['total_revenue'] ?? 0); ?></div>
                            <div class="card-label">Total Revenue</div>
                        </div>
                        <div class="summary-card">
                            <div class="card-icon">📋</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['total_orders'] ?? 0); ?></div>
                            <div class="card-label">Total Orders</div>
                        </div>
                        <div class="summary-card info">
                            <div class="card-icon">📊</div>
                            <div class="card-value"><?php echo formatPrice($report_data['summary']['avg_order_value'] ?? 0); ?></div>
                            <div class="card-label">Avg Order Value</div>
                        </div>
                        <div class="summary-card warning">
                            <div class="card-icon">👥</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['unique_customers'] ?? 0); ?></div>
                            <div class="card-label">Unique Customers</div>
                        </div>

                    <?php elseif ($report_type === 'orders'): ?>
                        <div class="summary-card">
                            <div class="card-icon">📋</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['total_orders'] ?? 0); ?></div>
                            <div class="card-label">Total Orders</div>
                        </div>
                        <div class="summary-card success">
                            <div class="card-icon">✅</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['delivered_orders'] ?? 0); ?></div>
                            <div class="card-label">Delivered Orders</div>
                        </div>
                        <div class="summary-card danger">
                            <div class="card-icon">❌</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['cancelled_orders'] ?? 0); ?></div>
                            <div class="card-label">Cancelled Orders</div>
                        </div>
                        <div class="summary-card info">
                            <div class="card-icon">⏱️</div>
                            <div class="card-value"><?php echo round($report_data['summary']['avg_processing_time'] ?? 0); ?> min</div>
                            <div class="card-label">Avg Processing Time</div>
                        </div>

                    <?php elseif ($report_type === 'products'): ?>
                        <div class="summary-card">
                            <div class="card-icon">🍕</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['unique_products'] ?? 0); ?></div>
                            <div class="card-label">Unique Products</div>
                        </div>
                        <div class="summary-card warning">
                            <div class="card-icon">📦</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['total_items_sold'] ?? 0); ?></div>
                            <div class="card-label">Items Sold</div>
                        </div>
                        <div class="summary-card success">
                            <div class="card-icon">💰</div>
                            <div class="card-value"><?php echo formatPrice($report_data['summary']['total_product_revenue'] ?? 0); ?></div>
                            <div class="card-label">Product Revenue</div>
                        </div>
                        <div class="summary-card info">
                            <div class="card-icon">📊</div>
                            <div class="card-value"><?php echo formatPrice($report_data['summary']['avg_product_price'] ?? 0); ?></div>
                            <div class="card-label">Avg Product Price</div>
                        </div>

                    <?php elseif ($report_type === 'customers'): ?>
                        <div class="summary-card">
                            <div class="card-icon">👥</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['total_customers'] ?? 0); ?></div>
                            <div class="card-label">Total Customers</div>
                        </div>
                        <div class="summary-card success">
                            <div class="card-icon">🔥</div>
                            <div class="card-value"><?php echo number_format($report_data['summary']['active_customers'] ?? 0); ?></div>
                            <div class="card-label">Active Customers</div>
                        </div>
                        <div class="summary-card info">
                            <div class="card-icon">📊</div>
                            <div class="card-value"><?php echo round($report_data['summary']['avg_orders_per_customer'] ?? 0, 1); ?></div>
                            <div class="card-label">Avg Orders/Customer</div>
                        </div>
                        <div class="summary-card warning">
                            <div class="card-icon">💰</div>
                            <div class="card-value"><?php echo formatPrice($report_data['summary']['avg_customer_value'] ?? 0); ?></div>
                            <div class="card-label">Avg Customer Value</div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Chart Section -->
                <?php if ($report_type === 'sales' && !empty($report_data['chart'])): ?>
                <div class="report-section">
                    <div class="section-header">
                        <h3 class="section-title">Daily Revenue Trend</h3>
                        <div class="export-buttons">
                            <button class="btn btn-secondary" onclick="exportChart()">Export Chart</button>
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Data Table Section -->
                <div class="report-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <?php 
                            switch($report_type) {
                                case 'sales': echo 'Sales Data by Day & Location'; break;
                                case 'orders': echo 'Orders by Status'; break;
                                case 'products': echo 'Top Selling Products'; break;
                                case 'customers': echo 'Top Customers'; break;
                            }
                            ?>
                        </h3>
                        <div class="export-buttons">
                            <button class="btn btn-success" onclick="exportToCSV()">Export CSV</button>
                            <button class="btn btn-secondary" onclick="printReport()">Print</button>
                        </div>
                    </div>

                    <?php if (!empty($report_data['data'])): ?>
                    <table class="data-table" id="reportTable">
                        <thead>
                            <tr>
                                <?php if ($report_type === 'sales'): ?>
                                    <th>Date</th>
                                    <th>Location</th>
                                    <th>Orders</th>
                                    <th>Revenue</th>
                                    <th>Avg Order Value</th>
                                    <th>Delivery</th>
                                    <th>Pickup</th>
                                <?php elseif ($report_type === 'orders'): ?>
                                    <th>Status</th>
                                    <th>Order Count</th>
                                    <th>Percentage</th>
                                    <th>Progress</th>
                                <?php elseif ($report_type === 'products'): ?>
                                    <th>Product Name</th>
                                    <th>Type</th>
                                    <th>Orders</th>
                                    <th>Quantity Sold</th>
                                    <th>Revenue</th>
                                    <th>Avg Price</th>
                                <?php elseif ($report_type === 'customers'): ?>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>City</th>
                                    <th>Orders</th>
                                    <th>Total Spent</th>
                                    <th>Avg Order</th>
                                    <th>Last Order</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($report_data['data'] as $row): ?>
                            <tr>
                                <?php if ($report_type === 'sales'): ?>
                                    <td><?php echo date('M j, Y', strtotime($row['order_date'])); ?></td>
                                    <td><?php echo e($row['store_name']); ?></td>
                                    <td class="font-weight-bold"><?php echo number_format($row['order_count']); ?></td>
                                    <td class="text-success font-weight-bold"><?php echo formatPrice($row['revenue']); ?></td>
                                    <td><?php echo formatPrice($row['avg_order_value']); ?></td>
                                    <td><?php echo number_format($row['delivery_orders']); ?></td>
                                    <td><?php echo number_format($row['pickup_orders']); ?></td>

                                <?php elseif ($report_type === 'orders'): ?>
                                    <td class="font-weight-bold"><?php echo e($row['status_name']); ?></td>
                                    <td><?php echo number_format($row['order_count']); ?></td>
                                    <td><?php echo $row['percentage']; ?>%</td>
                                    <td>
                                        <div class="percentage-bar">
                                            <div class="percentage-fill" style="width: <?php echo $row['percentage']; ?>%;"></div>
                                        </div>
                                    </td>

                                <?php elseif ($report_type === 'products'): ?>
                                    <td class="font-weight-bold"><?php echo e($row['item_name']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $row['item_type'] === 'custom' ? 'badge-info' : 'badge-primary'; ?>">
                                            <?php echo ucfirst($row['item_type']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo number_format($row['order_count']); ?></td>
                                    <td class="font-weight-bold"><?php echo number_format($row['total_quantity']); ?></td>
                                    <td class="text-success font-weight-bold"><?php echo formatPrice($row['total_revenue']); ?></td>
                                    <td><?php echo formatPrice($row['avg_price']); ?></td>

                                <?php elseif ($report_type === 'customers'): ?>
                                    <td class="font-weight-bold"><?php echo e($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?php echo e($row['email']); ?></td>
                                    <td><?php echo e($row['city']); ?></td>
                                    <td><?php echo number_format($row['order_count']); ?></td>
                                    <td class="text-success font-weight-bold"><?php echo formatPrice($row['total_spent']); ?></td>
                                    <td><?php echo formatPrice($row['avg_order_value']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($row['last_order_date'])); ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="no-data">
                        <p>No data available for the selected criteria.</p>
                        <p>Try adjusting your date range or location filter.</p>
                    </div>
                    <?php endif; ?>
                </div>

                <?php else: ?>
                <div class="report-section">
                    <div class="no-data">
                        <h3>No Data Available</h3>
                        <p>Please select your report criteria and click "Generate Report" to view analytics.</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
    // Chart.js setup for revenue chart
    <?php if ($report_type === 'sales' && !empty($report_data['chart'])): ?>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        
        const chartData = {
            labels: [<?php echo implode(',', array_map(function($item) { return '"' . date('M j', strtotime($item['date'])) . '"'; }, $report_data['chart'])); ?>],
            datasets: [{
                label: 'Revenue',
                data: [<?php echo implode(',', array_column($report_data['chart'], 'revenue')); ?>],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }, {
                label: 'Orders',
                data: [<?php echo implode(',', array_column($report_data['chart'], 'orders')); ?>],
                borderColor: '#27ae60',
                backgroundColor: 'rgba(39, 174, 96, 0.1)',
                borderWidth: 2,
                fill: false,
                yAxisID: 'y1'
            }]
        };

        const config = {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Daily Revenue and Orders Trend'
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Revenue (AUD)'
                        },
                        ticks: {
                            callback: function(value) {
                                return ' + value.toLocaleString();
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Orders'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        };

        new Chart(ctx, config);
    });
    <?php endif; ?>

    // Export functions
    function exportToCSV() {
        const table = document.getElementById('reportTable');
        if (!table) return;

        let csv = '';
        const rows = table.querySelectorAll('tr');
        
        for (let i = 0; i < rows.length; i++) {
            const cols = rows[i].querySelectorAll('td, th');
            const csvRow = [];
            
            for (let j = 0; j < cols.length; j++) {
                let cellText = cols[j].textContent.trim();
                // Handle cells with commas
                if (cellText.includes(',')) {
                    cellText = '"' + cellText + '"';
                }
                csvRow.push(cellText);
            }
            csv += csvRow.join(',') + '\n';
        }

        // Download CSV
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.setAttribute('hidden', '');
        a.setAttribute('href', url);
        a.setAttribute('download', '<?php echo $report_type; ?>_report_<?php echo date('Y-m-d'); ?>.csv');
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }

    function printReport() {
        window.print();
    }

    function exportChart() {
        const canvas = document.getElementById('revenueChart');
        if (canvas) {
            const url = canvas.toDataURL('image/png');
            const a = document.createElement('a');
            a.setAttribute('hidden', '');
            a.setAttribute('href', url);
            a.setAttribute('download', 'revenue_chart_<?php echo date('Y-m-d'); ?>.png');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
    }

    // Quick date range buttons
    function setDateRange(days) {
        const today = new Date();
        const fromDate = new Date();
        fromDate.setDate(today.getDate() - days);
        
        document.querySelector('input[name="date_from"]').value = fromDate.toISOString().split('T')[0];
        document.querySelector('input[name="date_to"]').value = today.toISOString().split('T')[0];
    }

    // Add quick date buttons
    document.addEventListener('DOMContentLoaded', function() {
        const filtersContainer = document.querySelector('.filters-container');
        const quickDatesDiv = document.createElement('div');
        quickDatesDiv.className = 'filter-group';
        quickDatesDiv.innerHTML = `
            <label class="form-label">Quick Dates</label>
            <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                <button type="button" class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;" onclick="setDateRange(7)">7 Days</button>
                <button type="button" class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;" onclick="setDateRange(30)">30 Days</button>
                <button type="button" class="btn btn-secondary" style="padding: 5px 10px; font-size: 12px;" onclick="setDateRange(90)">90 Days</button>
            </div>
        `;
        filtersContainer.insertBefore(quickDatesDiv, filtersContainer.lastElementChild);
    });

    // Auto-refresh every 5 minutes for real-time data
    setTimeout(function() {
        if (confirm('Refresh report with latest data?')) {
            location.reload();
        }
    }, 300000); // 5 minutes
    </script>

    <style>
    /* Print styles */
    @media print {
        .admin-sidebar,
        .admin-header,
        .export-buttons,
        .report-tabs,
        .filters-container {
            display: none;
        }
        
        .admin-content {
            margin-left: 0;
        }
        
        .report-section {
            break-inside: avoid;
        }
        
        .chart-container {
            height: 300px;
        }
    }

    /* Badge styles */
    .badge {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .badge-primary {
        background: #3498db;
        color: white;
    }

    .badge-info {
        background: #17a2b8;
        color: white;
    }

    /* Alert styles */
    .alert {
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .alert-danger {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    </style>
</body>
</html>