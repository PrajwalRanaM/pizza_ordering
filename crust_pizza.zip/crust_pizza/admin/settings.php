<?php
// admin/settings.php - System Settings Management
require_once '../includes/init.php';

// Check if user is admin
requireAdmin();

$message = '';
$error = '';
$tab = $_GET['tab'] ?? 'general';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please try again.';
    } else {
        $form_action = $_POST['action'] ?? '';
        
        switch ($form_action) {
            case 'update_general':
                // Update general settings
                $site_name = sanitizeInput($_POST['site_name'] ?? '');
                $site_tagline = sanitizeInput($_POST['site_tagline'] ?? '');
                $admin_email = filter_var($_POST['admin_email'] ?? '', FILTER_VALIDATE_EMAIL);
                $support_email = filter_var($_POST['support_email'] ?? '', FILTER_VALIDATE_EMAIL);
                $opening_hour = (int)($_POST['opening_hour'] ?? 0);
                $closing_hour = (int)($_POST['closing_hour'] ?? 0);
                
                // Validation
                $errors = [];
                if (empty($site_name)) $errors[] = 'Site name is required.';
                if (!$admin_email) $errors[] = 'Valid admin email is required.';
                if (!$support_email) $errors[] = 'Valid support email is required.';
                if ($opening_hour < 0 || $opening_hour > 23) $errors[] = 'Invalid opening hour.';
                if ($closing_hour < 1 || $closing_hour > 24) $errors[] = 'Invalid closing hour.';
                if ($opening_hour >= $closing_hour) $errors[] = 'Opening hour must be before closing hour.';
                
                if (empty($errors)) {
                    // In a real application, these would be stored in a settings table
                    // For now, we'll simulate successful update
                    $message = 'General settings updated successfully!';
                } else {
                    $error = implode('<br>', $errors);
                }
                break;
                
            case 'update_pricing':
                // Update pricing settings
                $min_order = (float)($_POST['min_order_amount'] ?? 0);
                $delivery_fee = (float)($_POST['delivery_fee'] ?? 0);
                $free_delivery_amount = (float)($_POST['free_delivery_amount'] ?? 0);
                $tax_rate = (float)($_POST['tax_rate'] ?? 0);
                $estimated_prep_time = (int)($_POST['estimated_prep_time'] ?? 0);
                $estimated_delivery_time = (int)($_POST['estimated_delivery_time'] ?? 0);
                
                // Validation
                $errors = [];
                if ($min_order < 0) $errors[] = 'Minimum order amount cannot be negative.';
                if ($delivery_fee < 0) $errors[] = 'Delivery fee cannot be negative.';
                if ($free_delivery_amount < $min_order) $errors[] = 'Free delivery amount must be greater than minimum order.';
                if ($tax_rate < 0 || $tax_rate > 1) $errors[] = 'Tax rate must be between 0 and 1 (e.g., 0.10 for 10%).';
                if ($estimated_prep_time < 5 || $estimated_prep_time > 120) $errors[] = 'Prep time must be between 5 and 120 minutes.';
                if ($estimated_delivery_time < 5 || $estimated_delivery_time > 60) $errors[] = 'Delivery time must be between 5 and 60 minutes.';
                
                if (empty($errors)) {
                    $message = 'Pricing settings updated successfully!';
                } else {
                    $error = implode('<br>', $errors);
                }
                break;
                
            case 'update_notifications':
                // Update notification settings
                $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
                $sms_notifications = isset($_POST['sms_notifications']) ? 1 : 0;
                $order_confirmation_email = isset($_POST['order_confirmation_email']) ? 1 : 0;
                $order_ready_notification = isset($_POST['order_ready_notification']) ? 1 : 0;
                $delivery_notification = isset($_POST['delivery_notification']) ? 1 : 0;
                
                $message = 'Notification settings updated successfully!';
                break;
                
            case 'add_location':
                // Add new location
                $store_name = sanitizeInput($_POST['store_name'] ?? '');
                $address = sanitizeInput($_POST['address'] ?? '');
                $city = sanitizeInput($_POST['city'] ?? '');
                $state = $_POST['state'] ?? '';
                $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
                $phone = sanitizeInput($_POST['phone'] ?? '');
                $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
                
                // Validation
                $errors = [];
                if (empty($store_name)) $errors[] = 'Store name is required.';
                if (empty($address)) $errors[] = 'Address is required.';
                if (empty($city)) $errors[] = 'City is required.';
                if (empty($state)) $errors[] = 'State is required.';
                if (!preg_match('/^[0-9]{4}$/', $postal_code)) $errors[] = 'Invalid postal code.';
                if (empty($phone)) $errors[] = 'Phone number is required.';
                if (!$email) $errors[] = 'Valid email is required.';
                
                if (empty($errors)) {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO locations (store_name, address, city, state, postal_code, phone, email, is_active, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
                        ");
                        $stmt->bind_param("sssssss", $store_name, $address, $city, $state, $postal_code, $phone, $email);
                        
                        if ($stmt->execute()) {
                            $message = 'Location added successfully!';
                        } else {
                            $error = 'Failed to add location. Please try again.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                } else {
                    $error = implode('<br>', $errors);
                }
                break;
                
            case 'update_location':
                // Update existing location
                $location_id = (int)($_POST['location_id'] ?? 0);
                $store_name = sanitizeInput($_POST['store_name'] ?? '');
                $address = sanitizeInput($_POST['address'] ?? '');
                $city = sanitizeInput($_POST['city'] ?? '');
                $state = $_POST['state'] ?? '';
                $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
                $phone = sanitizeInput($_POST['phone'] ?? '');
                $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
                $is_active = isset($_POST['is_active']) ? 1 : 0;
                
                if ($location_id > 0) {
                    try {
                        $stmt = $conn->prepare("
                            UPDATE locations 
                            SET store_name = ?, address = ?, city = ?, state = ?, postal_code = ?, 
                                phone = ?, email = ?, is_active = ?, updated_at = NOW()
                            WHERE location_id = ?
                        ");
                        $stmt->bind_param("sssssssii", $store_name, $address, $city, $state, 
                                        $postal_code, $phone, $email, $is_active, $location_id);
                        
                        if ($stmt->execute()) {
                            $message = 'Location updated successfully!';
                        } else {
                            $error = 'Failed to update location. Please try again.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                }
                break;
                
            case 'add_category':
                // Add new category
                $category_name = sanitizeInput($_POST['category_name'] ?? '');
                $description = sanitizeInput($_POST['description'] ?? '');
                $display_order = (int)($_POST['display_order'] ?? 0);
                
                if (!empty($category_name)) {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO product_categories (category_name, description, display_order, is_active)
                            VALUES (?, ?, ?, 1)
                        ");
                        $stmt->bind_param("ssi", $category_name, $description, $display_order);
                        
                        if ($stmt->execute()) {
                            $message = 'Category added successfully!';
                        } else {
                            $error = 'Failed to add category. Please try again.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                } else {
                    $error = 'Category name is required.';
                }
                break;
                
            case 'add_order_status':
                // Add new order status
                $status_name = sanitizeInput($_POST['status_name'] ?? '');
                $description = sanitizeInput($_POST['description'] ?? '');
                $display_order = (int)($_POST['display_order'] ?? 0);
                
                if (!empty($status_name)) {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO order_statuses (status_name, description, display_order)
                            VALUES (?, ?, ?)
                        ");
                        $stmt->bind_param("ssi", $status_name, $description, $display_order);
                        
                        if ($stmt->execute()) {
                            $message = 'Order status added successfully!';
                        } else {
                            $error = 'Failed to add order status. Please try again.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                } else {
                    $error = 'Status name is required.';
                }
                break;
                
            case 'add_role':
                // Add new employee role
                $role_name = sanitizeInput($_POST['role_name'] ?? '');
                $description = sanitizeInput($_POST['description'] ?? '');
                
                if (!empty($role_name)) {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO employee_roles (role_name, description)
                            VALUES (?, ?)
                        ");
                        $stmt->bind_param("ss", $role_name, $description);
                        
                        if ($stmt->execute()) {
                            $message = 'Employee role added successfully!';
                        } else {
                            $error = 'Failed to add role. Please try again.';
                        }
                    } catch (Exception $e) {
                        $error = 'Database error: ' . $e->getMessage();
                    }
                } else {
                    $error = 'Role name is required.';
                }
                break;
        }
    }
}

// Get current settings (in a real app, these would come from a settings table)
$current_settings = [
    'site_name' => SITE_NAME,
    'site_tagline' => SITE_TAGLINE,
    'admin_email' => ADMIN_EMAIL,
    'support_email' => SUPPORT_EMAIL,
    'opening_hour' => OPENING_HOUR,
    'closing_hour' => CLOSING_HOUR,
    'min_order_amount' => MIN_ORDER_AMOUNT,
    'delivery_fee' => DELIVERY_FEE,
    'free_delivery_amount' => FREE_DELIVERY_AMOUNT,
    'tax_rate' => TAX_RATE,
    'estimated_prep_time' => ESTIMATED_PREP_TIME,
    'estimated_delivery_time' => ESTIMATED_DELIVERY_TIME,
];

// Get locations
$locations = [];
try {
    $result = $conn->query("SELECT * FROM locations ORDER BY city, store_name");
    $locations = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Locations fetch error: ' . $e->getMessage());
}

// Get categories
$categories = [];
try {
    $result = $conn->query("SELECT * FROM product_categories ORDER BY display_order, category_name");
    $categories = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Categories fetch error: ' . $e->getMessage());
}

// Get order statuses
$order_statuses = [];
try {
    $result = $conn->query("SELECT * FROM order_statuses ORDER BY display_order, status_name");
    $order_statuses = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Order statuses fetch error: ' . $e->getMessage());
}

// Get employee roles
$employee_roles = [];
try {
    $result = $conn->query("SELECT * FROM employee_roles ORDER BY role_name");
    $employee_roles = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    logError('Employee roles fetch error: ' . $e->getMessage());
}

// Get system stats
$system_stats = [];
try {
    // Database size
    $result = $conn->query("
        SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE()
    ");
    $system_stats['db_size'] = $result->fetch_assoc()['size_mb'] ?? 0;
    
    // Total records count
    $tables = ['customers', 'orders', 'products', 'ingredients', 'employees'];
    foreach ($tables as $table) {
        $result = $conn->query("SELECT COUNT(*) as count FROM $table");
        $system_stats[$table . '_count'] = $result->fetch_assoc()['count'];
    }
} catch (Exception $e) {
    logError('System stats error: ' . $e->getMessage());
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?php echo SITE_NAME; ?> Admin</title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/settings.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <nav class="admin-sidebar">
            <div class="sidebar-header">
                <a href="dashboard.php" class="sidebar-brand">
                    🍕 Admin Panel
                </a>
            </div>
            <ul class="sidebar-nav">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <span>📊</span> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="orders.php" class="nav-link">
                        <span>📋</span> Orders
                    </a>
                </li>
                <li class="nav-item">
                    <a href="products.php" class="nav-link">
                        <span>🍕</span> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a href="ingredients.php" class="nav-link">
                        <span>🥬</span> Ingredients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="customers.php" class="nav-link">
                        <span>👥</span> Customers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="employees.php" class="nav-link">
                        <span>👨‍💼</span> Employees
                    </a>
                </li>
                <li class="nav-item">
                    <a href="locations.php" class="nav-link">
                        <span>📍</span> Locations
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <span>📈</span> Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="settings.php" class="nav-link active">
                        <span>⚙️</span> Settings
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="admin-content">
            <!-- Header -->
            <header class="admin-header">
                <h1 class="admin-title">System Settings</h1>
                <div class="admin-user">
                    <div class="user-info">
                        <div class="user-name"><?php echo e(getCurrentUserFullName()); ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <a href="../logout.php" class="logout-btn">Logout</a>
                </div>
            </header>

            <div class="main-content">
                <?php if ($message): ?>
                <div class="message success"><?php echo e($message); ?></div>
                <?php endif; ?>

                <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
                <?php endif; ?>

                <!-- Settings Tabs -->
                <div class="settings-tabs">
                    <button class="tab-button <?php echo $tab === 'general' ? 'active' : ''; ?>" 
                            onclick="showTab('general')">
                        ⚙️ General Settings
                    </button>
                    <button class="tab-button <?php echo $tab === 'pricing' ? 'active' : ''; ?>" 
                            onclick="showTab('pricing')">
                        💰 Pricing & Timing
                    </button>
                    <button class="tab-button <?php echo $tab === 'locations' ? 'active' : ''; ?>" 
                            onclick="showTab('locations')">
                        📍 Locations
                    </button>
                    <button class="tab-button <?php echo $tab === 'categories' ? 'active' : ''; ?>" 
                            onclick="showTab('categories')">
                        📂 Categories
                    </button>
                    <button class="tab-button <?php echo $tab === 'system' ? 'active' : ''; ?>" 
                            onclick="showTab('system')">
                        🔧 System
                    </button>
                </div>

                <!-- General Settings Tab -->
                <div id="general" class="tab-content <?php echo $tab === 'general' ? 'active' : ''; ?>">
                    <div class="settings-section">
                        <h2 class="section-title">General Settings</h2>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="action" value="update_general">
                            
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Site Name</label>
                                    <input type="text" name="site_name" class="form-input" 
                                           value="<?php echo e($current_settings['site_name']); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Site Tagline</label>
                                    <input type="text" name="site_tagline" class="form-input" 
                                           value="<?php echo e($current_settings['site_tagline']); ?>">
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Admin Email</label>
                                    <input type="email" name="admin_email" class="form-input" 
                                           value="<?php echo e($current_settings['admin_email']); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Support Email</label>
                                    <input type="email" name="support_email" class="form-input" 
                                           value="<?php echo e($current_settings['support_email']); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Opening Hour</label>
                                    <select name="opening_hour" class="form-select">
                                        <?php for ($i = 0; $i < 24; $i++): ?>
                                        <option value="<?php echo $i; ?>" <?php echo $current_settings['opening_hour'] == $i ? 'selected' : ''; ?>>
                                            <?php echo sprintf('%02d:00', $i); ?>
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Closing Hour</label>
                                    <select name="closing_hour" class="form-select">
                                        <?php for ($i = 1; $i <= 24; $i++): ?>
                                        <option value="<?php echo $i; ?>" <?php echo $current_settings['closing_hour'] == $i ? 'selected' : ''; ?>>
                                            <?php echo sprintf('%02d:00', $i == 24 ? 0 : $i); ?>
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Update General Settings</button>
                        </form>
                    </div>

                    <!-- Notification Settings -->
                    <div class="settings-section">
                        <h2 class="section-title">Notification Settings</h2>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="action" value="update_notifications">
                            
                            <div class="checkbox-group">
                                <div class="checkbox-item">
                                    <input type="checkbox" name="email_notifications" id="email_notifications" checked>
                                    <label for="email_notifications">Enable Email Notifications</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" name="sms_notifications" id="sms_notifications">
                                    <label for="sms_notifications">Enable SMS Notifications</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" name="order_confirmation_email" id="order_confirmation_email" checked>
                                    <label for="order_confirmation_email">Send Order Confirmation Emails</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" name="order_ready_notification" id="order_ready_notification" checked>
                                    <label for="order_ready_notification">Send Order Ready Notifications</label>
                                </div>
                                <div class="checkbox-item">
                                    <input type="checkbox" name="delivery_notification" id="delivery_notification" checked>
                                    <label for="delivery_notification">Send Delivery Notifications</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary" style="margin-top: 20px;">Update Notification Settings</button>
                        </form>
                    </div>
                </div>

                <!-- Pricing & Timing Tab -->
                <div id="pricing" class="tab-content <?php echo $tab === 'pricing' ? 'active' : ''; ?>">
                    <div class="settings-section">
                        <h2 class="section-title">Pricing & Timing Settings</h2>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="action" value="update_pricing">
                            
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label">Minimum Order Amount (AUD)</label>
                                    <input type="number" name="min_order_amount" class="form-input" step="0.01" min="0"
                                           value="<?php echo $current_settings['min_order_amount']; ?>" required>
                                    <div class="help-text">Minimum amount required for delivery orders</div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Delivery Fee (AUD)</label>
                                    <input type="number" name="delivery_fee" class="form-input" step="0.01" min="0"
                                           value="<?php echo $current_settings['delivery_fee']; ?>" required>
                                    <div class="help-text">Standard delivery fee charged to customers</div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Free Delivery Amount (AUD)</label>
                                    <input type="number" name="free_delivery_amount" class="form-input" step="0.01" min="0"
                                           value="<?php echo $current_settings['free_delivery_amount']; ?>" required>
                                    <div class="help-text">Order amount above which delivery is free</div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Tax Rate (GST)</label>
                                    <input type="number" name="tax_rate" class="form-input" step="0.01" min="0" max="1"
                                           value="<?php echo $current_settings['tax_rate']; ?>" required>
                                    <div class="help-text">Tax rate as decimal (e.g., 0.10 for 10%)</div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Estimated Prep Time (minutes)</label>
                                    <input type="number" name="estimated_prep_time" class="form-input" min="5" max="120"
                                           value="<?php echo $current_settings['estimated_prep_time']; ?>" required>
                                    <div class="help-text">Average time to prepare orders</div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Estimated Delivery Time (minutes)</label>
                                    <input type="number" name="estimated_delivery_time" class="form-input" min="5" max="60"
                                           value="<?php echo $current_settings['estimated_delivery_time']; ?>" required>
                                    <div class="help-text">Average delivery time after prep</div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Update Pricing Settings</button>
                        </form>
                    </div>
                </div>

                <!-- Locations Tab -->
                <div id="locations" class="tab-content <?php echo $tab === 'locations' ? 'active' : ''; ?>">
                    <div class="settings-section">
                        <h2 class="section-title">Store Locations</h2>
                        
                        <!-- Add New Location Form -->
                        <div class="quick-add-form">
                            <h4>Add New Location</h4>
                            <form method="POST" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="add_location">
                                
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">Store Name</label>
                                        <input type="text" name="store_name" class="form-input" required
                                               placeholder="Crust Pizza - City Name">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Phone</label>
                                        <input type="tel" name="phone" class="form-input" required
                                               placeholder="(03) 1234 5678">
                                    </div>
                                    <div class="form-group full-width">
                                        <label class="form-label">Address</label>
                                        <input type="text" name="address" class="form-input" required
                                               placeholder="123 Main Street">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">City</label>
                                        <input type="text" name="city" class="form-input" required
                                               placeholder="Melbourne">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">State</label>
                                        <select name="state" class="form-select" required>
                                            <option value="">Select State</option>
                                            <?php foreach (AU_STATES as $code => $name): ?>
                                            <option value="<?php echo $code; ?>"><?php echo $name; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Postal Code</label>
                                        <input type="text" name="postal_code" class="form-input" required
                                               placeholder="3000" pattern="[0-9]{4}" maxlength="4">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="email" name="email" class="form-input" required
                                               placeholder="store@crustpizza.com.au">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">Add Location</button>
                            </form>
                        </div>

                        <!-- Locations Table -->
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Store Name</th>
                                    <th>Address</th>
                                    <th>Contact</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($locations as $location): ?>
                                <tr>
                                    <td><?php echo $location['location_id']; ?></td>
                                    <td><strong><?php echo e($location['store_name']); ?></strong></td>
                                    <td>
                                        <?php echo e($location['address']); ?><br>
                                        <?php echo e($location['city']); ?>, <?php echo e($location['state']); ?> <?php echo e($location['postal_code']); ?>
                                    </td>
                                    <td>
                                        📞 <?php echo e($location['phone']); ?><br>
                                        📧 <?php echo e($location['email']); ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $location['is_active'] ? 'active' : 'inactive'; ?>">
                                            <?php echo $location['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button onclick="editLocation(<?php echo $location['location_id']; ?>)" 
                                                class="btn btn-primary btn-sm">Edit</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Categories Tab -->
                <div id="categories" class="tab-content <?php echo $tab === 'categories' ? 'active' : ''; ?>">
                    <div class="settings-section">
                        <h2 class="section-title">Product Categories</h2>
                        
                        <!-- Add Category Form -->
                        <div class="quick-add-form">
                            <h4>Add New Category</h4>
                            <form method="POST" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="add_category">
                                
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">Category Name</label>
                                        <input type="text" name="category_name" class="form-input" required
                                               placeholder="e.g., Pizzas, Sides, Drinks">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Display Order</label>
                                        <input type="number" name="display_order" class="form-input" min="0"
                                               placeholder="0" value="0">
                                    </div>
                                    <div class="form-group full-width">
                                        <label class="form-label">Description</label>
                                        <textarea name="description" class="form-textarea"
                                                  placeholder="Optional description"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">Add Category</button>
                            </form>
                        </div>

                        <!-- Categories Table -->
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category Name</th>
                                    <th>Description</th>
                                    <th>Display Order</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?php echo $category['category_id']; ?></td>
                                    <td><strong><?php echo e($category['category_name']); ?></strong></td>
                                    <td><?php echo e($category['description'] ?? 'No description'); ?></td>
                                    <td><?php echo $category['display_order']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $category['is_active'] ? 'active' : 'inactive'; ?>">
                                            <?php echo $category['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Order Statuses Section -->
                    <div class="settings-section">
                        <h2 class="section-title">Order Statuses</h2>
                        
                        <!-- Add Order Status Form -->
                        <div class="quick-add-form">
                            <h4>Add New Order Status</h4>
                            <form method="POST" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="add_order_status">
                                
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">Status Name</label>
                                        <input type="text" name="status_name" class="form-input" required
                                               placeholder="e.g., Preparing, Out for Delivery">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Display Order</label>
                                        <input type="number" name="display_order" class="form-input" min="0"
                                               placeholder="0" value="0">
                                    </div>
                                    <div class="form-group full-width">
                                        <label class="form-label">Description</label>
                                        <textarea name="description" class="form-textarea"
                                                  placeholder="Optional description"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">Add Status</button>
                            </form>
                        </div>

                        <!-- Order Statuses Table -->
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Status Name</th>
                                    <th>Description</th>
                                    <th>Display Order</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order_statuses as $status): ?>
                                <tr>
                                    <td><?php echo $status['status_id']; ?></td>
                                    <td><strong><?php echo e($status['status_name']); ?></strong></td>
                                    <td><?php echo e($status['description'] ?? 'No description'); ?></td>
                                    <td><?php echo $status['display_order']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Employee Roles Section -->
                    <div class="settings-section">
                        <h2 class="section-title">Employee Roles</h2>
                        
                        <!-- Add Role Form -->
                        <div class="quick-add-form">
                            <h4>Add New Employee Role</h4>
                            <form method="POST" action="">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="add_role">
                                
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">Role Name</label>
                                        <input type="text" name="role_name" class="form-input" required
                                               placeholder="e.g., Kitchen Manager, Cashier">
                                    </div>
                                    <div class="form-group full-width">
                                        <label class="form-label">Description</label>
                                        <textarea name="description" class="form-textarea"
                                                  placeholder="Role responsibilities and description"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success">Add Role</button>
                            </form>
                        </div>

                        <!-- Employee Roles Table -->
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Role Name</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($employee_roles as $role): ?>
                                <tr>
                                    <td><?php echo $role['role_id']; ?></td>
                                    <td><strong><?php echo e($role['role_name']); ?></strong></td>
                                    <td><?php echo e($role['description'] ?? 'No description'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- System Tab -->
                <div id="system" class="tab-content <?php echo $tab === 'system' ? 'active' : ''; ?>">
                    <!-- System Information -->
                    <div class="settings-section">
                        <h2 class="section-title">System Information</h2>
                        
                        <div class="system-info-grid">
                            <div class="info-card">
                                <div class="info-value"><?php echo number_format($system_stats['customers_count'] ?? 0); ?></div>
                                <div class="info-label">Total Customers</div>
                            </div>
                            <div class="info-card">
                                <div class="info-value"><?php echo number_format($system_stats['orders_count'] ?? 0); ?></div>
                                <div class="info-label">Total Orders</div>
                            </div>
                            <div class="info-card">
                                <div class="info-value"><?php echo number_format($system_stats['products_count'] ?? 0); ?></div>
                                <div class="info-label">Total Products</div>
                            </div>
                            <div class="info-card">
                                <div class="info-value"><?php echo number_format($system_stats['ingredients_count'] ?? 0); ?></div>
                                <div class="info-label">Total Ingredients</div>
                            </div>
                            <div class="info-card">
                                <div class="info-value"><?php echo number_format($system_stats['employees_count'] ?? 0); ?></div>
                                <div class="info-label">Total Employees</div>
                            </div>
                            <div class="info-card warning">
                                <div class="info-value"><?php echo $system_stats['db_size'] ?? 0; ?> MB</div>
                                <div class="info-label">Database Size</div>
                            </div>
                        </div>
                    </div>

                    <!-- System Status -->
                    <div class="settings-section">
                        <h2 class="section-title">System Status</h2>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">PHP Version</label>
                                <div style="padding: 10px; background: #f8f9fa; border-radius: 4px;">
                                    <?php echo PHP_VERSION; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">MySQL Version</label>
                                <div style="padding: 10px; background: #f8f9fa; border-radius: 4px;">
                                    <?php echo $conn->get_server_info(); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Server Time</label>
                                <div style="padding: 10px; background: #f8f9fa; border-radius: 4px;">
                                    <?php echo date('Y-m-d H:i:s T'); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Environment</label>
                                <div style="padding: 10px; background: #f8f9fa; border-radius: 4px;">
                                    <?php echo ENVIRONMENT; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Maintenance Tools -->
                    <div class="settings-section">
                        <h2 class="section-title">Maintenance Tools</h2>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                            <button class="btn btn-secondary" onclick="clearCache()">
                                🗑️ Clear Cache
                            </button>
                            <button class="btn btn-secondary" onclick="optimizeDatabase()">
                                🔧 Optimize Database
                            </button>
                            <button class="btn btn-secondary" onclick="exportData()">
                                📤 Export Data
                            </button>
                            <button class="btn btn-warning" onclick="maintenanceMode()">
                                ⚠️ Maintenance Mode
                            </button>
                        </div>
                        
                        <div class="help-text" style="margin-top: 15px;">
                            <strong>Warning:</strong> Maintenance tools should be used with caution. 
                            Always backup your data before performing maintenance operations.
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
    function showTab(tabName) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all tab buttons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected tab content
        document.getElementById(tabName).classList.add('active');
        
        // Add active class to selected tab button
        event.target.classList.add('active');
        
        // Update URL
        const url = new URL(window.location);
        url.searchParams.set('tab', tabName);
        window.history.replaceState({}, '', url);
    }

    function editLocation(locationId) {
        // In a real implementation, this would open a modal or redirect to edit page
        alert('Edit location functionality would be implemented here for location ID: ' + locationId);
    }

    function clearCache() {
        if (confirm('Are you sure you want to clear the cache? This action cannot be undone.')) {
            // In a real implementation, this would make an AJAX call to clear cache
            alert('Cache cleared successfully!');
        }
    }

    function optimizeDatabase() {
        if (confirm('Are you sure you want to optimize the database? This may take a few minutes.')) {
            // In a real implementation, this would make an AJAX call to optimize database
            alert('Database optimization completed!');
        }
    }

    function exportData() {
        if (confirm('Are you sure you want to export all data? This will create a backup file.')) {
            // In a real implementation, this would trigger a data export
            alert('Data export started. You will receive an email when complete.');
        }
    }

    function maintenanceMode() {
        if (confirm('Are you sure you want to enable maintenance mode? This will prevent customers from placing orders.')) {
            // In a real implementation, this would toggle maintenance mode
            alert('Maintenance mode toggled!');
        }
    }

    // Auto-hide messages after 5 seconds
    setTimeout(function() {
        const messages = document.querySelectorAll('.message');
        messages.forEach(function(message) {
            message.style.opacity = '0';
            setTimeout(() => message.remove(), 300);
        });
    }, 5000);

    // Initialize tab based on URL parameter
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const tab = urlParams.get('tab');
        if (tab && document.getElementById(tab)) {
            showTab(tab);
        }
    });
    </script>
</body>
</html>