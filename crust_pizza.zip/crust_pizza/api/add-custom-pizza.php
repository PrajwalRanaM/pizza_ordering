<?php
// api/add-custom-pizza.php - Add custom pizza to cart
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to add items to cart']);
    exit;
}

// Check if store is open
if (!isStoreOpen()) {
    echo json_encode(['success' => false, 'message' => 'Sorry, we are currently closed']);
    exit;
}

// Check if location is selected
$location_id = getSelectedLocation();
if (!$location_id) {
    echo json_encode(['success' => false, 'message' => 'Please select a location first']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required_fields = ['size_id', 'crust_type_id', 'sauce_id', 'quantity'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        echo json_encode(['success' => false, 'message' => "Missing required field: $field"]);
        exit;
    }
}

$size_id = (int)$input['size_id'];
$crust_type_id = (int)$input['crust_type_id'];
$sauce_id = (int)$input['sauce_id'];
$cheese_id = isset($input['cheese_id']) ? (int)$input['cheese_id'] : null;
$cheese_amount = $input['cheese_amount'] ?? 'regular';
$toppings = $input['toppings'] ?? [];
$quantity = max(1, min(10, (int)$input['quantity']));

try {
    // Initialize cart in session if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Calculate price
    $base_price = 15.90; // Base price for custom pizza
    
    // Get size multiplier
    $stmt = $conn->prepare("SELECT price_multiplier FROM crust_sizes WHERE size_id = ? AND is_active = 1");
    $stmt->bind_param("i", $size_id);
    $stmt->execute();
    $size_result = $stmt->get_result();
    if ($size_result->num_rows === 0) {
        throw new Exception('Invalid size selected');
    }
    $size_multiplier = $size_result->fetch_assoc()['price_multiplier'];
    
    // Get crust additional price
    $stmt = $conn->prepare("SELECT additional_price FROM crust_types WHERE crust_type_id = ? AND is_active = 1");
    $stmt->bind_param("i", $crust_type_id);
    $stmt->execute();
    $crust_result = $stmt->get_result();
    if ($crust_result->num_rows === 0) {
        throw new Exception('Invalid crust selected');
    }
    $crust_price = $crust_result->fetch_assoc()['additional_price'];
    
    // Calculate toppings price
    $toppings_price = 0;
    if (!empty($toppings)) {
        $placeholders = str_repeat('?,', count($toppings) - 1) . '?';
        $stmt = $conn->prepare("SELECT SUM(price) as total FROM ingredients WHERE ingredient_id IN ($placeholders) AND is_active = 1");
        $types = str_repeat('i', count($toppings));
        $stmt->bind_param($types, ...$toppings);
        $stmt->execute();
        $toppings_result = $stmt->get_result();
        $toppings_price = $toppings_result->fetch_assoc()['total'] ?? 0;
    }
    
    // Extra cheese price
    $extra_cheese_price = ($cheese_amount === 'extra') ? 2.00 : 0;
    
    // Calculate total price for one pizza
    $unit_price = ($base_price * $size_multiplier) + $crust_price + $toppings_price + $extra_cheese_price;
    
    // Create unique cart key for this custom pizza
    $cart_key = 'custom_' . uniqid();
    
    // Create description
    $description = "Custom Pizza with ";
    $description_parts = [];
    
    // Get component names for description
    $stmt = $conn->prepare("SELECT size_name FROM crust_sizes WHERE size_id = ?");
    $stmt->bind_param("i", $size_id);
    $stmt->execute();
    $size_name = $stmt->get_result()->fetch_assoc()['size_name'];
    
    $stmt = $conn->prepare("SELECT crust_name FROM crust_types WHERE crust_type_id = ?");
    $stmt->bind_param("i", $crust_type_id);
    $stmt->execute();
    $crust_name = $stmt->get_result()->fetch_assoc()['crust_name'];
    
    $stmt = $conn->prepare("SELECT sauce_name FROM sauces WHERE sauce_id = ?");
    $stmt->bind_param("i", $sauce_id);
    $stmt->execute();
    $sauce_name = $stmt->get_result()->fetch_assoc()['sauce_name'];
    
    $description_parts[] = $crust_name . " crust";
    $description_parts[] = $sauce_name;
    
    if ($cheese_id && $cheese_amount !== 'none') {
        $stmt = $conn->prepare("SELECT cheese_name FROM cheese_types WHERE cheese_id = ?");
        $stmt->bind_param("i", $cheese_id);
        $stmt->execute();
        $cheese_name = $stmt->get_result()->fetch_assoc()['cheese_name'];
        $description_parts[] = $cheese_name . ($cheese_amount === 'extra' ? ' (extra)' : '');
    }
    
    // Get topping names
    if (!empty($toppings)) {
        $placeholders = str_repeat('?,', count($toppings) - 1) . '?';
        $stmt = $conn->prepare("SELECT ingredient_name FROM ingredients WHERE ingredient_id IN ($placeholders)");
        $types = str_repeat('i', count($toppings));
        $stmt->bind_param($types, ...$toppings);
        $stmt->execute();
        $toppings_result = $stmt->get_result();
        $topping_names = [];
        while ($row = $toppings_result->fetch_assoc()) {
            $topping_names[] = $row['ingredient_name'];
        }
        if (!empty($topping_names)) {
            $description_parts[] = implode(', ', $topping_names);
        }
    }
    
    $description = $size_name . " " . implode(', ', $description_parts);
    
    // Add to cart
    $_SESSION['cart'][$cart_key] = [
        'type' => 'custom',
        'product_name' => 'Build Your Own Pizza',
        'description' => $description,
        'size_id' => $size_id,
        'size_name' => $size_name,
        'crust_type_id' => $crust_type_id,
        'sauce_id' => $sauce_id,
        'cheese_id' => $cheese_id,
        'cheese_amount' => $cheese_amount,
        'toppings' => $toppings,
        'price' => $unit_price,
        'quantity' => $quantity,
        'added_at' => time()
    ];
    
    // Calculate cart totals
    $cart_count = 0;
    $cart_total = 0;
    
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
        $cart_total += $item['price'] * $item['quantity'];
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Custom pizza added to cart',
        'cart_count' => $cart_count,
        'cart_total' => formatPrice($cart_total),
        'cart_raw_total' => $cart_total
    ]);
    
} catch (Exception $e) {
    logError('Add custom pizza error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>