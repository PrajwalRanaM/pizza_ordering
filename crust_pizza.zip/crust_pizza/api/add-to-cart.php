<?php
// api/add-to-cart.php - Add item to cart
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to add items to cart']);
    exit;
}

// Check if store is open
if (!isStoreOpen()) {
    echo json_encode(['success' => false, 'message' => 'Sorry, we are currently closed']);
    exit;
}

// Check if location is selected
$location_id = getSelectedLocation();
if (!$location_id) {
    echo json_encode(['success' => false, 'message' => 'Please select a location first']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$product_id = $input['product_id'] ?? null;
$size_id = $input['size_id'] ?? null;
$quantity = $input['quantity'] ?? 1;
$type = $input['type'] ?? 'preset'; // 'preset' or 'custom'

// Validate input
if (!$product_id || !$size_id || !is_numeric($quantity)) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$quantity = max(1, min(20, (int)$quantity)); // Limit quantity between 1-20

try {
    // Initialize cart in session if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if ($type === 'preset') {
        // Get product details
        $stmt = $conn->prepare("
            SELECT p.product_id, p.product_name, p.base_price, 
                   cs.size_name, cs.price_multiplier
            FROM products p
            JOIN crust_sizes cs ON cs.size_id = ?
            WHERE p.product_id = ? AND p.is_active = 1
        ");
        $stmt->bind_param("ii", $size_id, $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'Product not found']);
            exit;
        }
        
        $product = $result->fetch_assoc();
        $price = $product['base_price'] * $product['price_multiplier'];
        
        // Create cart item key
        $cart_key = "preset_{$product_id}_{$size_id}";
        
        // Add or update cart item
        if (isset($_SESSION['cart'][$cart_key])) {
            $_SESSION['cart'][$cart_key]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$cart_key] = [
                'type' => 'preset',
                'product_id' => $product_id,
                'product_name' => $product['product_name'],
                'size_id' => $size_id,
                'size_name' => $product['size_name'],
                'price' => $price,
                'quantity' => $quantity,
                'added_at' => time()
            ];
        }
        
    } else if ($type === 'custom') {
        // Handle custom pizza (for pizza builder)
        // This will be implemented when we create the pizza builder
        echo json_encode(['success' => false, 'message' => 'Custom pizzas not yet implemented']);
        exit;
    }
    
    // Calculate cart totals
    $cart_count = 0;
    $cart_total = 0;
    
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
        $cart_total += $item['price'] * $item['quantity'];
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Item added to cart',
        'cart_count' => $cart_count,
        'cart_total' => formatPrice($cart_total),
        'cart_raw_total' => $cart_total
    ]);
    
} catch (Exception $e) {
    logError('Add to cart error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
?>