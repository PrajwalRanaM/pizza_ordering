<?php
// api/cancel-order.php - Cancel customer order
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to cancel orders']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$order_id = $input['order_id'] ?? null;

// Validate input
if (!$order_id || !is_numeric($order_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit;
}

$customer_id = getCurrentUserId();

try {
    // Verify the order belongs to the customer and check its status
    $order_stmt = $conn->prepare("
        SELECT o.order_id, o.order_number, o.order_status_id, o.total_amount, 
               o.payment_method, o.payment_status, o.created_at
        FROM orders o
        WHERE o.order_id = ? AND o.customer_id = ?
    ");
    $order_stmt->bind_param("ii", $order_id, $customer_id);
    $order_stmt->execute();
    $order_result = $order_stmt->get_result();
    
    if ($order_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found or access denied']);
        exit;
    }
    
    $order = $order_result->fetch_assoc();
    
    // Check if order can be cancelled
    $cancellable_statuses = [ORDER_STATUS_PENDING, ORDER_STATUS_PREPARING];
    if (!in_array($order['order_status_id'], $cancellable_statuses)) {
        echo json_encode(['success' => false, 'message' => 'This order cannot be cancelled as it is already being processed']);
        exit;
    }
    
    // Check if order was placed recently (allow cancellation within reasonable time)
    $order_time = strtotime($order['created_at']);
    $current_time = time();
    $time_diff = $current_time - $order_time;
    
    // Allow cancellation within 5 minutes for pending orders, 2 minutes for preparing orders
    $max_cancel_time = ($order['order_status_id'] === ORDER_STATUS_PENDING) ? 300 : 120; // seconds
    
    if ($time_diff > $max_cancel_time && $order['order_status_id'] === ORDER_STATUS_PREPARING) {
        echo json_encode(['success' => false, 'message' => 'This order is already being prepared and cannot be cancelled']);
        exit;
    }
    
    // Begin transaction for cancellation
    $conn->begin_transaction();
    
    try {
        // Update order status to cancelled
        $update_stmt = $conn->prepare("
            UPDATE orders 
            SET order_status_id = ?, updated_at = NOW()
            WHERE order_id = ?
        ");
        $cancelled_status = ORDER_STATUS_CANCELLED;
        $update_stmt->bind_param("ii", $cancelled_status, $order_id);
        
        if (!$update_stmt->execute()) {
            throw new Exception('Failed to update order status');
        }
        
        // Add status history entry
        $history_stmt = $conn->prepare("
            INSERT INTO order_status_history (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
            VALUES (?, ?, 'customer', ?, 'Order cancelled by customer', NOW())
        ");
        $history_stmt->bind_param("iii", $order_id, $cancelled_status, $customer_id);
        
        if (!$history_stmt->execute()) {
            throw new Exception('Failed to add status history');
        }
        
        // Handle refund for paid orders
        $refund_processed = false;
        if ($order['payment_status'] === 'completed' && $order['payment_method'] !== 'cash_on_delivery') {
            // In a real system, you would integrate with payment gateway for refunds
            // For now, we'll create a refund transaction record
            
            $refund_ref = 'REFUND_' . $order['order_number'] . '_' . date('YmdHis');
            
            $refund_stmt = $conn->prepare("
                INSERT INTO payment_transactions (
                    order_id, transaction_reference, amount, payment_method,
                    status, gateway_response, created_at
                ) VALUES (?, ?, ?, ?, 'success', 'Automatic refund processed for cancelled order', NOW())
            ");
            
            $refund_amount = -$order['total_amount']; // Negative amount for refund
            $refund_stmt->bind_param("isds", $order_id, $refund_ref, $refund_amount, $order['payment_method']);
            
            if ($refund_stmt->execute()) {
                // Update order payment status
                $payment_update_stmt = $conn->prepare("
                    UPDATE orders 
                    SET payment_status = 'refunded'
                    WHERE order_id = ?
                ");
                $payment_update_stmt->bind_param("i", $order_id);
                $payment_update_stmt->execute();
                
                $refund_processed = true;
            }
        }
        
        // Remove any delivery assignments if they exist
        $delivery_stmt = $conn->prepare("
            UPDATE delivery_assignments 
            SET delivery_status = 'failed', 
                failure_reason = 'Order cancelled by customer'
            WHERE order_id = ? AND delivery_status = 'assigned'
        ");
        $delivery_stmt->bind_param("i", $order_id);
        $delivery_stmt->execute();
        
        // Commit the transaction
        $conn->commit();
        
        // Prepare response message
        $message = 'Order #' . $order['order_number'] . ' has been cancelled successfully';
        if ($refund_processed) {
            $message .= '. Your refund has been processed and will appear in your account within 3-5 business days';
        } elseif ($order['payment_method'] === 'cash_on_delivery') {
            $message .= '. No payment was processed for this order';
        }
        
        // Log the cancellation
        logError('Order cancelled: Order ID ' . $order_id . ' by customer ID ' . $customer_id);
        
        // Return success response
        echo json_encode([
            'success' => true,
            'message' => $message,
            'order_id' => $order_id,
            'order_number' => $order['order_number'],
            'refund_processed' => $refund_processed,
            'refund_amount' => $refund_processed ? formatPrice($order['total_amount']) : null
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on any error
        $conn->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    logError('Cancel order error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while cancelling your order. Please contact customer service.']);
}
?>