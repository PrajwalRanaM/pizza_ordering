<?php
require_once '../includes/init.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$location_id = $input['location_id'] ?? $_SESSION[SESSION_LOCATION_ID] ?? null;
$address = $input['address'] ?? '';
$postal_code = $input['postal_code'] ?? '';

if (!$location_id || !$postal_code) {
    echo json_encode(['success' => false, 'message' => 'Missing required information']);
    exit;
}

// Simple postal code based delivery check
$deliverable_postcodes = [
    1 => ['3000', '3001', '3002', '3003', '3004', '3006', '3008'], // CBD location
    2 => ['3008', '3000', '3001', '3006', '3121', '3141'],         // Docklands location
    3 => ['3053', '3054', '3055', '3056', '3057', '3058'],         // Carlton location
    4 => ['3121', '3122', '3123', '3124', '3141', '3142'],         // Richmond location
    5 => ['3182', '3183', '3184', '3185', '3186', '3141']          // St Kilda location
];

$can_deliver = isset($deliverable_postcodes[$location_id]) && 
               in_array($postal_code, $deliverable_postcodes[$location_id]);

$response = [
    'success' => true,
    'can_deliver' => $can_deliver,
    'delivery_fee' => $can_deliver ? DELIVERY_FEE : null,
    'min_order' => $can_deliver ? MIN_ORDER_AMOUNT : null,
    'message' => $can_deliver ? 
        'Great! We deliver to your area.' : 
        'Sorry, this address is outside our delivery area. Pickup is available.'
];

echo json_encode($response);
?>