<?php
// api/clear-cart.php - Clear entire cart
require_once '../../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to clear cart']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get current cart count for response
    $previous_count = 0;
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $previous_count += $item['quantity'];
        }
    }
    
    // Clear the cart
    $_SESSION['cart'] = [];
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Cart cleared successfully',
        'previous_count' => $previous_count,
        'cart_count' => 0,
        'cart_empty' => true,
        'subtotal' => 0,
        'subtotal_formatted' => formatPrice(0),
        'tax_amount' => 0,
        'tax_formatted' => formatPrice(0),
        'delivery_fee' => 0,
        'delivery_formatted' => 'FREE',
        'total' => 0,
        'total_formatted' => formatPrice(0)
    ]);
    
} catch (Exception $e) {
    logError('Clear cart error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
?>