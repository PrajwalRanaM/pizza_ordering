<?php
require_once '../includes/init.php';

header('Content-Type: application/json');

// Handle the location clearing...

// Clear from session
unset($_SESSION[SESSION_LOCATION_ID]);

// Clear cookie
setcookie(COOKIE_LOCATION, '', time() - 3600, '/');

echo json_encode(['success' => true]);