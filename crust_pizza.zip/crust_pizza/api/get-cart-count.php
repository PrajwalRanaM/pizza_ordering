<?php
// api/get-cart-count.php - Get cart count for header badge
require_once '../../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    echo json_encode([
        'success' => true,
        'cart_count' => 0,
        'logged_in' => false
    ]);
    exit;
}

try {
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Calculate cart count
    $cart_count = 0;
    $cart_subtotal = 0;
    
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
        $cart_subtotal += $item['price'] * $item['quantity'];
    }
    
    // Return cart information
    echo json_encode([
        'success' => true,
        'cart_count' => $cart_count,
        'cart_subtotal' => $cart_subtotal,
        'cart_subtotal_formatted' => formatPrice($cart_subtotal),
        'logged_in' => true,
        'user_name' => getCurrentUserName(),
        'min_order_met' => $cart_subtotal >= MIN_ORDER_AMOUNT,
        'free_delivery' => $cart_subtotal >= FREE_DELIVERY_AMOUNT
    ]);
    
} catch (Exception $e) {
    logError('Get cart count error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred',
        'cart_count' => 0
    ]);
}
?>