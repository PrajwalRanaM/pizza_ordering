<?php
// api/remove-from-cart.php - Remove item from cart
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to modify cart']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$cart_key = $input['cart_key'] ?? null;

// Validate input
if (!$cart_key) {
    echo json_encode(['success' => false, 'message' => 'Invalid cart item']);
    exit;
}

try {
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Check if cart item exists
    if (!isset($_SESSION['cart'][$cart_key])) {
        echo json_encode(['success' => false, 'message' => 'Item not found in cart']);
        exit;
    }
    
    // Store item info for response
    $removed_item = $_SESSION['cart'][$cart_key];
    
    // Remove item from cart
    unset($_SESSION['cart'][$cart_key]);
    
    // Calculate new cart totals
    $cart_count = 0;
    $cart_subtotal = 0;
    
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
        $cart_subtotal += $item['price'] * $item['quantity'];
    }
    
    // Calculate order totals
    $tax_amount = $cart_subtotal * TAX_RATE;
    $delivery_fee = ($cart_subtotal >= FREE_DELIVERY_AMOUNT) ? 0 : DELIVERY_FEE;
    $total_amount = $cart_subtotal + $delivery_fee + $tax_amount;
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Item removed from cart',
        'removed_item' => [
            'name' => $removed_item['product_name'],
            'quantity' => $removed_item['quantity']
        ],
        'cart_count' => $cart_count,
        'cart_empty' => empty($_SESSION['cart']),
        'subtotal' => $cart_subtotal,
        'subtotal_formatted' => formatPrice($cart_subtotal),
        'tax_amount' => $tax_amount,
        'tax_formatted' => formatPrice($tax_amount),
        'delivery_fee' => $delivery_fee,
        'delivery_formatted' => $delivery_fee > 0 ? formatPrice($delivery_fee) : 'FREE',
        'total' => $total_amount,
        'total_formatted' => formatPrice($total_amount),
        'min_order_met' => $cart_subtotal >= MIN_ORDER_AMOUNT,
        'free_delivery' => $cart_subtotal >= FREE_DELIVERY_AMOUNT
    ]);
    
} catch (Exception $e) {
    logError('Remove from cart error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
?>