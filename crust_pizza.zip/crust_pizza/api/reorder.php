<?php
// api/reorder.php - Add previous order items to cart
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to reorder items']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$order_id = $input['order_id'] ?? null;

// Validate input
if (!$order_id || !is_numeric($order_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID']);
    exit;
}

$customer_id = getCurrentUserId();

try {
    // Verify the order belongs to the customer
    $order_stmt = $conn->prepare("
        SELECT order_id, order_status_id, location_id 
        FROM orders 
        WHERE order_id = ? AND customer_id = ?
    ");
    $order_stmt->bind_param("ii", $order_id, $customer_id);
    $order_stmt->execute();
    $order_result = $order_stmt->get_result();
    
    if ($order_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found or access denied']);
        exit;
    }
    
    $order = $order_result->fetch_assoc();
    
    // Check if order is completed (only allow reordering completed orders)
    if (!in_array($order['order_status_id'], [ORDER_STATUS_DELIVERED, ORDER_STATUS_PICKED_UP])) {
        echo json_encode(['success' => false, 'message' => 'Can only reorder completed orders']);
        exit;
    }
    
    // Get order items
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_id, p.is_active
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id
    ");
    $items_stmt->bind_param("i", $order_id);
    $items_stmt->execute();
    $order_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    if (empty($order_items)) {
        echo json_encode(['success' => false, 'message' => 'No items found in this order']);
        exit;
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    $added_items = 0;
    $skipped_items = 0;
    $added_item_names = [];
    
    foreach ($order_items as $item) {
        // Skip items that are no longer active
        if ($item['product_id'] && $item['is_active'] == 0) {
            $skipped_items++;
            continue;
        }
        
        if ($item['item_type'] === 'preset') {
            // Handle preset items
            if (!$item['product_id']) {
                $skipped_items++;
                continue;
            }
            
            // Get current product and size details
            $product_stmt = $conn->prepare("
                SELECT p.product_name, p.base_price, p.is_active
                FROM products p
                WHERE p.product_id = ? AND p.is_active = 1
            ");
            $product_stmt->bind_param("i", $item['product_id']);
            $product_stmt->execute();
            $product_result = $product_stmt->get_result();
            
            if ($product_result->num_rows === 0) {
                $skipped_items++;
                continue;
            }
            
            $product = $product_result->fetch_assoc();
            
            // For preset items, we need to determine the size
            // This is a simplified approach - in a real system you'd store size_id with order_items
            $size_stmt = $conn->prepare("
                SELECT size_id, size_name, price_multiplier 
                FROM crust_sizes 
                WHERE is_active = 1 
                ORDER BY size_id 
                LIMIT 1
            ");
            $size_stmt->execute();
            $size_result = $size_stmt->get_result();
            
            if ($size_result->num_rows === 0) {
                $skipped_items++;
                continue;
            }
            
            $size = $size_result->fetch_assoc();
            $current_price = $product['base_price'] * $size['price_multiplier'];
            
            // Create cart item key
            $cart_key = "preset_{$item['product_id']}_{$size['size_id']}_reorder_" . time() . "_" . $added_items;
            
            // Add to cart
            $_SESSION['cart'][$cart_key] = [
                'type' => 'preset',
                'product_id' => $item['product_id'],
                'product_name' => $product['product_name'],
                'size_id' => $size['size_id'],
                'size_name' => $size['size_name'],
                'price' => $current_price,
                'quantity' => $item['quantity'],
                'added_at' => time()
            ];
            
            $added_items += $item['quantity'];
            $added_item_names[] = $item['quantity'] . 'x ' . $product['product_name'];
            
        } else if ($item['item_type'] === 'custom') {
            // Handle custom pizzas
            $custom_stmt = $conn->prepare("
                SELECT cp.*, cs.size_name, cs.price_multiplier, ct.crust_name, 
                       s.sauce_name, ch.cheese_name
                FROM custom_pizzas cp
                JOIN crust_sizes cs ON cp.size_id = cs.size_id
                JOIN crust_types ct ON cp.crust_type_id = ct.crust_type_id
                LEFT JOIN sauces s ON cp.sauce_id = s.sauce_id
                LEFT JOIN cheese_types ch ON cp.cheese_id = ch.cheese_id
                WHERE cp.order_item_id = ?
            ");
            $custom_stmt->bind_param("i", $item['order_item_id']);
            $custom_stmt->execute();
            $custom_result = $custom_stmt->get_result();
            
            if ($custom_result->num_rows === 0) {
                $skipped_items++;
                continue;
            }
            
            $custom_details = $custom_result->fetch_assoc();
            
            // Get toppings
            $toppings_stmt = $conn->prepare("
                SELECT cpt.ingredient_id, i.ingredient_name, i.price, i.is_active
                FROM custom_pizza_toppings cpt
                JOIN ingredients i ON cpt.ingredient_id = i.ingredient_id
                WHERE cpt.custom_pizza_id = ?
            ");
            $toppings_stmt->bind_param("i", $custom_details['custom_pizza_id']);
            $toppings_stmt->execute();
            $toppings_result = $toppings_stmt->get_result();
            
            $toppings = [];
            $toppings_price = 0;
            $topping_names = [];
            
            while ($topping = $toppings_result->fetch_assoc()) {
                if ($topping['is_active']) {
                    $toppings[] = $topping['ingredient_id'];
                    $toppings_price += $topping['price'];
                    $topping_names[] = $topping['ingredient_name'];
                }
            }
            
            // Calculate custom pizza price
            $base_price = 15.90; // Base price for custom pizza
            $size_price = $base_price * $custom_details['price_multiplier'];
            $extra_cheese_price = ($custom_details['cheese_amount'] === 'extra') ? 2.00 : 0;
            $custom_price = $size_price + $toppings_price + $extra_cheese_price;
            
            // Create description
            $description = $custom_details['size_name'] . " " . $custom_details['crust_name'] . " crust";
            if ($custom_details['sauce_name']) {
                $description .= ", " . $custom_details['sauce_name'];
            }
            if ($custom_details['cheese_name'] && $custom_details['cheese_amount'] !== 'none') {
                $description .= ", " . $custom_details['cheese_name'];
                if ($custom_details['cheese_amount'] === 'extra') {
                    $description .= " (extra)";
                }
            }
            if (!empty($topping_names)) {
                $description .= ", " . implode(', ', $topping_names);
            }
            
            // Create cart item key
            $cart_key = 'custom_reorder_' . time() . '_' . $added_items;
            
            // Add to cart
            $_SESSION['cart'][$cart_key] = [
                'type' => 'custom',
                'product_name' => 'Build Your Own Pizza',
                'description' => $description,
                'size_id' => $custom_details['size_id'],
                'size_name' => $custom_details['size_name'],
                'crust_type_id' => $custom_details['crust_type_id'],
                'sauce_id' => $custom_details['sauce_id'],
                'cheese_id' => $custom_details['cheese_id'],
                'cheese_amount' => $custom_details['cheese_amount'],
                'toppings' => $toppings,
                'price' => $custom_price,
                'quantity' => $item['quantity'],
                'added_at' => time()
            ];
            
            $added_items += $item['quantity'];
            $added_item_names[] = $item['quantity'] . 'x Custom Pizza';
        }
    }
    
    // Calculate new cart totals
    $cart_count = 0;
    $cart_total = 0;
    
    foreach ($_SESSION['cart'] as $cart_item) {
        $cart_count += $cart_item['quantity'];
        $cart_total += $cart_item['price'] * $cart_item['quantity'];
    }
    
    // Prepare response message
    $message = '';
    if ($added_items > 0) {
        $message = "Added {$added_items} item" . ($added_items !== 1 ? 's' : '') . " to your cart";
        if ($skipped_items > 0) {
            $message .= ". {$skipped_items} item" . ($skipped_items !== 1 ? 's were' : ' was') . " skipped (no longer available)";
        }
    } else {
        $message = "No items could be added. All items from this order are no longer available.";
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => $message,
        'added_items' => $added_items,
        'skipped_items' => $skipped_items,
        'cart_count' => $cart_count,
        'cart_total' => formatPrice($cart_total),
        'cart_raw_total' => $cart_total,
        'item_details' => $added_item_names
    ]);
    
} catch (Exception $e) {
    logError('Reorder error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while processing your reorder. Please try again.']);
}
?>