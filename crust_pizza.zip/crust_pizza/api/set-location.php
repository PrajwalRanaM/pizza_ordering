<?php
require_once '../includes/init.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$location_id = $input['location_id'] ?? null;

if (!$location_id || !is_numeric($location_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid location ID']);
    exit;
}

// Verify location exists and is active
$stmt = $conn->prepare("SELECT location_id FROM locations WHERE location_id = ? AND is_active = 1");
$stmt->bind_param("i", $location_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive location']);
    exit;
}

// Set location in session
$_SESSION[SESSION_LOCATION_ID] = $location_id;

// Set cookie for 30 days
setcookie(COOKIE_LOCATION, $location_id, time() + (30 * 24 * 60 * 60), '/');

echo json_encode(['success' => true, 'location_id' => $location_id]);

$stmt->close();
$conn->close();