<?php
// api/update-cart.php - Update cart item quantity
require_once '../includes/init.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Please login to update cart']);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$cart_key = $input['cart_key'] ?? null;
$quantity = $input['quantity'] ?? null;

// Validate input
if (!$cart_key || !is_numeric($quantity)) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$quantity = max(1, min(20, (int)$quantity)); // Limit quantity between 1-20

try {
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Check if cart item exists
    if (!isset($_SESSION['cart'][$cart_key])) {
        echo json_encode(['success' => false, 'message' => 'Item not found in cart']);
        exit;
    }
    
    // Update quantity
    $_SESSION['cart'][$cart_key]['quantity'] = $quantity;
    
    // Calculate new cart totals
    $cart_count = 0;
    $cart_subtotal = 0;
    
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
        $cart_subtotal += $item['price'] * $item['quantity'];
    }
    
    // Calculate order totals
    $tax_amount = $cart_subtotal * TAX_RATE;
    $delivery_fee = ($cart_subtotal >= FREE_DELIVERY_AMOUNT) ? 0 : DELIVERY_FEE;
    $total_amount = $cart_subtotal + $delivery_fee + $tax_amount;
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Cart updated successfully',
        'cart_key' => $cart_key,
        'new_quantity' => $quantity,
        'cart_count' => $cart_count,
        'subtotal' => $cart_subtotal,
        'subtotal_formatted' => formatPrice($cart_subtotal),
        'tax_amount' => $tax_amount,
        'tax_formatted' => formatPrice($tax_amount),
        'delivery_fee' => $delivery_fee,
        'delivery_formatted' => $delivery_fee > 0 ? formatPrice($delivery_fee) : 'FREE',
        'total' => $total_amount,
        'total_formatted' => formatPrice($total_amount),
        'min_order_met' => $cart_subtotal >= MIN_ORDER_AMOUNT,
        'free_delivery' => $cart_subtotal >= FREE_DELIVERY_AMOUNT
    ]);
    
} catch (Exception $e) {
    logError('Update cart error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']);
}
?>