<?php
// public/builder.php - Pizza Builder Page
require_once 'includes/init.php';

// Check if location is selected
$selected_location = getSelectedLocation();
if (!$selected_location) {
    setFlashMessage('Please select a location first to build your pizza.', 'warning');
    redirect('index.php');
}

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'builder.php';
    setFlashMessage('Please login to create your custom pizza.', 'info');
    redirect('login.php');
}

// Check if store is open
if (!isStoreOpen()) {
    setFlashMessage('Sorry, we are currently closed. Please come back during business hours.', 'warning');
    redirect('menu.php');
}

// Fetch pizza building components
// 1. Crust Sizes
$sizes_sql = "SELECT size_id, size_name, size_code, price_multiplier 
              FROM crust_sizes 
              WHERE is_active = 1 
              ORDER BY size_id";
$sizes = $conn->query($sizes_sql)->fetch_all(MYSQLI_ASSOC);

// 2. Crust Types
$crusts_sql = "SELECT crust_type_id, crust_name, description, additional_price, 
                      is_gluten_free, is_vegan 
               FROM crust_types 
               WHERE is_active = 1 
               ORDER BY crust_type_id";
$crusts = $conn->query($crusts_sql)->fetch_all(MYSQLI_ASSOC);

// 3. Sauces
$sauces_sql = "SELECT sauce_id, sauce_name, description, is_vegan 
               FROM sauces 
               WHERE is_active = 1 
               ORDER BY sauce_id";
$sauces = $conn->query($sauces_sql)->fetch_all(MYSQLI_ASSOC);

// 4. Cheese Types
$cheese_sql = "SELECT cheese_id, cheese_name, description, is_vegan 
               FROM cheese_types 
               WHERE is_active = 1 
               ORDER BY cheese_id";
$cheeses = $conn->query($cheese_sql)->fetch_all(MYSQLI_ASSOC);

// 5. Toppings (Ingredients)
$toppings_sql = "SELECT ingredient_id, ingredient_name, description, category, 
                        price, is_vegan, is_gluten_free 
                 FROM ingredients 
                 WHERE is_active = 1 
                 AND category IN ('vegetarian', 'non-vegetarian')
                 ORDER BY category DESC, ingredient_name";
$toppings = $conn->query($toppings_sql)->fetch_all(MYSQLI_ASSOC);

// Base price for custom pizza
$base_price = 15.90; // From the database or config

// Include header
$current_page = 'builder.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Build Your Own Pizza - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/builder.css">
</head>
<body>
    <div class="builder-container">
        <!-- Main Builder Section -->
        <div class="builder-main">
            <!-- Progress Steps -->
            <div class="progress-steps">
                <div class="steps-container">
                    <div class="progress-line">
                        <div class="progress-line-fill" id="progressFill"></div>
                    </div>
                    <div class="step active" data-step="1">
                        <div class="step-number">1</div>
                        <div class="step-title">Size</div>
                    </div>
                    <div class="step" data-step="2">
                        <div class="step-number">2</div>
                        <div class="step-title">Crust</div>
                    </div>
                    <div class="step" data-step="3">
                        <div class="step-number">3</div>
                        <div class="step-title">Sauce</div>
                    </div>
                    <div class="step" data-step="4">
                        <div class="step-number">4</div>
                        <div class="step-title">Cheese</div>
                    </div>
                    <div class="step" data-step="5">
                        <div class="step-number">5</div>
                        <div class="step-title">Toppings</div>
                    </div>
                </div>
            </div>

            <!-- Step 1: Size Selection -->
            <div class="builder-step active" id="step-1">
                <div class="step-header">
                    <h2>Choose Your Pizza Size</h2>
                    <p>Select the perfect size for your appetite</p>
                </div>
                <div class="options-grid">
                    <?php foreach ($sizes as $size): ?>
                    <div class="option-card size-option" data-size-id="<?php echo $size['size_id']; ?>" 
                         data-multiplier="<?php echo $size['price_multiplier']; ?>">
                        <div class="option-icon">🍕</div>
                        <div class="option-name"><?php echo e($size['size_name']); ?></div>
                        <div class="option-price">
                            <?php echo formatPrice($base_price * $size['price_multiplier']); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="step-navigation">
                    <button class="nav-btn btn-prev" disabled>Previous</button>
                    <button class="nav-btn btn-next" onclick="nextStep()" disabled>Next</button>
                </div>
            </div>

            <!-- Step 2: Crust Selection -->
            <div class="builder-step" id="step-2">
                <div class="step-header">
                    <h2>Select Your Crust Type</h2>
                    <p>Choose from our variety of delicious crusts</p>
                </div>
                <div class="options-grid">
                    <?php foreach ($crusts as $crust): ?>
                    <div class="option-card crust-option" data-crust-id="<?php echo $crust['crust_type_id']; ?>"
                         data-price="<?php echo $crust['additional_price']; ?>">
                        <div class="option-icon">🥖</div>
                        <div class="option-name"><?php echo e($crust['crust_name']); ?></div>
                        <?php if ($crust['additional_price'] > 0): ?>
                        <div class="option-price">+<?php echo formatPrice($crust['additional_price']); ?></div>
                        <?php endif; ?>
                        <div class="option-description"><?php echo e($crust['description']); ?></div>
                        <?php if ($crust['is_gluten_free']): ?>
                        <span class="badge badge-gluten-free">Gluten Free</span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="step-navigation">
                    <button class="nav-btn btn-prev" onclick="prevStep()">Previous</button>
                    <button class="nav-btn btn-next" onclick="nextStep()" disabled>Next</button>
                </div>
            </div>

            <!-- Step 3: Sauce Selection -->
            <div class="builder-step" id="step-3">
                <div class="step-header">
                    <h2>Choose Your Sauce</h2>
                    <p>Select the perfect base sauce for your pizza</p>
                </div>
                <div class="options-grid">
                    <?php foreach ($sauces as $sauce): ?>
                    <div class="option-card sauce-option" data-sauce-id="<?php echo $sauce['sauce_id']; ?>">
                        <div class="option-icon">🥫</div>
                        <div class="option-name"><?php echo e($sauce['sauce_name']); ?></div>
                        <div class="option-description"><?php echo e($sauce['description']); ?></div>
                        <?php if ($sauce['is_vegan']): ?>
                        <span class="badge badge-vegan">Vegan</span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="step-navigation">
                    <button class="nav-btn btn-prev" onclick="prevStep()">Previous</button>
                    <button class="nav-btn btn-next" onclick="nextStep()" disabled>Next</button>
                </div>
            </div>

            <!-- Step 4: Cheese Selection -->
            <div class="builder-step" id="step-4">
                <div class="step-header">
                    <h2>Select Your Cheese</h2>
                    <p>Choose your cheese and amount</p>
                </div>
                <div class="options-grid">
                    <?php foreach ($cheeses as $cheese): ?>
                    <div class="option-card cheese-option" data-cheese-id="<?php echo $cheese['cheese_id']; ?>">
                        <div class="option-icon">🧀</div>
                        <div class="option-name"><?php echo e($cheese['cheese_name']); ?></div>
                        <div class="option-description"><?php echo e($cheese['description']); ?></div>
                        <?php if ($cheese['is_vegan']): ?>
                        <span class="badge badge-vegan">Vegan</span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <h3 style="margin-top: 30px; margin-bottom: 15px;">Cheese Amount</h3>
                <div class="options-grid">
                    <div class="option-card cheese-amount-option" data-amount="none">
                        <div class="option-icon">❌</div>
                        <div class="option-name">No Cheese</div>
                    </div>
                    <div class="option-card cheese-amount-option selected" data-amount="regular">
                        <div class="option-icon">🧀</div>
                        <div class="option-name">Regular</div>
                    </div>
                    <div class="option-card cheese-amount-option" data-amount="extra" data-price="2.00">
                        <div class="option-icon">🧀🧀</div>
                        <div class="option-name">Extra Cheese</div>
                        <div class="option-price">+<?php echo formatPrice(2.00); ?></div>
                    </div>
                </div>
                
                <div class="step-navigation">
                    <button class="nav-btn btn-prev" onclick="prevStep()">Previous</button>
                    <button class="nav-btn btn-next" onclick="nextStep()">Next</button>
                </div>
            </div>

            <!-- Step 5: Toppings Selection -->
            <div class="builder-step" id="step-5">
                <div class="step-header">
                    <h2>Add Your Favorite Toppings</h2>
                    <p>Customize your pizza with our fresh toppings</p>
                </div>
                
                <?php 
                $vegetarian_toppings = array_filter($toppings, function($t) { return $t['category'] === 'vegetarian'; });
                $meat_toppings = array_filter($toppings, function($t) { return $t['category'] === 'non-vegetarian'; });
                ?>
                
                <div class="toppings-section">
                    <h3>🥗 Vegetarian Toppings</h3>
                    <?php foreach ($vegetarian_toppings as $topping): ?>
                    <div class="topping-item" data-topping-id="<?php echo $topping['ingredient_id']; ?>"
                         data-price="<?php echo $topping['price']; ?>">
                        <div class="topping-info">
                            <input type="checkbox" class="topping-checkbox" 
                                   id="topping-<?php echo $topping['ingredient_id']; ?>">
                            <label for="topping-<?php echo $topping['ingredient_id']; ?>" class="topping-name">
                                <?php echo e($topping['ingredient_name']); ?>
                            </label>
                            <div class="topping-badges">
                                <?php if ($topping['is_vegan']): ?>
                                <span class="badge badge-vegan">Vegan</span>
                                <?php endif; ?>
                                <?php if ($topping['is_gluten_free']): ?>
                                <span class="badge badge-gluten-free">GF</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="topping-price">+<?php echo formatPrice($topping['price']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="toppings-section">
                    <h3>🥩 Meat Toppings</h3>
                    <?php foreach ($meat_toppings as $topping): ?>
                    <div class="topping-item" data-topping-id="<?php echo $topping['ingredient_id']; ?>"
                         data-price="<?php echo $topping['price']; ?>">
                        <div class="topping-info">
                            <input type="checkbox" class="topping-checkbox" 
                                   id="topping-<?php echo $topping['ingredient_id']; ?>">
                            <label for="topping-<?php echo $topping['ingredient_id']; ?>" class="topping-name">
                                <?php echo e($topping['ingredient_name']); ?>
                            </label>
                        </div>
                        <div class="topping-price">+<?php echo formatPrice($topping['price']); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="step-navigation">
                    <button class="nav-btn btn-prev" onclick="prevStep()">Previous</button>
                    <button class="nav-btn btn-next" onclick="finishPizza()">Finish Pizza</button>
                </div>
            </div>
        </div>

        <!-- Order Summary Sidebar -->
        <div class="order-summary">
            <div class="summary-header">
                <h3>Your Custom Pizza</h3>
                <div class="pizza-preview" id="pizzaPreview">🍕</div>
            </div>
            
            <div class="summary-details">
                <div class="summary-item">
                    <span class="summary-item-label">Size:</span>
                    <span class="summary-item-value" id="summary-size">-</span>
                </div>
                <div class="summary-item">
                    <span class="summary-item-label">Crust:</span>
                    <span class="summary-item-value" id="summary-crust">-</span>
                </div>
                <div class="summary-item">
                    <span class="summary-item-label">Sauce:</span>
                    <span class="summary-item-value" id="summary-sauce">-</span>
                </div>
                <div class="summary-item">
                    <span class="summary-item-label">Cheese:</span>
                    <span class="summary-item-value" id="summary-cheese">-</span>
                </div>
                
                <div class="summary-toppings" id="summary-toppings" style="display: none;">
                    <h4>Toppings:</h4>
                    <div class="topping-list" id="topping-list"></div>
                </div>
            </div>
            
            <div class="summary-total">
                <div class="total-row">
                    <span class="total-label">Total:</span>
                    <span class="total-amount" id="total-amount"><?php echo formatPrice($base_price); ?></span>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <label for="quantity">Quantity:</label>
                <select id="quantity" style="width: 100%; padding: 8px; margin-top: 5px;">
                    <?php for ($i = 1; $i <= 10; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <button class="add-to-cart-btn" id="addToCartBtn" disabled onclick="addCustomPizzaToCart()">
                Complete Your Pizza First
            </button>
        </div>
    </div>

    <?php include 'templates/footer.php'; ?>

    <script>
    // Pizza Builder State
    const pizzaState = {
        currentStep: 1,
        selections: {
            size: null,
            crust: null,
            sauce: null,
            cheese: null,
            cheeseAmount: 'regular',
            toppings: []
        },
        prices: {
            base: <?php echo $base_price; ?>,
            sizeMultiplier: 1,
            crust: 0,
            cheeseExtra: 0,
            toppings: 0
        }
    };

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        initializeEventListeners();
        updateProgressBar();
        updateSummary();
    });

    function initializeEventListeners() {
        // Size selection
        document.querySelectorAll('.size-option').forEach(option => {
            option.addEventListener('click', function() {
                selectOption(this, 'size');
                pizzaState.selections.size = {
                    id: this.dataset.sizeId,
                    name: this.querySelector('.option-name').textContent,
                    multiplier: parseFloat(this.dataset.multiplier)
                };
                pizzaState.prices.sizeMultiplier = parseFloat(this.dataset.multiplier);
                updateSummary();
                enableNextButton();
            });
        });

        // Crust selection
        document.querySelectorAll('.crust-option').forEach(option => {
            option.addEventListener('click', function() {
                selectOption(this, 'crust');
                pizzaState.selections.crust = {
                    id: this.dataset.crustId,
                    name: this.querySelector('.option-name').textContent,
                    price: parseFloat(this.dataset.price) || 0
                };
                pizzaState.prices.crust = parseFloat(this.dataset.price) || 0;
                updateSummary();
                enableNextButton();
            });
        });

        // Sauce selection
        document.querySelectorAll('.sauce-option').forEach(option => {
            option.addEventListener('click', function() {
                selectOption(this, 'sauce');
                pizzaState.selections.sauce = {
                    id: this.dataset.sauceId,
                    name: this.querySelector('.option-name').textContent
                };
                updateSummary();
                enableNextButton();
            });
        });

        // Cheese selection
        document.querySelectorAll('.cheese-option').forEach(option => {
            option.addEventListener('click', function() {
                selectOption(this, 'cheese');
                pizzaState.selections.cheese = {
                    id: this.dataset.cheeseId,
                    name: this.querySelector('.option-name').textContent
                };
                updateSummary();
                enableNextButton();
            });
        });

        // Cheese amount selection
        document.querySelectorAll('.cheese-amount-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.cheese-amount-option').forEach(opt => {
                    opt.classList.remove('selected');
                });
                this.classList.add('selected');
                
                pizzaState.selections.cheeseAmount = this.dataset.amount;
                pizzaState.prices.cheeseExtra = this.dataset.amount === 'extra' ? 
                    parseFloat(this.dataset.price) || 0 : 0;
                
                updateSummary();
                
                // Enable next button if cheese is selected or no cheese
                if (pizzaState.selections.cheese || this.dataset.amount === 'none') {
                    enableNextButton();
                }
            });
        });

        // Topping selection
        document.querySelectorAll('.topping-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const toppingItem = this.closest('.topping-item');
                const toppingId = toppingItem.dataset.toppingId;
                const toppingName = toppingItem.querySelector('.topping-name').textContent.trim();
                const toppingPrice = parseFloat(toppingItem.dataset.price);
                
                if (this.checked) {
                    toppingItem.classList.add('selected');
                    pizzaState.selections.toppings.push({
                        id: toppingId,
                        name: toppingName,
                        price: toppingPrice
                    });
                } else {
                    toppingItem.classList.remove('selected');
                    pizzaState.selections.toppings = pizzaState.selections.toppings.filter(
                        t => t.id !== toppingId
                    );
                }
                
                updateToppingsPrice();
                updateSummary();
            });
        });

        // Quantity change
        document.getElementById('quantity').addEventListener('change', function() {
            updateSummary();
        });
    }

    function selectOption(element, type) {
        // Remove selected class from siblings
        element.parentElement.querySelectorAll('.option-card').forEach(card => {
            card.classList.remove('selected');
        });
        // Add selected class
        element.classList.add('selected');
    }

    function enableNextButton() {
        const nextBtn = document.querySelector(`#step-${pizzaState.currentStep} .btn-next`);
        if (nextBtn) {
            nextBtn.disabled = false;
        }
    }

    function updateToppingsPrice() {
        pizzaState.prices.toppings = pizzaState.selections.toppings.reduce(
            (sum, topping) => sum + topping.price, 0
        );
    }

    function nextStep() {
        if (pizzaState.currentStep < 5) {
            // Mark current step as completed
            document.querySelector(`[data-step="${pizzaState.currentStep}"]`).classList.add('completed');
            
            // Hide current step
            document.getElementById(`step-${pizzaState.currentStep}`).classList.remove('active');
            
            // Move to next step
            pizzaState.currentStep++;
            
            // Show next step
            document.getElementById(`step-${pizzaState.currentStep}`).classList.add('active');
            document.querySelector(`[data-step="${pizzaState.currentStep}"]`).classList.add('active');
            
            updateProgressBar();
            
            // Special handling for last step
            if (pizzaState.currentStep === 5) {
                checkIfCanAddToCart();
            }
        }
    }

    function prevStep() {
        if (pizzaState.currentStep > 1) {
            // Remove active from current step
            document.getElementById(`step-${pizzaState.currentStep}`).classList.remove('active');
            document.querySelector(`[data-step="${pizzaState.currentStep}"]`).classList.remove('active');
            
            // Move to previous step
            pizzaState.currentStep--;
            
            // Show previous step
            document.getElementById(`step-${pizzaState.currentStep}`).classList.add('active');
            document.querySelector(`[data-step="${pizzaState.currentStep}"]`).classList.add('active');
            
            updateProgressBar();
        }
    }

    function updateProgressBar() {
        const progress = ((pizzaState.currentStep - 1) / 4) * 100;
        document.getElementById('progressFill').style.width = progress + '%';
    }

    function updateSummary() {
        // Update individual items
        document.getElementById('summary-size').textContent = 
            pizzaState.selections.size ? pizzaState.selections.size.name : '-';
        
        document.getElementById('summary-crust').textContent = 
            pizzaState.selections.crust ? pizzaState.selections.crust.name : '-';
        
        document.getElementById('summary-sauce').textContent = 
            pizzaState.selections.sauce ? pizzaState.selections.sauce.name : '-';
        
        // Update cheese display
        let cheeseText = '-';
        if (pizzaState.selections.cheeseAmount === 'none') {
            cheeseText = 'No Cheese';
        } else if (pizzaState.selections.cheese) {
            cheeseText = pizzaState.selections.cheese.name;
            if (pizzaState.selections.cheeseAmount === 'extra') {
                cheeseText += ' (Extra)';
            }
        }
        document.getElementById('summary-cheese').textContent = cheeseText;
        
        // Update toppings
        const toppingsList = document.getElementById('topping-list');
        const toppingsSection = document.getElementById('summary-toppings');
        
        if (pizzaState.selections.toppings.length > 0) {
            toppingsSection.style.display = 'block';
            toppingsList.innerHTML = pizzaState.selections.toppings
                .map(t => `• ${t.name}`)
                .join('<br>');
        } else {
            toppingsSection.style.display = 'none';
        }
        
        // Calculate total
        const baseTotal = pizzaState.prices.base * pizzaState.prices.sizeMultiplier;
        const crustPrice = pizzaState.prices.crust;
        const cheeseExtraPrice = pizzaState.prices.cheeseExtra;
        const toppingsPrice = pizzaState.prices.toppings;
        const subtotal = baseTotal + crustPrice + cheeseExtraPrice + toppingsPrice;
        
        const quantity = parseInt(document.getElementById('quantity').value) || 1;
        const total = subtotal * quantity;
        
        document.getElementById('total-amount').textContent = formatPrice(total);
        
        // Update preview animation
        animatePizzaPreview();
    }

    function formatPrice(price) {
        return '<?php echo CURRENCY_SYMBOL; ?>' + price.toFixed(2);
    }

    function animatePizzaPreview() {
        const preview = document.getElementById('pizzaPreview');
        preview.classList.add('pulse');
        setTimeout(() => preview.classList.remove('pulse'), 1000);
    }

    function finishPizza() {
        // Mark last step as completed
        document.querySelector(`[data-step="5"]`).classList.add('completed');
        updateProgressBar();
        
        // Enable add to cart button
        const addBtn = document.getElementById('addToCartBtn');
        addBtn.disabled = false;
        addBtn.textContent = 'Add to Cart';
        addBtn.classList.add('pulse');
        
        // Show success message
        showNotification('Your pizza is ready! Click "Add to Cart" to continue.');
    }

    function checkIfCanAddToCart() {
        const hasAllSelections = pizzaState.selections.size && 
                               pizzaState.selections.crust && 
                               pizzaState.selections.sauce;
        
        if (hasAllSelections) {
            const addBtn = document.getElementById('addToCartBtn');
            addBtn.disabled = false;
            addBtn.textContent = 'Add to Cart';
        }
    }

    function addCustomPizzaToCart() {
        // Validate all selections
        if (!pizzaState.selections.size || !pizzaState.selections.crust || 
            !pizzaState.selections.sauce) {
            alert('Please complete all steps before adding to cart');
            return;
        }
        
        const quantity = parseInt(document.getElementById('quantity').value) || 1;
        
        // Prepare data for API
        const customPizza = {
            type: 'custom',
            size_id: pizzaState.selections.size.id,
            crust_type_id: pizzaState.selections.crust.id,
            sauce_id: pizzaState.selections.sauce.id,
            cheese_id: pizzaState.selections.cheese ? pizzaState.selections.cheese.id : null,
            cheese_amount: pizzaState.selections.cheeseAmount,
            toppings: pizzaState.selections.toppings.map(t => t.id),
            quantity: quantity,
            total_price: calculateTotal()
        };
        
        // Show loading state
        const addBtn = document.getElementById('addToCartBtn');
        addBtn.disabled = true;
        addBtn.textContent = 'Adding to Cart...';
        
        // Make API request
        fetch('api/add-custom-pizza.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(customPizza)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('Custom pizza added to cart!', 'success');
                
                // Update cart count if exists
                if (data.cart_count) {
                    updateCartCount(data.cart_count);
                }
                
                // Reset builder after delay
                setTimeout(() => {
                    if (confirm('Would you like to create another pizza?')) {
                        resetBuilder();
                    } else {
                        window.location.href = 'cart.php';
                    }
                }, 1500);
            } else {
                showNotification(data.message || 'Failed to add to cart', 'error');
                addBtn.disabled = false;
                addBtn.textContent = 'Add to Cart';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('An error occurred. Please try again.', 'error');
            addBtn.disabled = false;
            addBtn.textContent = 'Add to Cart';
        });
    }

    function calculateTotal() {
        const baseTotal = pizzaState.prices.base * pizzaState.prices.sizeMultiplier;
        const crustPrice = pizzaState.prices.crust;
        const cheeseExtraPrice = pizzaState.prices.cheeseExtra;
        const toppingsPrice = pizzaState.prices.toppings;
        return baseTotal + crustPrice + cheeseExtraPrice + toppingsPrice;
    }

    function resetBuilder() {
        // Reset state
        pizzaState.currentStep = 1;
        pizzaState.selections = {
            size: null,
            crust: null,
            sauce: null,
            cheese: null,
            cheeseAmount: 'regular',
            toppings: []
        };
        pizzaState.prices = {
            base: <?php echo $base_price; ?>,
            sizeMultiplier: 1,
            crust: 0,
            cheeseExtra: 0,
            toppings: 0
        };
        
        // Reset UI
        document.querySelectorAll('.builder-step').forEach(step => {
            step.classList.remove('active');
        });
        document.getElementById('step-1').classList.add('active');
        
        document.querySelectorAll('.step').forEach(step => {
            step.classList.remove('active', 'completed');
        });
        document.querySelector('[data-step="1"]').classList.add('active');
        
        document.querySelectorAll('.option-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        document.querySelectorAll('.topping-checkbox').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        document.querySelectorAll('.topping-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        // Reset quantity
        document.getElementById('quantity').value = '1';
        
        // Reset button
        const addBtn = document.getElementById('addToCartBtn');
        addBtn.disabled = true;
        addBtn.textContent = 'Complete Your Pizza First';
        addBtn.classList.remove('pulse');
        
        // Update display
        updateProgressBar();
        updateSummary();
    }

    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        `;
        
        switch(type) {
            case 'success':
                notification.style.background = '#00b894';
                break;
            case 'error':
                notification.style.background = '#d63031';
                break;
            default:
                notification.style.background = '#74b9ff';
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    function updateCartCount(count) {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = count;
            cartBadge.style.display = count > 0 ? 'inline-block' : 'none';
        }
    }

    // Add animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
    </script>
</body>
</html>