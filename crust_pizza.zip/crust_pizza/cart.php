<?php
// public/cart.php - Shopping Cart Page
require_once 'includes/init.php';

// Check if location is selected
$selected_location = getSelectedLocation();
if (!$selected_location) {
    setFlashMessage('Please select a location first to view your cart.', 'warning');
    redirect('index.php');
}

// Check if user is logged in
if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'cart.php';
    setFlashMessage('Please login to view your cart.', 'info');
    redirect('login.php');
}

// Get location details
$location_stmt = $conn->prepare("SELECT store_name, city, address, phone FROM locations WHERE location_id = ?");
$location_stmt->bind_param("i", $selected_location);
$location_stmt->execute();
$location = $location_stmt->get_result()->fetch_assoc();

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart = $_SESSION['cart'];
$cart_count = 0;
$cart_subtotal = 0;

// Calculate cart totals
foreach ($cart as $item) {
    $cart_count += $item['quantity'];
    $cart_subtotal += $item['price'] * $item['quantity'];
}

// Calculate order totals
$delivery_fee = DELIVERY_FEE;
$tax_rate = TAX_RATE;
$tax_amount = $cart_subtotal * $tax_rate;
$total_amount = $cart_subtotal + $delivery_fee + $tax_amount;

// Check if minimum order is met for delivery
$min_order_met = $cart_subtotal >= MIN_ORDER_AMOUNT;
$free_delivery = $cart_subtotal >= FREE_DELIVERY_AMOUNT;
if ($free_delivery) {
    $delivery_fee = 0;
    $total_amount = $cart_subtotal + $tax_amount;
}

// Include header
$current_page = 'cart.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/cart.css">
</head>
<body>
    <?php if (!isStoreOpen()): ?>
    <div class="store-closed-banner">
        🕐 Sorry, we're currently closed. We're open from <?php echo OPENING_HOUR; ?>:00 AM to <?php echo CLOSING_HOUR - 12; ?>:00 PM daily.
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success"><?php echo e($message); ?></div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('warning')): ?>
    <div class="flash-message flash-warning"><?php echo e($message); ?></div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('info')): ?>
    <div class="flash-message flash-info"><?php echo e($message); ?></div>
    <?php endif; ?>

    <!-- Cart Header -->
    <section class="cart-header">
        <h1>🛒 Your Cart</h1>
        <p><?php echo $cart_count; ?> item<?php echo $cart_count !== 1 ? 's' : ''; ?> ready for ordering</p>
    </section>

    <div class="cart-container">
        <!-- Cart Items -->
        <div class="cart-main">
            <?php if (empty($cart)): ?>
            <!-- Empty Cart -->
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h2>Your cart is empty</h2>
                <p>Looks like you haven't added any delicious pizzas yet!</p>
                <a href="menu.php" class="btn-shop">🍕 Browse Our Menu</a>
            </div>
            <?php else: ?>
            <!-- Cart Items Header -->
            <div class="cart-items-header">
                🍕 Your Items (<?php echo $cart_count; ?>)
            </div>

            <!-- Cart Items List -->
            <?php foreach ($cart as $cart_key => $item): ?>
            <div class="cart-item" data-cart-key="<?php echo e($cart_key); ?>">
                <div class="item-content">
                    <div class="item-image">
                        <?php if ($item['type'] === 'custom'): ?>
                            🎨
                        <?php else: ?>
                            🍕
                        <?php endif; ?>
                    </div>
                    
                    <div class="item-details">
                        <h4 class="item-name"><?php echo e($item['product_name']); ?></h4>
                        
                        <?php if (isset($item['description'])): ?>
                        <p class="item-description"><?php echo e($item['description']); ?></p>
                        <?php endif; ?>
                        
                        <?php if ($item['type'] === 'custom'): ?>
                        <!-- Custom Pizza Details -->
                        <div class="item-customizations">
                            <div class="customization-label">Size:</div>
                            <?php echo e($item['size_name']); ?>
                            
                            <?php if (isset($item['toppings']) && !empty($item['toppings'])): ?>
                            <div class="customization-label" style="margin-top: 5px;">Toppings:</div>
                            Custom selected toppings
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <!-- Preset Pizza Details -->
                        <div class="item-customizations">
                            <div class="customization-label">Size:</div>
                            <?php echo e($item['size_name']); ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="item-meta">
                            <div class="item-price">
                                <?php echo formatPrice($item['price']); ?> each
                            </div>
                            
                            <div class="quantity-control">
                                <button class="qty-btn" onclick="updateQuantity('<?php echo e($cart_key); ?>', -1)" 
                                        <?php echo $item['quantity'] <= 1 ? 'disabled' : ''; ?>>-</button>
                                <input type="number" class="qty-input" value="<?php echo $item['quantity']; ?>" 
                                       min="1" max="20" readonly>
                                <button class="qty-btn" onclick="updateQuantity('<?php echo e($cart_key); ?>', 1)" 
                                        <?php echo $item['quantity'] >= 20 ? 'disabled' : ''; ?>>+</button>
                            </div>
                            
                            <button class="remove-btn" onclick="removeItem('<?php echo e($cart_key); ?>')">
                                🗑️ Remove
                            </button>
                            
                            <div class="item-total">
                                <?php echo formatPrice($item['price'] * $item['quantity']); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Order Summary Sidebar -->
        <?php if (!empty($cart)): ?>
        <div class="order-summary">
            <div class="summary-header">
                <h3>Order Summary</h3>
                <div class="location-info">
                    📍 <?php echo e($location['store_name']); ?><br>
                    <?php echo e($location['city']); ?>
                </div>
            </div>

            <!-- Delivery Options -->
            <div class="delivery-options">
                <div class="delivery-option selected" data-type="delivery">
                    <input type="radio" name="order_type" value="delivery" checked>
                    <div class="delivery-info">
                        <div class="delivery-name">🚚 Delivery</div>
                        <div class="delivery-desc">Delivered to your door</div>
                    </div>
                    <div class="delivery-price">
                        <?php echo $free_delivery ? 'FREE' : formatPrice($delivery_fee); ?>
                    </div>
                </div>
                
                <div class="delivery-option" data-type="pickup">
                    <input type="radio" name="order_type" value="pickup">
                    <div class="delivery-info">
                        <div class="delivery-name">🏪 Pickup</div>
                        <div class="delivery-desc">Collect from store</div>
                    </div>
                    <div class="delivery-price">FREE</div>
                </div>
            </div>

            <!-- Free Delivery Banner -->
            <?php if ($free_delivery): ?>
            <div class="free-delivery-banner">
                🎉 You've earned FREE delivery!
            </div>
            <?php elseif ($cart_subtotal > 0): ?>
            <?php $remaining = FREE_DELIVERY_AMOUNT - $cart_subtotal; ?>
            <div class="minimum-order-warning">
                💡 Add <?php echo formatPrice($remaining); ?> more for FREE delivery!
            </div>
            <?php endif; ?>

            <!-- Minimum Order Warning -->
            <?php if (!$min_order_met && $cart_subtotal > 0): ?>
            <?php $remaining = MIN_ORDER_AMOUNT - $cart_subtotal; ?>
            <div class="minimum-order-warning">
                ⚠️ Minimum order for delivery: <?php echo formatPrice(MIN_ORDER_AMOUNT); ?><br>
                Add <?php echo formatPrice($remaining); ?> more to continue.
            </div>
            <?php endif; ?>

            <!-- Order Totals -->
            <div class="summary-section">
                <div class="summary-row">
                    <span class="summary-label">Subtotal (<?php echo $cart_count; ?> items):</span>
                    <span class="summary-value"><?php echo formatPrice($cart_subtotal); ?></span>
                </div>
                
                <div class="summary-row" id="delivery-fee-row">
                    <span class="summary-label">Delivery Fee:</span>
                    <span class="summary-value" id="delivery-fee-amount">
                        <?php echo $free_delivery ? 'FREE' : formatPrice($delivery_fee); ?>
                    </span>
                </div>
                
                <div class="summary-row">
                    <span class="summary-label">Tax (GST):</span>
                    <span class="summary-value"><?php echo formatPrice($tax_amount); ?></span>
                </div>
            </div>

            <div class="summary-section">
                <div class="summary-row">
                    <span class="summary-label summary-total">Total:</span>
                    <span class="summary-value summary-total" id="total-amount">
                        <?php echo formatPrice($total_amount); ?>
                    </span>
                </div>
            </div>

            <!-- Checkout Section -->
            <div class="checkout-section">
                <?php if (isStoreOpen()): ?>
                    <?php if ($min_order_met || $cart_subtotal == 0): ?>
                    <button class="btn-checkout" onclick="proceedToCheckout()" 
                            <?php echo empty($cart) ? 'disabled' : ''; ?>>
                        <?php echo empty($cart) ? 'Add Items to Continue' : 'Proceed to Checkout'; ?>
                    </button>
                    <?php else: ?>
                    <button class="btn-checkout" disabled>
                        Minimum Order Not Met
                    </button>
                    <?php endif; ?>
                <?php else: ?>
                <button class="btn-checkout" disabled>
                    Store Closed
                </button>
                <?php endif; ?>
                
                <div class="continue-shopping">
                    <a href="menu.php">← Continue Shopping</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <?php include 'templates/footer.php'; ?>

    <script>
    let isUpdating = false;

    // Update quantity
    function updateQuantity(cartKey, change) {
        if (isUpdating) return;
        
        const currentQty = parseInt(document.querySelector(`[data-cart-key="${cartKey}"] .qty-input`).value);
        const newQty = Math.max(1, Math.min(20, currentQty + change));
        
        if (newQty === currentQty) return;
        
        isUpdating = true;
        
        // Update UI immediately
        document.querySelector(`[data-cart-key="${cartKey}"] .qty-input`).value = newQty;
        
        // Make API request
        fetch('../api/update-cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cart_key: cartKey,
                quantity: newQty
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update the page with new totals
                updateCartDisplay(data);
                showNotification('Cart updated successfully', 'success');
            } else {
                // Revert on error
                document.querySelector(`[data-cart-key="${cartKey}"] .qty-input`).value = currentQty;
                showNotification(data.message || 'Failed to update cart', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            // Revert on error
            document.querySelector(`[data-cart-key="${cartKey}"] .qty-input`).value = currentQty;
            showNotification('Failed to update cart. Please try again.', 'error');
        })
        .finally(() => {
            isUpdating = false;
        });
    }

    // Remove item from cart
    function removeItem(cartKey) {
        if (isUpdating) return;
        
        if (!confirm('Are you sure you want to remove this item from your cart?')) {
            return;
        }
        
        isUpdating = true;
        
        // Add loading effect
        const itemElement = document.querySelector(`[data-cart-key="${cartKey}"]`);
        itemElement.classList.add('loading');
        
        fetch('../api/remove-from-cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                cart_key: cartKey
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove item from DOM
                itemElement.remove();
                
                // Update cart display
                updateCartDisplay(data);
                
                // Check if cart is empty
                if (data.cart_count === 0) {
                    location.reload(); // Reload to show empty cart
                } else {
                    showNotification('Item removed from cart', 'success');
                }
            } else {
                itemElement.classList.remove('loading');
                showNotification(data.message || 'Failed to remove item', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            itemElement.classList.remove('loading');
            showNotification('Failed to remove item. Please try again.', 'error');
        })
        .finally(() => {
            isUpdating = false;
        });
    }

    // Update cart display with new totals
    function updateCartDisplay(data) {
        // Update header
        const headerText = document.querySelector('.cart-header p');
        if (headerText) {
            headerText.textContent = `${data.cart_count} item${data.cart_count !== 1 ? 's' : ''} ready for ordering`;
        }
        
        // Update cart items header
        const itemsHeader = document.querySelector('.cart-items-header');
        if (itemsHeader) {
            itemsHeader.textContent = `🍕 Your Items (${data.cart_count})`;
        }
        
        // Update totals in summary
        if (data.subtotal !== undefined) {
            const subtotalElements = document.querySelectorAll('.summary-row .summary-value');
            if (subtotalElements[0]) {
                subtotalElements[0].textContent = data.subtotal_formatted;
            }
        }
        
        if (data.total !== undefined) {
            const totalElement = document.getElementById('total-amount');
            if (totalElement) {
                totalElement.textContent = data.total_formatted;
            }
        }
        
        // Update item totals
        document.querySelectorAll('.cart-item').forEach(item => {
            const cartKey = item.dataset.cartKey;
            const quantity = parseInt(item.querySelector('.qty-input').value);
            const priceText = item.querySelector('.item-price').textContent;
            const price = parseFloat(priceText.replace(/[^0-9.]/g, ''));
            const totalElement = item.querySelector('.item-total');
            if (totalElement) {
                totalElement.textContent = formatPrice(price * quantity);
            }
        });
        
        // Update quantity controls
        document.querySelectorAll('.cart-item').forEach(item => {
            const qtyInput = item.querySelector('.qty-input');
            const qty = parseInt(qtyInput.value);
            const decreaseBtn = item.querySelector('.qty-btn:first-child');
            const increaseBtn = item.querySelector('.qty-btn:last-child');
            
            decreaseBtn.disabled = qty <= 1;
            increaseBtn.disabled = qty >= 20;
        });
    }

    // Handle delivery option change
    document.addEventListener('DOMContentLoaded', function() {
        const deliveryOptions = document.querySelectorAll('.delivery-option');
        const deliveryFeeRow = document.getElementById('delivery-fee-row');
        const deliveryFeeAmount = document.getElementById('delivery-fee-amount');
        const totalAmount = document.getElementById('total-amount');
        
        deliveryOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Update selection
                deliveryOptions.forEach(opt => opt.classList.remove('selected'));
                this.classList.add('selected');
                
                // Update radio button
                const radio = this.querySelector('input[type="radio"]');
                radio.checked = true;
                
                // Update fees
                const orderType = this.dataset.type;
                updateDeliveryFees(orderType);
            });
        });
        
        function updateDeliveryFees(orderType) {
            const subtotal = <?php echo $cart_subtotal; ?>;
            const taxAmount = <?php echo $tax_amount; ?>;
            const freeDelivery = <?php echo $free_delivery ? 'true' : 'false'; ?>;
            
            let deliveryFee = 0;
            let deliveryText = 'FREE';
            
            if (orderType === 'delivery' && !freeDelivery) {
                deliveryFee = <?php echo DELIVERY_FEE; ?>;
                deliveryText = formatPrice(deliveryFee);
            }
            
            // Update display
            if (orderType === 'pickup') {
                deliveryFeeRow.style.display = 'none';
            } else {
                deliveryFeeRow.style.display = 'flex';
                deliveryFeeAmount.textContent = deliveryText;
            }
            
            // Update total
            const newTotal = subtotal + deliveryFee + taxAmount;
            totalAmount.textContent = formatPrice(newTotal);
        }
    });

    // Proceed to checkout
    function proceedToCheckout() {
        const orderType = document.querySelector('input[name="order_type"]:checked').value;
        
        // Show loading state
        const checkoutBtn = document.querySelector('.btn-checkout');
        checkoutBtn.classList.add('btn-loading');
        checkoutBtn.disabled = true;
        checkoutBtn.textContent = 'Processing...';
        
        // Redirect to checkout with order type
        window.location.href = `checkout.php?type=${orderType}`;
    }

    // Helper functions
    function formatPrice(price) {
        return '<?php echo CURRENCY_SYMBOL; ?>' + price.toFixed(2);
    }

    function showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            max-width: 300px;
        `;
        
        switch(type) {
            case 'success':
                notification.style.background = '#00b894';
                break;
            case 'error':
                notification.style.background = '#d63031';
                break;
            case 'warning':
                notification.style.background = '#fdcb6e';
                notification.style.color = '#2d3436';
                break;
            default:
                notification.style.background = '#74b9ff';
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // Remove after 4 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 4000);
    }

    // Auto-hide flash messages
    document.addEventListener('DOMContentLoaded', function() {
        const flashMessages = document.querySelectorAll('.flash-message');
        flashMessages.forEach(message => {
            setTimeout(() => {
                message.style.opacity = '0';
                setTimeout(() => message.remove(), 300);
            }, 5000);
        });
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Press 'C' to continue shopping
        if (e.key === 'c' || e.key === 'C') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                const continueLink = document.querySelector('.continue-shopping a');
                if (continueLink) {
                    window.location.href = continueLink.href;
                }
            }
        }
        
        // Press Enter to checkout (if enabled)
        if (e.key === 'Enter') {
            const checkoutBtn = document.querySelector('.btn-checkout');
            if (checkoutBtn && !checkoutBtn.disabled) {
                proceedToCheckout();
            }
        }
    });

    // Prevent form submission on quantity input
    document.addEventListener('DOMContentLoaded', function() {
        const qtyInputs = document.querySelectorAll('.qty-input');
        qtyInputs.forEach(input => {
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                }
            });
            
            // Handle direct input changes
            input.addEventListener('change', function() {
                const cartKey = this.closest('.cart-item').dataset.cartKey;
                const newQty = Math.max(1, Math.min(20, parseInt(this.value) || 1));
                const currentQty = parseInt(this.dataset.currentQty || this.value);
                
                if (newQty !== currentQty) {
                    this.dataset.currentQty = newQty;
                    this.value = newQty;
                    
                    // Update cart
                    updateQuantity(cartKey, newQty - currentQty);
                }
            });
        });
    });
    </script>

    <style>
    /* Notification animations */
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    /* Additional responsive improvements */
    @media (max-width: 480px) {
        .cart-item {
            padding: 20px 15px;
        }
        
        .item-content {
            gap: 10px;
        }
        
        .item-image {
            width: 60px;
            height: 60px;
            font-size: 1.5rem;
        }
        
        .item-name {
            font-size: 1.1rem;
        }
        
        .quantity-control {
            flex-direction: row;
            width: 100%;
        }
        
        .qty-input {
            flex: 1;
        }
        
        .remove-btn {
            width: 100%;
            margin-top: 10px;
        }
        
        .order-summary {
            padding: 20px 15px;
        }
        
        .btn-checkout {
            padding: 15px;
            font-size: 1rem;
        }
    }
    
    /* Touch device improvements */
    @media (hover: none) and (pointer: coarse) {
        .qty-btn {
            min-height: 44px;
            min-width: 44px;
        }
        
        .remove-btn {
            min-height: 44px;
            padding: 12px 15px;
        }
        
        .delivery-option {
            min-height: 60px;
            padding: 15px 12px;
        }
    }
    
    /* Print styles */
    @media print {
        .cart-header,
        .order-summary,
        .btn-checkout,
        .continue-shopping {
            display: none;
        }
        
        .cart-container {
            grid-template-columns: 1fr;
            margin-top: 0;
        }
        
        .cart-item {
            border-bottom: 1px solid #ccc;
            page-break-inside: avoid;
        }
    }
    
    /* High contrast mode support */
    @media (prefers-contrast: high) {
        .cart-item:hover {
            background: #f0f0f0;
        }
        
        .btn-checkout {
            border: 2px solid;
        }
        
        .delivery-option.selected {
            border-width: 3px;
        }
    }
    
    /* Reduced motion support */
    @media (prefers-reduced-motion: reduce) {
        .cart-item,
        .qty-btn,
        .remove-btn,
        .btn-checkout,
        .delivery-option {
            transition: none;
        }
        
        .notification {
            animation: none;
        }
        
        @keyframes slideIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
    }
    </style>
</body>
</html>