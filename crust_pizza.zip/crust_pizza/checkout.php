<?php
// public/checkout.php
require_once 'includes/init.php';

// Check if location is selected
$selected_location = getSelectedLocation();
if (!$selected_location) {
    setFlashMessage('Please select a location first.', 'warning');
    redirect('index.php');
}

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    setFlashMessage('Please login to checkout.', 'info');
    redirect('login.php');
}

// Check if store is open
if (!isStoreOpen()) {
    setFlashMessage('Sorry, we are currently closed. Orders can only be placed during business hours.', 'warning');
    redirect('cart.php');
}

// Initialize cart and validate
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    setFlashMessage('Your cart is empty. Please add items before checkout.', 'warning');
    redirect('menu.php');
}

// Get order type from URL or default to delivery
$order_type = $_GET['type'] ?? 'delivery';
if (!in_array($order_type, ['delivery', 'pickup'])) {
    $order_type = 'delivery';
}

// Calculate cart totals
$cart = $_SESSION['cart'];
$cart_count = 0;
$cart_subtotal = 0;

foreach ($cart as $item) {
    $cart_count += $item['quantity'];
    $cart_subtotal += $item['price'] * $item['quantity'];
}

// Check minimum order for delivery
if ($order_type === 'delivery' && $cart_subtotal < MIN_ORDER_AMOUNT) {
    setFlashMessage('Minimum order for delivery is ' . formatPrice(MIN_ORDER_AMOUNT) . '. Please add more items or choose pickup.', 'warning');
    redirect('cart.php');
}

// Calculate fees
$tax_amount = $cart_subtotal * TAX_RATE;
$delivery_fee = 0;
if ($order_type === 'delivery' && $cart_subtotal < FREE_DELIVERY_AMOUNT) {
    $delivery_fee = DELIVERY_FEE;
}
$total_amount = $cart_subtotal + $delivery_fee + $tax_amount;

// Get customer details
$customer_id = getCurrentUserId();
$stmt = $conn->prepare("SELECT * FROM customers WHERE customer_id = ?");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

// Get location details
$stmt = $conn->prepare("SELECT * FROM locations WHERE location_id = ?");
$stmt->bind_param("i", $selected_location);
$stmt->execute();
$location = $stmt->get_result()->fetch_assoc();

// Handle form submission
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please refresh and try again.';
    } else {
        // Get form data
        $delivery_address = '';
        $delivery_city = '';
        $delivery_state = '';
        $delivery_postal_code = '';
        $pickup_time = null;
        
        if ($order_type === 'delivery') {
            $delivery_address = sanitizeInput($_POST['delivery_address'] ?? '');
            $delivery_city = sanitizeInput($_POST['delivery_city'] ?? '');
            $delivery_state = $_POST['delivery_state'] ?? '';
            $delivery_postal_code = sanitizeInput($_POST['delivery_postal_code'] ?? '');
            
            // Validate delivery address
            if (empty($delivery_address)) $errors[] = 'Delivery address is required.';
            if (empty($delivery_city)) $errors[] = 'City is required.';
            if (empty($delivery_state)) $errors[] = 'State is required.';
            if (empty($delivery_postal_code)) $errors[] = 'Postal code is required.';
            
            // Validate postal code format
            if (!empty($delivery_postal_code) && !preg_match('/^[0-9]{4}$/', $delivery_postal_code)) {
                $errors[] = 'Please enter a valid 4-digit postal code.';
            }
        } else {
            // For pickup, validate pickup time
            $pickup_time_input = $_POST['pickup_time'] ?? '';
            if (!empty($pickup_time_input)) {
                $pickup_time = date('Y-m-d H:i:s', strtotime($pickup_time_input));
                
                // Validate pickup time is in the future and within business hours
                $pickup_timestamp = strtotime($pickup_time);
                $min_pickup_time = time() + (ESTIMATED_PREP_TIME * 60); // Minimum prep time
                
                if ($pickup_timestamp < $min_pickup_time) {
                    $errors[] = 'Pickup time must be at least ' . ESTIMATED_PREP_TIME . ' minutes from now.';
                }
            }
        }
        
        $payment_method = $_POST['payment_method'] ?? '';
        $special_instructions = sanitizeInput($_POST['special_instructions'] ?? '');
        
        // Validate payment method
        if (empty($payment_method) || !in_array($payment_method, ['credit_card', 'debit_card', 'internet_banking', 'cash_on_delivery'])) {
            $errors[] = 'Please select a valid payment method.';
        }
        
        // Cash on delivery only for delivery orders
        if ($payment_method === 'cash_on_delivery' && $order_type !== 'delivery') {
            $errors[] = 'Cash on delivery is only available for delivery orders.';
        }
        
        // Validate special instructions length
        if (strlen($special_instructions) > 500) {
            $errors[] = 'Special instructions must be less than 500 characters.';
        }
        
        // If no errors, process the order
        if (empty($errors)) {
            try {
                $conn->begin_transaction();
                
                // Generate unique order number
                $order_number = 'CP' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
                
                // Check if order number exists (very unlikely but safe)
                $check_stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_number = ?");
                $check_stmt->bind_param("s", $order_number);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    $order_number = 'CP' . date('Ymd') . str_pad(rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                }
                
                // Calculate estimated time
                $estimated_time = date('Y-m-d H:i:s', time() + (ESTIMATED_PREP_TIME * 60) + ($order_type === 'delivery' ? ESTIMATED_DELIVERY_TIME * 60 : 0));
                
                // Prepare variables for binding (FIX: Can't pass constants by reference)
                $order_status_pending = ORDER_STATUS_PENDING;
                $payment_status_pending = PAYMENT_PENDING;
                
                // Insert order
                $order_stmt = $conn->prepare("
                    INSERT INTO orders (
                        order_number, customer_id, location_id, order_type,
                        delivery_address, delivery_city, delivery_state, delivery_postal_code,
                        pickup_time, order_status_id, subtotal, tax_amount, delivery_fee,
                        total_amount, payment_method, payment_status, estimated_time,
                        special_instructions, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                
                $order_stmt->bind_param(
                    "siisssssiddddsssss",
                    $order_number,
                    $customer_id,
                    $selected_location,
                    $order_type,
                    $delivery_address,
                    $delivery_city,
                    $delivery_state,
                    $delivery_postal_code,
                    $pickup_time,
                    $order_status_pending,
                    $cart_subtotal,
                    $tax_amount,
                    $delivery_fee,
                    $total_amount,
                    $payment_method,
                    $payment_status_pending,
                    $estimated_time,
                    $special_instructions
                );
                
                if (!$order_stmt->execute()) {
                    throw new Exception('Failed to create order: ' . $order_stmt->error);
                }
                
                $order_id = $conn->insert_id;
                
                // Insert order items - FIX: Correct parameter count
                foreach ($cart as $cart_key => $item) {
                    // Prepare variables for order items
                    $product_id = $item['type'] === 'preset' ? $item['product_id'] : null;
                    $total_price = $item['price'] * $item['quantity'];
                    $empty_instructions = '';  // For item-level special instructions
                    
                    $item_stmt = $conn->prepare("
                        INSERT INTO order_items (
                            order_id, product_id, item_name, item_type, quantity,
                            unit_price, total_price, special_instructions
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    // FIX: Correct binding - 8 parameters: i,i,s,s,i,d,d,s
                    $item_stmt->bind_param(
                        "iissidds",
                        $order_id,                    // i - integer
                        $product_id,                  // i - integer (can be null)
                        $item['product_name'],        // s - string
                        $item['type'],                // s - string
                        $item['quantity'],            // i - integer
                        $item['price'],               // d - double/decimal
                        $total_price,                 // d - double/decimal
                        $empty_instructions           // s - string
                    );
                    
                    if (!$item_stmt->execute()) {
                        throw new Exception('Failed to add order item: ' . $item_stmt->error);
                    }
                    
                    $order_item_id = $conn->insert_id;
                    
                    // Handle custom pizza details
                    if ($item['type'] === 'custom') {
                        $custom_stmt = $conn->prepare("
                            INSERT INTO custom_pizzas (
                                order_item_id, size_id, crust_type_id, sauce_id,
                                cheese_id, cheese_amount
                            ) VALUES (?, ?, ?, ?, ?, ?)
                        ");
                        
                        $custom_stmt->bind_param(
                            "iiiiss",
                            $order_item_id,
                            $item['size_id'],
                            $item['crust_type_id'],
                            $item['sauce_id'],
                            $item['cheese_id'],
                            $item['cheese_amount']
                        );
                        
                        if (!$custom_stmt->execute()) {
                            throw new Exception('Failed to add custom pizza details: ' . $custom_stmt->error);
                        }
                        
                        $custom_pizza_id = $conn->insert_id;
                        
                        // Add custom pizza toppings
                        if (!empty($item['toppings'])) {
                            foreach ($item['toppings'] as $topping_id) {
                                $topping_stmt = $conn->prepare("
                                    INSERT INTO custom_pizza_toppings (custom_pizza_id, ingredient_id, quantity)
                                    VALUES (?, ?, ?)
                                ");
                                $default_quantity = 1;  // FIX: Using variable instead of literal
                                $topping_stmt->bind_param("iii", $custom_pizza_id, $topping_id, $default_quantity);
                                
                                if (!$topping_stmt->execute()) {
                                    throw new Exception('Failed to add topping: ' . $topping_stmt->error);
                                }
                            }
                        }
                    }
                }
                
                // Insert initial order status history
                $history_stmt = $conn->prepare("
                    INSERT INTO order_status_history (order_id, status_id, changed_by_type, changed_by_id, notes)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $changed_by_type = 'customer';  // FIX: Using variable instead of literal
                $notes = 'Order placed';        // FIX: Using variable instead of literal
                $history_stmt->bind_param("iisis", $order_id, $order_status_pending, $changed_by_type, $customer_id, $notes);
                
                if (!$history_stmt->execute()) {
                    throw new Exception('Failed to add order history: ' . $history_stmt->error);
                }
                
                // Simulate payment processing
                if ($payment_method !== 'cash_on_delivery') {
                    // In a real system, this would integrate with a payment gateway
                    $transaction_ref = 'TXN' . date('YmdHis') . rand(1000, 9999);
                    $payment_status_success = 'success';  // FIX: Using variable instead of literal
                    $gateway_response = 'Simulated payment - Order processed successfully';  // FIX: Using variable
                    
                    $payment_stmt = $conn->prepare("
                        INSERT INTO payment_transactions (
                            order_id, transaction_reference, amount, payment_method,
                            status, gateway_response
                        ) VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    
                    $payment_stmt->bind_param("ssdsss", $order_id, $transaction_ref, $total_amount, $payment_method, $payment_status_success, $gateway_response);
                    
                    if (!$payment_stmt->execute()) {
                        throw new Exception('Failed to record payment: ' . $payment_stmt->error);
                    }
                    
                    // Update order payment status
                    $payment_completed = 'completed';  // FIX: Using variable instead of literal
                    $update_payment_stmt = $conn->prepare("UPDATE orders SET payment_status = ? WHERE order_id = ?");
                    $update_payment_stmt->bind_param("si", $payment_completed, $order_id);
                    
                    if (!$update_payment_stmt->execute()) {
                        throw new Exception('Failed to update payment status: ' . $update_payment_stmt->error);
                    }
                }
                
                // Commit transaction
                $conn->commit();
                
                // Clear cart
                $_SESSION['cart'] = [];
                
                // Set success message
                setFlashMessage('Order placed successfully! Your order number is ' . $order_number, 'success');
                
                // Redirect to order confirmation
                redirect('order-confirmation.php?order=' . $order_number);
                
            } catch (Exception $e) {
                $conn->rollback();
                logError('Checkout error: ' . $e->getMessage());
                $errors[] = 'Failed to process order: ' . $e->getMessage();
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Include header
$current_page = 'checkout.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/checkout.css">
    
</head>
<body>
    <!-- Checkout Header -->
    <section class="checkout-header">
        <h1>🛒 Checkout</h1>
        <p>Complete your order for delicious pizza delivery</p>
    </section>

    <div class="checkout-container">
        <!-- Checkout Form -->
        <div class="checkout-main">
            <?php if (!empty($errors)): ?>
            <div class="error-message">
                <strong>Please fix the following errors:</strong>
                <ul class="error-list">
                    <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" action="" id="checkoutForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <!-- Order Type Selection -->
                <div class="section-header">
                    📦 Order Type
                </div>
                <div class="form-section">
                    <div class="order-type-toggle">
                        <button type="button" class="toggle-option <?php echo $order_type === 'delivery' ? 'active' : ''; ?>" 
                                data-type="delivery">
                            🚚 Delivery
                        </button>
                        <button type="button" class="toggle-option <?php echo $order_type === 'pickup' ? 'active' : ''; ?>" 
                                data-type="pickup">
                            🏪 Pickup
                        </button>
                    </div>
                    
                    <!-- Delivery Section -->
                    <div class="delivery-section <?php echo $order_type === 'delivery' ? 'active' : ''; ?>">
                        <h4 style="margin-bottom: 15px; color: var(--primary-color);">📍 Delivery Address</h4>
                        
                        <div class="form-group">
                            <label for="delivery_address" class="form-label required">Street Address</label>
                            <input type="text" 
                                   id="delivery_address" 
                                   name="delivery_address" 
                                   class="form-input" 
                                   placeholder="123 Main Street"
                                   value="<?php echo isset($_POST['delivery_address']) ? htmlspecialchars($_POST['delivery_address']) : htmlspecialchars($customer['address']); ?>">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="delivery_city" class="form-label required">City</label>
                                <input type="text" 
                                       id="delivery_city" 
                                       name="delivery_city" 
                                       class="form-input" 
                                       placeholder="Melbourne"
                                       value="<?php echo isset($_POST['delivery_city']) ? htmlspecialchars($_POST['delivery_city']) : htmlspecialchars($customer['city']); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="delivery_state" class="form-label required">State</label>
                                <select id="delivery_state" name="delivery_state" class="form-select">
                                    <option value="">Select State</option>
                                    <?php foreach (AU_STATES as $code => $name): ?>
                                        <option value="<?php echo $code; ?>" 
                                                <?php echo (isset($_POST['delivery_state']) ? $_POST['delivery_state'] : $customer['state']) === $code ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="delivery_postal_code" class="form-label required">Postal Code</label>
                            <input type="text" 
                                   id="delivery_postal_code" 
                                   name="delivery_postal_code" 
                                   class="form-input" 
                                   placeholder="3000"
                                   pattern="[0-9]{4}"
                                   maxlength="4"
                                   value="<?php echo isset($_POST['delivery_postal_code']) ? htmlspecialchars($_POST['delivery_postal_code']) : htmlspecialchars($customer['postal_code']); ?>">
                        </div>
                        
                        <div style="background: var(--gray-light); padding: 12px; border-radius: 6px; margin-top: 15px;">
                            <strong>🏪 Delivering from:</strong><br>
                            <?php echo htmlspecialchars($location['store_name']); ?><br>
                            <?php echo htmlspecialchars($location['address'] . ', ' . $location['city']); ?><br>
                            📞 <?php echo htmlspecialchars($location['phone']); ?>
                        </div>
                    </div>
                    
                    <!-- Pickup Section -->
                    <div class="pickup-section <?php echo $order_type === 'pickup' ? 'active' : ''; ?>">
                        <h4 style="margin-bottom: 15px; color: var(--primary-color);">⏰ Pickup Time</h4>
                        
                        <div class="form-group">
                            <label for="pickup_time" class="form-label">Preferred Pickup Time (Optional)</label>
                            <input type="datetime-local" 
                                   id="pickup_time" 
                                   name="pickup_time" 
                                   class="form-input"
                                   min="<?php echo date('Y-m-d\TH:i', time() + (ESTIMATED_PREP_TIME * 60)); ?>">
                            <small style="color: var(--gray-dark); font-size: 0.85rem; margin-top: 5px; display: block;">
                                Leave empty for ASAP (approximately <?php echo ESTIMATED_PREP_TIME; ?> minutes)
                            </small>
                        </div>
                        
                        <div style="background: var(--gray-light); padding: 12px; border-radius: 6px; margin-top: 15px;">
                            <strong>🏪 Pickup from:</strong><br>
                            <?php echo htmlspecialchars($location['store_name']); ?><br>
                            <?php echo htmlspecialchars($location['address'] . ', ' . $location['city']); ?><br>
                            📞 <?php echo htmlspecialchars($location['phone']); ?><br>
                            <strong>Hours:</strong> <?php echo OPENING_HOUR; ?>:00 AM - <?php echo CLOSING_HOUR - 12; ?>:00 PM Daily
                        </div>
                    </div>
                </div>

                <!-- Customer Information -->
                <div class="section-header">
                    👤 Customer Information
                </div>
                <div class="form-section">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-input" 
                                   value="<?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?>" 
                                   readonly>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-input" 
                                   value="<?php echo htmlspecialchars($customer['email']); ?>" 
                                   readonly>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" class="form-input" 
                               value="<?php echo htmlspecialchars($customer['phone']); ?>" 
                               readonly>
                    </div>
                    
                    <div class="form-group">
                        <label for="special_instructions" class="form-label">Special Instructions (Optional)</label>
                        <textarea id="special_instructions" 
                                  name="special_instructions" 
                                  class="form-textarea" 
                                  rows="3" 
                                  maxlength="500"
                                  placeholder="Any special requests, allergies, or delivery instructions..."><?php echo isset($_POST['special_instructions']) ? htmlspecialchars($_POST['special_instructions']) : ''; ?></textarea>
                        <small style="color: var(--gray-dark); font-size: 0.85rem;">Maximum 500 characters</small>
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="section-header">
                    💳 Payment Method
                </div>
                <div class="form-section">
                    <div class="payment-methods">
                        <div class="payment-method" data-method="credit_card">
                            <input type="radio" name="payment_method" value="credit_card" id="credit_card">
                            <div class="payment-info">
                                <div class="payment-name">💳 Credit Card</div>
                                <div class="payment-desc">Visa, Mastercard, Amex</div>
                            </div>
                        </div>
                        
                        <div class="payment-method" data-method="debit_card">
                            <input type="radio" name="payment_method" value="debit_card" id="debit_card">
                            <div class="payment-info">
                                <div class="payment-name">💳 Debit Card</div>
                                <div class="payment-desc">Direct from your account</div>
                            </div>
                        </div>
                        
                        <div class="payment-method" data-method="internet_banking">
                            <input type="radio" name="payment_method" value="internet_banking" id="internet_banking">
                            <div class="payment-info">
                                <div class="payment-name">🏦 Internet Banking</div>
                                <div class="payment-desc">Direct bank transfer</div>
                            </div>
                        </div>
                        
                        <div class="payment-method delivery-only" data-method="cash_on_delivery" 
                             style="<?php echo $order_type !== 'delivery' ? 'display: none;' : ''; ?>">
                            <input type="radio" name="payment_method" value="cash_on_delivery" id="cash_on_delivery">
                            <div class="payment-info">
                                <div class="payment-name">💵 Cash on Delivery</div>
                                <div class="payment-desc">Pay when delivered</div>
                            </div>
                        </div>
                    </div>
                    
                    <div style="background: var(--gray-light); padding: 15px; border-radius: 8px; margin-top: 15px; text-align: center; font-size: 0.85rem; color: var(--gray-dark);">
                        🔒 Your payment information is secure and encrypted.<br>
                        We never store your payment details.
                    </div>
                </div>
            </form>
        </div>

        <!-- Order Summary -->
        <div class="order-summary">
            <div class="summary-header">
                <h3>Order Summary</h3>
                <p style="color: var(--gray-dark); font-size: 0.9rem;">
                    <?php echo ucfirst($order_type); ?> • <?php echo $cart_count; ?> item<?php echo $cart_count !== 1 ? 's' : ''; ?>
                </p>
            </div>

            <div class="order-items">
                <?php foreach ($cart as $item): ?>
                <div class="order-item">
                    <div class="item-info">
                        <div class="item-name">
                            <?php echo htmlspecialchars($item['product_name']); ?>
                            <?php if ($item['quantity'] > 1): ?>
                                <span style="color: var(--gray-dark);">× <?php echo $item['quantity']; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item-details">
                            <?php if (isset($item['size_name'])): ?>
                                Size: <?php echo htmlspecialchars($item['size_name']); ?>
                            <?php endif; ?>
                            <?php if ($item['type'] === 'custom' && isset($item['description'])): ?>
                                <br><?php echo htmlspecialchars($item['description']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="item-price">
                        <?php echo formatPrice($item['price'] * $item['quantity']); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="summary-totals">
                <div class="total-row">
                    <span>Subtotal:</span>
                    <span><?php echo formatPrice($cart_subtotal); ?></span>
                </div>
                
                <?php if ($order_type === 'delivery'): ?>
                <div class="total-row">
                    <span>Delivery Fee:</span>
                    <span id="delivery-fee-display">
                        <?php echo $delivery_fee > 0 ? formatPrice($delivery_fee) : 'FREE'; ?>
                    </span>
                </div>
                <?php endif; ?>
                
                <div class="total-row">
                    <span>Tax (GST):</span>
                    <span><?php echo formatPrice($tax_amount); ?></span>
                </div>
                
                <div class="total-row final">
                    <span>Total:</span>
                    <span id="total-display"><?php echo formatPrice($total_amount); ?></span>
                </div>
            </div>

            <button type="submit" form="checkoutForm" class="place-order-btn" id="placeOrderBtn">
                Place Order - <?php echo formatPrice($total_amount); ?>
            </button>
            
            <div style="text-align: center; margin-top: 15px;">
                <a href="cart.php" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">
                    ← Back to Cart
                </a>
            </div>
        </div>
    </div>

    <?php include 'templates/footer.php'; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Order type toggle
        const toggleButtons = document.querySelectorAll('.toggle-option');
        const deliverySection = document.querySelector('.delivery-section');
        const pickupSection = document.querySelector('.pickup-section');
        const deliveryOnlyMethods = document.querySelectorAll('.delivery-only');
        
        toggleButtons.forEach(button => {
            button.addEventListener('click', function() {
                const orderType = this.dataset.type;
                
                // Update active button
                toggleButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                // Show/hide sections
                if (orderType === 'delivery') {
                    deliverySection.classList.add('active');
                    pickupSection.classList.remove('active');
                    deliveryOnlyMethods.forEach(method => method.style.display = 'flex');
                } else {
                    deliverySection.classList.remove('active');
                    pickupSection.classList.add('active');
                    deliveryOnlyMethods.forEach(method => {
                        method.style.display = 'none';
                        method.querySelector('input').checked = false;
                    });
                }
                
                // Update URL
                const url = new URL(window.location);
                url.searchParams.set('type', orderType);
                window.history.replaceState({}, '', url);
            });
        });
        
        // Payment method selection
        const paymentMethods = document.querySelectorAll('.payment-method');
        paymentMethods.forEach(method => {
            method.addEventListener('click', function() {
                // Remove selected class from all
                paymentMethods.forEach(m => m.classList.remove('selected'));
                
                // Add selected class and check radio
                this.classList.add('selected');
                this.querySelector('input[type="radio"]').checked = true;
            });
        });
        
        // Form submission
        const checkoutForm = document.getElementById('checkoutForm');
        const placeOrderBtn = document.getElementById('placeOrderBtn');
        
        checkoutForm.addEventListener('submit', function(e) {
            // Show loading state
            placeOrderBtn.style.position = 'relative';
            placeOrderBtn.style.color = 'transparent';
            placeOrderBtn.innerHTML = '<span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 20px; height: 20px; border: 2px solid transparent; border-top-color: white; border-radius: 50%; animation: spin 1s linear infinite;"></span>';
            placeOrderBtn.disabled = true;
            
            // Validate form
            const isValid = validateForm();
            if (!isValid) {
                e.preventDefault();
                resetButton();
            }
        });
        
        // Validation functions
        function validateForm() {
            let isValid = true;
            const activeOrderType = document.querySelector('.toggle-option.active').dataset.type;
            
            // Validate based on order type
            if (activeOrderType === 'delivery') {
                const deliveryFields = ['delivery_address', 'delivery_city', 'delivery_state', 'delivery_postal_code'];
                deliveryFields.forEach(fieldName => {
                    const field = document.querySelector(`[name="${fieldName}"]`);
                    if (!validateField(field)) {
                        isValid = false;
                    }
                });
            }
            
            // Validate payment method
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            if (!paymentMethod) {
                isValid = false;
                alert('Please select a payment method');
            }
            
            return isValid;
        }
        
        function validateField(field) {
            if (!field) return true;
            
            const value = field.value.trim();
            let isValid = true;
            
            // Required field validation
            if (field.hasAttribute('required') && !value) {
                isValid = false;
            }
            
            // Specific field validation
            if (field.name === 'delivery_postal_code' && value && !/^\d{4}$/.test(value)) {
                isValid = false;
            }
            
            // Update field appearance
            if (isValid) {
                field.style.borderColor = 'var(--success-color)';
                field.style.backgroundColor = '#f0fff4';
            } else {
                field.style.borderColor = 'var(--error-color)';
                field.style.backgroundColor = '#fff5f5';
            }
            
            return isValid;
        }
        
        function resetButton() {
            const placeOrderBtn = document.getElementById('placeOrderBtn');
            placeOrderBtn.disabled = false;
            placeOrderBtn.style.color = '';
            placeOrderBtn.innerHTML = 'Place Order - <?php echo formatPrice($total_amount); ?>';
        }
        
        // Postal code formatting
        const postalCode = document.getElementById('delivery_postal_code');
        if (postalCode) {
            postalCode.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '').substring(0, 4);
            });
        }
    });
    </script>
</body>
</html>