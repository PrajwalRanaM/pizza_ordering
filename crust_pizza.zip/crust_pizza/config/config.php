<?php
// config/config.php - Site configuration
// NOTE: Session settings have been moved to includes/init.php

// Environment settings
define('ENVIRONMENT', 'development'); // Change to 'production' when deploying

// Site information
define('SITE_NAME', 'Crust Pizza');
define('SITE_TAGLINE', 'Gourmet Pizza Delivered Fresh');
define('SITE_URL', 'http://localhost/crust_pizza/');
define('ADMIN_EMAIL', 'admin@crustpizza.com.au');
define('SUPPORT_EMAIL', 'support@crustpizza.com.au');

// Directory paths
define('ROOT_PATH', dirname(dirname(__FILE__)) . '/');
define('CONFIG_PATH', ROOT_PATH . 'config/');
define('INCLUDES_PATH', ROOT_PATH . 'includes/');
define('CLASSES_PATH', ROOT_PATH . 'classes/');
define('ASSETS_PATH', SITE_URL . 'assets/');
define('UPLOADS_PATH', ROOT_PATH . 'uploads/');
define('UPLOADS_URL', SITE_URL . 'uploads/');

// Database configuration (can override database.php settings)
define('DB_HOST', 'localhost');
define('DB_NAME', 'crust_pizza_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Session configuration
define('SESSION_LIFETIME', 1800); // 30 minutes
define('SESSION_NAME', 'CRUST_PIZZA_SESSION');

// Security settings
define('CSRF_TOKEN_NAME', 'csrf_token');
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// Timezone
date_default_timezone_set('Australia/Melbourne');

// Error reporting based on environment
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
}
if (ENVIRONMENT === 'production') {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', ROOT_PATH . 'logs/error.log');
}

// Upload settings
ini_set('upload_max_filesize', '5M');
ini_set('post_max_size', '10M');

// Pizza ordering settings
define('MIN_ORDER_AMOUNT', 20.00); // Minimum order for delivery
define('DELIVERY_FEE', 5.00);
define('TAX_RATE', 0.10); // 10% GST
define('FREE_DELIVERY_AMOUNT', 50.00);
define('MAX_DELIVERY_DISTANCE', 10); // km
define('ESTIMATED_PREP_TIME', 30); // minutes
define('ESTIMATED_DELIVERY_TIME', 20); // additional minutes

// Business hours (24-hour format)
define('OPENING_HOUR', 1); // 1 AM
define('CLOSING_HOUR', 23); // 11 PM

// Order status IDs (must match database)
define('ORDER_STATUS_PENDING', 1);
define('ORDER_STATUS_PREPARING', 2);
define('ORDER_STATUS_READY', 3);
define('ORDER_STATUS_OUT_FOR_DELIVERY', 4);
define('ORDER_STATUS_DELIVERED', 5);
define('ORDER_STATUS_PICKED_UP', 6);
define('ORDER_STATUS_CANCELLED', 7);
define('ORDER_STATUS_FAILED', 8);

// Employee role IDs (must match database)
define('ROLE_KITCHEN_STAFF', 1);
define('ROLE_DELIVERY_STAFF', 2);
define('ROLE_COUNTER_STAFF', 3);

// Payment methods
define('PAYMENT_CREDIT_CARD', 'credit_card');
define('PAYMENT_DEBIT_CARD', 'debit_card');
define('PAYMENT_INTERNET_BANKING', 'internet_banking');
define('PAYMENT_CASH_ON_DELIVERY', 'cash_on_delivery');

// Email settings (for production, use SMTP)
define('EMAIL_FROM', 'noreply@crustpizza.com.au');
define('EMAIL_FROM_NAME', 'Crust Pizza');

// Pagination
define('ITEMS_PER_PAGE', 12);
define('ORDERS_PER_PAGE', 20);

// Image upload settings
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'webp']);
define('MAX_IMAGE_SIZE', 5 * 1024 * 1024); // 5MB

// Currency
define('CURRENCY_SYMBOL', '$');
define('CURRENCY_CODE', 'AUD');

// Google Maps API (if needed for delivery tracking)
define('GOOGLE_MAPS_API_KEY', ''); // Add your API key

// Social media links
define('FACEBOOK_URL', 'https://facebook.com/crustpizza');
define('INSTAGRAM_URL', 'https://instagram.com/crustpizza');
define('TWITTER_URL', 'https://twitter.com/crustpizza');

// SEO defaults
define('DEFAULT_META_TITLE', 'Crust Pizza - Gourmet Pizza Delivery Melbourne');
define('DEFAULT_META_DESCRIPTION', 'Order delicious gourmet pizzas online from Crust Pizza. Fresh ingredients, innovative flavors, and fast delivery across Melbourne.');
define('DEFAULT_META_KEYWORDS', 'pizza delivery, gourmet pizza, online ordering, Melbourne pizza, Crust Pizza');

// Feature flags
define('ENABLE_REVIEWS', true);
define('ENABLE_LOYALTY_PROGRAM', false);
define('ENABLE_SOCIAL_LOGIN', false);
define('ENABLE_SMS_NOTIFICATIONS', false);
define('ENABLE_PUSH_NOTIFICATIONS', false);

// Development/Debug flags
define('SHOW_SQL_ERRORS', ENVIRONMENT === 'development');
define('LOG_QUERIES', false);
define('ENABLE_CACHE', ENVIRONMENT === 'production');

// Note: constants.php is now loaded by init.php
// If you're including config.php directly, uncomment the line below:
// require_once CONFIG_PATH . 'constants.php';
?>