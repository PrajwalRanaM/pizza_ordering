<?php
// config/constants.php - Application constants

// Status messages
define('MSG_LOGIN_SUCCESS', 'Welcome back! You have successfully logged in.');
define('MSG_LOGIN_FAILED', 'Invalid email or password.');
define('MSG_LOGOUT_SUCCESS', 'You have been successfully logged out.');
define('MSG_REGISTER_SUCCESS', 'Your account has been created successfully!');
define('MSG_REGISTER_FAILED', 'Registration failed. Please try again.');
define('MSG_ACCESS_DENIED', 'You do not have permission to access this page.');
define('MSG_SESSION_EXPIRED', 'Your session has expired. Please login again.');
define('MSG_ORDER_PLACED', 'Your order has been placed successfully!');
define('MSG_ORDER_CANCELLED', 'Your order has been cancelled.');
define('MSG_PROFILE_UPDATED', 'Your profile has been updated successfully.');
define('MSG_PASSWORD_CHANGED', 'Your password has been changed successfully.');
define('MSG_ITEM_ADDED_TO_CART', 'Item added to cart successfully.');
define('MSG_CART_UPDATED', 'Cart updated successfully.');
define('MSG_CART_EMPTY', 'Your cart is empty.');
define('MSG_MINIMUM_ORDER', 'Minimum order amount for delivery is $' . MIN_ORDER_AMOUNT);

// Error messages
define('ERR_REQUIRED_FIELDS', 'Please fill in all required fields.');
define('ERR_INVALID_EMAIL', 'Please enter a valid email address.');
define('ERR_EMAIL_EXISTS', 'An account with this email already exists.');
define('ERR_USERNAME_EXISTS', 'This username is already taken.');
define('ERR_WEAK_PASSWORD', 'Password does not meet security requirements.');
define('ERR_PASSWORDS_NOT_MATCH', 'Passwords do not match.');
define('ERR_INVALID_PHONE', 'Please enter a valid phone number.');
define('ERR_INVALID_POSTCODE', 'Please enter a valid postcode.');
define('ERR_DATABASE_ERROR', 'A database error occurred. Please try again.');
define('ERR_CSRF_TOKEN', 'Invalid form submission. Please refresh and try again.');
define('ERR_FILE_UPLOAD', 'File upload failed. Please try again.');
define('ERR_INVALID_IMAGE', 'Please upload a valid image file (JPG, PNG, or WebP).');
define('ERR_IMAGE_TOO_LARGE', 'Image size must be less than 5MB.');
define('ERR_NO_LOCATION_SELECTED', 'Please select a store location.');
define('ERR_OUTSIDE_DELIVERY_AREA', 'Sorry, this address is outside our delivery area.');
define('ERR_STORE_CLOSED', 'Sorry, we are currently closed. Our hours are 11 AM - 11 PM.');

// Pizza sizes
define('SIZE_SMALL', 'Small');
define('SIZE_MEDIUM', 'Medium');
define('SIZE_LARGE', 'Large');

// Order types
define('ORDER_TYPE_DELIVERY', 'delivery');
define('ORDER_TYPE_PICKUP', 'pickup');

// User types
define('USER_TYPE_CUSTOMER', 'customer');
define('USER_TYPE_EMPLOYEE', 'employee');
define('USER_TYPE_ADMIN', 'admin');

// Regex patterns
define('REGEX_USERNAME', '/^[a-zA-Z0-9_]{3,20}$/');
define('REGEX_PHONE_AU', '/^(?:\+?61|0)4\d{8}$/');
define('REGEX_POSTCODE_AU', '/^[0-9]{4}$/');
define('REGEX_PASSWORD', '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/');

// Australian states
define('AU_STATES', [
    'NSW' => 'New South Wales',
    'VIC' => 'Victoria',
    'QLD' => 'Queensland',
    'WA' => 'Western Australia',
    'SA' => 'South Australia',
    'TAS' => 'Tasmania',
    'ACT' => 'Australian Capital Territory',
    'NT' => 'Northern Territory'
]);

// Dietary categories
define('DIETARY_VEGETARIAN', 'vegetarian');
define('DIETARY_VEGAN', 'vegan');
define('DIETARY_GLUTEN_FREE', 'gluten_free');

// Ingredient categories
define('INGREDIENT_VEG', 'vegetarian');
define('INGREDIENT_NON_VEG', 'non-vegetarian');
define('INGREDIENT_SAUCE', 'sauce');
define('INGREDIENT_CHEESE', 'cheese');
define('INGREDIENT_OTHER', 'other');

// Cheese amounts
define('CHEESE_NONE', 'none');
define('CHEESE_REGULAR', 'regular');
define('CHEESE_EXTRA', 'extra');

// Order item types
define('ITEM_TYPE_PRESET', 'preset');
define('ITEM_TYPE_CUSTOM', 'custom');

// Payment statuses
define('PAYMENT_PENDING', 'pending');
define('PAYMENT_COMPLETED', 'completed');
define('PAYMENT_FAILED', 'failed');
define('PAYMENT_REFUNDED', 'refunded');

// Delivery statuses
define('DELIVERY_ASSIGNED', 'assigned');
define('DELIVERY_DEPARTED', 'departed');
define('DELIVERY_DELIVERED', 'delivered');
define('DELIVERY_FAILED', 'failed');

// Actions for order item ingredients
define('INGREDIENT_ACTION_ADD', 'add');
define('INGREDIENT_ACTION_REMOVE', 'remove');
define('INGREDIENT_ACTION_EXTRA', 'extra');

// Email templates
define('EMAIL_ORDER_CONFIRMATION', 'order_confirmation');
define('EMAIL_ORDER_READY', 'order_ready');
define('EMAIL_ORDER_DELIVERED', 'order_delivered');
define('EMAIL_WELCOME', 'welcome');
define('EMAIL_PASSWORD_RESET', 'password_reset');

// Session keys
define('SESSION_USER_ID', 'user_id');
define('SESSION_USER_NAME', 'user_name');
define('SESSION_USER_TYPE', 'user_type');
define('SESSION_FULL_NAME', 'full_name');
define('SESSION_ROLE_ID', 'role_id');
define('SESSION_ROLE_NAME', 'role_name');
define('SESSION_LOCATION_ID', 'selected_location');
define('SESSION_CART', 'cart');
define('SESSION_CSRF', 'csrf_token');
define('SESSION_LAST_ACTIVITY', 'last_activity');
define('SESSION_LOGIN_ATTEMPTS', 'login_attempts');
define('SESSION_REDIRECT_URL', 'redirect_after_login');

// Cookie names
define('COOKIE_REMEMBER_ME', 'crust_remember');
define('COOKIE_LOCATION', 'crust_location');
define('COOKIE_CONSENT', 'crust_cookie_consent');

// Cache keys (if using caching)
define('CACHE_MENU_ITEMS', 'menu_items');
define('CACHE_LOCATIONS', 'locations');
define('CACHE_INGREDIENTS', 'ingredients');
define('CACHE_CATEGORIES', 'categories');

// API response codes
define('API_SUCCESS', 200);
define('API_CREATED', 201);
define('API_BAD_REQUEST', 400);
define('API_UNAUTHORIZED', 401);
define('API_FORBIDDEN', 403);
define('API_NOT_FOUND', 404);
define('API_SERVER_ERROR', 500);

// Notification types
define('NOTIFY_SUCCESS', 'success');
define('NOTIFY_ERROR', 'error');
define('NOTIFY_WARNING', 'warning');
define('NOTIFY_INFO', 'info');

// Log types
define('LOG_LOGIN', 'login');
define('LOG_LOGOUT', 'logout');
define('LOG_ORDER', 'order');
define('LOG_ERROR', 'error');
define('LOG_ADMIN', 'admin');

// Maximum values
define('MAX_CART_ITEMS', 50);
define('MAX_PIZZA_TOPPINGS', 10);
define('MAX_ORDER_ITEMS', 20);
define('MAX_ADDRESS_LENGTH', 255);
define('MAX_INSTRUCTIONS_LENGTH', 500);

// Default values
define('DEFAULT_LOCATION_ID', 1); // CBD location
define('DEFAULT_CURRENCY', 'AUD');
define('DEFAULT_LANGUAGE', 'en-AU');
define('DEFAULT_PAGE_SIZE', 10);
?>