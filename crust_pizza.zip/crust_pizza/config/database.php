<?php
// config/database.php - Database configuration and connection class

class Database {
    private static $instance = null;
    private $connection;
    
    // Database configuration
    private $host = 'localhost';
    private $database = 'crust_pizza_db';
    private $username = 'root';
    private $password = '';
    private $charset = 'utf8mb4';
    
    // Private constructor to prevent direct instantiation
    private function __construct() {
        try {
            $this->connection = new mysqli(
                $this->host,
                $this->username,
                $this->password,
                $this->database
            );
            
            if ($this->connection->connect_error) {
                throw new Exception($this->connection->connect_error);
            }
            
            // Set charset
            if (!$this->connection->set_charset($this->charset)) {
                throw new Exception("Error setting charset: " . $this->connection->error);
            }
            
            // Set timezone to Melbourne
            $this->connection->query("SET time_zone = '+10:00'");
            
        } catch (Exception $e) {
            $this->handleConnectionError($e);
        }
    }
    
    // Get database instance (Singleton pattern)
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    // Get connection
    public function getConnection() {
        return $this->connection;
    }
    
    // Prepare statement with error handling
    public function prepare($sql) {
        $stmt = $this->connection->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $this->connection->error);
        }
        return $stmt;
    }
    
    // Execute query with error handling
    public function query($sql) {
        $result = $this->connection->query($sql);
        if ($result === false) {
            throw new Exception("Query failed: " . $this->connection->error);
        }
        return $result;
    }
    
    // Get last insert ID
    public function getLastId() {
        return $this->connection->insert_id;
    }
    
    // Get affected rows
    public function getAffectedRows() {
        return $this->connection->affected_rows;
    }
    
    // Begin transaction
    public function beginTransaction() {
        $this->connection->autocommit(false);
        $this->connection->begin_transaction();
    }
    
    // Commit transaction
    public function commit() {
        $this->connection->commit();
        $this->connection->autocommit(true);
    }
    
    // Rollback transaction
    public function rollback() {
        $this->connection->rollback();
        $this->connection->autocommit(true);
    }
    
    // Escape string
    public function escape($string) {
        return $this->connection->real_escape_string($string);
    }
    
    // Close connection
    public function close() {
        if ($this->connection) {
            $this->connection->close();
        }
    }
    
    // Handle connection errors with user-friendly messages
    private function handleConnectionError($e) {
        $error_message = $e->getMessage();
        
        // Check if we're in development or production
        $is_development = true; // Set to false in production
        
        if ($is_development) {
            // Development: Show detailed error messages
            if (strpos($error_message, 'Connection refused') !== false || 
                strpos($error_message, "Can't connect") !== false) {
                $this->showError(
                    "MySQL Server is not running!",
                    "Please follow these steps:",
                    [
                        "Open XAMPP Control Panel",
                        "Click 'Start' next to MySQL",
                        "Wait for the status to show 'Running'",
                        "Refresh this page"
                    ],
                    $error_message
                );
            } elseif (strpos($error_message, 'Unknown database') !== false) {
                $this->showError(
                    "Database 'crust_pizza_db' not found!",
                    "Please follow these steps:",
                    [
                        "Open phpMyAdmin (http://localhost/phpmyadmin)",
                        "Click 'New' to create a database",
                        "Name it 'crust_pizza_db'",
                        "Run the SQL schema file to create tables",
                        "Run the seed data file to populate tables",
                        "Refresh this page"
                    ],
                    $error_message
                );
            } elseif (strpos($error_message, 'Access denied') !== false) {
                $this->showError(
                    "Database Access Denied!",
                    "Check your database credentials:",
                    [
                        "Username: " . $this->username,
                        "Password: " . ($this->password ? '(set)' : '(empty)'),
                        "Update credentials in config/database.php if needed"
                    ],
                    $error_message
                );
            } else {
                $this->showError(
                    "Database Connection Error",
                    "An unexpected error occurred:",
                    [],
                    $error_message
                );
            }
        } else {
            // Production: Show generic error message
            $this->showProductionError();
        }
        
        exit();
    }
    
    // Display detailed error page (development)
    private function showError($title, $subtitle, $steps = [], $technical_details = '') {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Connection Error - Crust Pizza</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f8f9fa;
                    margin: 0;
                    padding: 20px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                }
                .error-container {
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                    padding: 40px;
                    max-width: 600px;
                    width: 100%;
                }
                .error-icon {
                    font-size: 48px;
                    color: #d63031;
                    text-align: center;
                    margin-bottom: 20px;
                }
                h1 {
                    color: #d63031;
                    font-size: 28px;
                    margin: 0 0 10px 0;
                    text-align: center;
                }
                .subtitle {
                    color: #2d3436;
                    font-size: 18px;
                    margin-bottom: 20px;
                    text-align: center;
                }
                .steps {
                    background: #f8f9fa;
                    border-left: 4px solid #d63031;
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 4px;
                }
                .steps ol {
                    margin: 0;
                    padding-left: 20px;
                }
                .steps li {
                    margin-bottom: 10px;
                    color: #2d3436;
                    line-height: 1.6;
                }
                .technical-details {
                    background: #2d3436;
                    color: #dfe6e9;
                    padding: 15px;
                    border-radius: 4px;
                    font-family: 'Courier New', monospace;
                    font-size: 13px;
                    margin-top: 20px;
                    word-wrap: break-word;
                }
                .btn-retry {
                    display: block;
                    width: 100%;
                    padding: 15px;
                    background: #d63031;
                    color: white;
                    text-align: center;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: 600;
                    margin-top: 20px;
                    transition: background 0.3s ease;
                }
                .btn-retry:hover {
                    background: #c0392b;
                }
            </style>
        </head>
        <body>
            <div class="error-container">
                <div class="error-icon">❌</div>
                <h1><?php echo htmlspecialchars($title); ?></h1>
                <p class="subtitle"><?php echo htmlspecialchars($subtitle); ?></p>
                
                <?php if (!empty($steps)): ?>
                <div class="steps">
                    <ol>
                        <?php foreach ($steps as $step): ?>
                            <li><?php echo htmlspecialchars($step); ?></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
                <?php endif; ?>
                
                <?php if ($technical_details): ?>
                <div class="technical-details">
                    <strong>Technical Details:</strong><br>
                    <?php echo htmlspecialchars($technical_details); ?>
                </div>
                <?php endif; ?>
                
                <a href="javascript:location.reload()" class="btn-retry">🔄 Retry Connection</a>
            </div>
        </body>
        </html>
        <?php
    }
    
    // Display generic error page (production)
    private function showProductionError() {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Service Temporarily Unavailable - Crust Pizza</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f8f9fa;
                    margin: 0;
                    padding: 20px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                }
                .error-container {
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                    padding: 60px 40px;
                    max-width: 500px;
                    width: 100%;
                    text-align: center;
                }
                .pizza-icon {
                    font-size: 72px;
                    margin-bottom: 20px;
                }
                h1 {
                    color: #2d3436;
                    font-size: 28px;
                    margin: 0 0 15px 0;
                }
                p {
                    color: #636e72;
                    font-size: 16px;
                    line-height: 1.6;
                    margin-bottom: 30px;
                }
                .btn-home {
                    display: inline-block;
                    padding: 15px 30px;
                    background: #d63031;
                    color: white;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: 600;
                    transition: background 0.3s ease;
                }
                .btn-home:hover {
                    background: #c0392b;
                }
            </style>
        </head>
        <body>
            <div class="error-container">
                <div class="pizza-icon">🍕</div>
                <h1>Oops! Something went wrong</h1>
                <p>We're having trouble connecting to our services right now. Our team has been notified and is working on it. Please try again in a few moments.</p>
                <a href="/" class="btn-home">Go to Homepage</a>
            </div>
        </body>
        </html>
        <?php
    }
    
    // Prevent cloning
    private function __clone() {}
    
    // Prevent unserialization
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// Updated includes/db.php - Backward compatibility wrapper
// This file maintains compatibility with existing code that uses $conn

try {
    // Get database instance
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
} catch (Exception $e) {
    // Errors are already handled by the Database class
    exit();
}

// Helper function to get database instance anywhere in the application
function getDB() {
    return Database::getInstance();
}

// Helper function to get connection
function getConnection() {
    return Database::getInstance()->getConnection();
}
?>