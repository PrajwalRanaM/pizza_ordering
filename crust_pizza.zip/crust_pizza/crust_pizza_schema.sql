-- Crust Pizza Online Ordering System Database Schema
-- Database: crust_pizza_db

-- Drop database if exists and create new one
DROP DATABASE IF EXISTS crust_pizza_db;
CREATE DATABASE crust_pizza_db;
USE crust_pizza_db;

-- =====================================================
-- LOCATION/STORE TABLE
-- =====================================================
CREATE TABLE locations (
    location_id INT PRIMARY KEY AUTO_INCREMENT,
    store_name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
-- USER TABLES
-- =====================================================

-- Customers table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Will store hashed password
    email VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(50),
    postal_code VARCHAR(10),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_username (username)
);

-- Employee roles
CREATE TABLE employee_roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT
);

-- Employees table
CREATE TABLE employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Will store hashed password
    email VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role_id INT NOT NULL,
    location_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES employee_roles(role_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id),
    INDEX idx_role (role_id),
    INDEX idx_location (location_id)
);

-- Admin table (superusers)
CREATE TABLE admins (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Will store hashed password
    email VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
-- PRODUCT TABLES
-- =====================================================

-- Product categories
CREATE TABLE product_categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL,
    description TEXT,
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

-- Crust sizes
CREATE TABLE crust_sizes (
    size_id INT PRIMARY KEY AUTO_INCREMENT,
    size_name VARCHAR(20) NOT NULL,
    size_code CHAR(1) NOT NULL, -- S, M, L
    price_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    is_active BOOLEAN DEFAULT TRUE
);

-- Crust types
CREATE TABLE crust_types (
    crust_type_id INT PRIMARY KEY AUTO_INCREMENT,
    crust_name VARCHAR(50) NOT NULL,
    description TEXT,
    additional_price DECIMAL(10,2) DEFAULT 0.00,
    is_gluten_free BOOLEAN DEFAULT FALSE,
    is_vegan BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- Sauce types
CREATE TABLE sauces (
    sauce_id INT PRIMARY KEY AUTO_INCREMENT,
    sauce_name VARCHAR(50) NOT NULL,
    description TEXT,
    is_vegan BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- Cheese types
CREATE TABLE cheese_types (
    cheese_id INT PRIMARY KEY AUTO_INCREMENT,
    cheese_name VARCHAR(50) NOT NULL,
    description TEXT,
    is_vegan BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- Ingredients/Toppings
CREATE TABLE ingredients (
    ingredient_id INT PRIMARY KEY AUTO_INCREMENT,
    ingredient_name VARCHAR(100) NOT NULL,
    description TEXT,
    category ENUM('vegetarian', 'non-vegetarian', 'sauce', 'cheese', 'other') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    is_vegan BOOLEAN DEFAULT FALSE,
    is_gluten_free BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category)
);

-- Products (Pizzas and Non-Pizza items)
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL,
    description TEXT,
    category_id INT NOT NULL,
    base_price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255),
    is_customizable BOOLEAN DEFAULT FALSE,
    is_vegetarian BOOLEAN DEFAULT FALSE,
    is_vegan BOOLEAN DEFAULT FALSE,
    is_gluten_free BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES product_categories(category_id),
    INDEX idx_category (category_id),
    INDEX idx_active (is_active)
);

-- Product ingredients (for preset pizzas)
CREATE TABLE product_ingredients (
    product_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT DEFAULT 1,
    PRIMARY KEY (product_id, ingredient_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
);

-- =====================================================
-- ORDER TABLES
-- =====================================================

-- Order statuses
CREATE TABLE order_statuses (
    status_id INT PRIMARY KEY AUTO_INCREMENT,
    status_name VARCHAR(50) NOT NULL,
    description TEXT,
    display_order INT DEFAULT 0
);

-- Orders
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    location_id INT NOT NULL,
    order_type ENUM('delivery', 'pickup') NOT NULL,
    delivery_address VARCHAR(255),
    delivery_city VARCHAR(100),
    delivery_state VARCHAR(50),
    delivery_postal_code VARCHAR(10),
    pickup_time DATETIME,
    order_status_id INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('credit_card', 'debit_card', 'internet_banking', 'cash_on_delivery') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    estimated_time DATETIME,
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id),
    FOREIGN KEY (order_status_id) REFERENCES order_statuses(status_id),
    INDEX idx_customer (customer_id),
    INDEX idx_location (location_id),
    INDEX idx_status (order_status_id),
    INDEX idx_order_number (order_number),
    INDEX idx_created_at (created_at)
);

-- Order items
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT,
    item_name VARCHAR(100) NOT NULL,
    item_type ENUM('preset', 'custom') NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    special_instructions TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_order (order_id)
);

-- Custom pizza details
CREATE TABLE custom_pizzas (
    custom_pizza_id INT PRIMARY KEY AUTO_INCREMENT,
    order_item_id INT NOT NULL,
    size_id INT NOT NULL,
    crust_type_id INT NOT NULL,
    sauce_id INT,
    cheese_id INT,
    cheese_amount ENUM('none', 'regular', 'extra') DEFAULT 'regular',
    FOREIGN KEY (order_item_id) REFERENCES order_items(order_item_id) ON DELETE CASCADE,
    FOREIGN KEY (size_id) REFERENCES crust_sizes(size_id),
    FOREIGN KEY (crust_type_id) REFERENCES crust_types(crust_type_id),
    FOREIGN KEY (sauce_id) REFERENCES sauces(sauce_id),
    FOREIGN KEY (cheese_id) REFERENCES cheese_types(cheese_id)
);

-- Custom pizza toppings
CREATE TABLE custom_pizza_toppings (
    custom_pizza_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT DEFAULT 1,
    PRIMARY KEY (custom_pizza_id, ingredient_id),
    FOREIGN KEY (custom_pizza_id) REFERENCES custom_pizzas(custom_pizza_id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
);

-- Order item ingredients (for modified preset pizzas)
CREATE TABLE order_item_ingredients (
    order_item_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    action ENUM('add', 'remove', 'extra') NOT NULL,
    quantity INT DEFAULT 1,
    PRIMARY KEY (order_item_id, ingredient_id, action),
    FOREIGN KEY (order_item_id) REFERENCES order_items(order_item_id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
);

-- =====================================================
-- TRACKING AND HISTORY TABLES
-- =====================================================

-- Order status history
CREATE TABLE order_status_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    status_id INT NOT NULL,
    changed_by_type ENUM('customer', 'employee', 'admin', 'system') NOT NULL,
    changed_by_id INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (status_id) REFERENCES order_statuses(status_id),
    INDEX idx_order (order_id),
    INDEX idx_created_at (created_at)
);

-- Delivery assignments
CREATE TABLE delivery_assignments (
    assignment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    departed_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    delivery_status ENUM('assigned', 'departed', 'delivered', 'failed') DEFAULT 'assigned',
    failure_reason TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    INDEX idx_order (order_id),
    INDEX idx_employee (employee_id)
);

-- =====================================================
-- CART TABLE (for temporary storage)
-- =====================================================

CREATE TABLE cart_items (
    cart_item_id INT PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(100) NOT NULL,
    customer_id INT,
    product_id INT,
    item_type ENUM('preset', 'custom') NOT NULL,
    item_details JSON, -- Store custom pizza details in JSON format
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_session (session_id),
    INDEX idx_customer (customer_id),
    INDEX idx_created_at (created_at)
);

-- =====================================================
-- PAYMENT TRANSACTIONS TABLE
-- =====================================================

CREATE TABLE payment_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    transaction_reference VARCHAR(100) UNIQUE,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('credit_card', 'debit_card', 'internet_banking', 'cash_on_delivery') NOT NULL,
    status ENUM('pending', 'success', 'failed', 'refunded') NOT NULL,
    gateway_response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    INDEX idx_order (order_id),
    INDEX idx_reference (transaction_reference)
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional indexes for common queries
CREATE INDEX idx_orders_date_range ON orders(created_at, order_status_id);
CREATE INDEX idx_orders_customer_date ON orders(customer_id, created_at);
CREATE INDEX idx_products_active_category ON products(is_active, category_id);

-- =====================================================
-- VIEWS FOR COMMON QUERIES
-- =====================================================

-- View for active menu items
CREATE VIEW active_menu_items AS
SELECT 
    p.product_id,
    p.product_name,
    p.description,
    p.base_price,
    p.image_url,
    pc.category_name,
    p.is_vegetarian,
    p.is_vegan,
    p.is_gluten_free
FROM products p
JOIN product_categories pc ON p.category_id = pc.category_id
WHERE p.is_active = TRUE AND pc.is_active = TRUE;

-- View for order summary
CREATE VIEW order_summary AS
SELECT 
    o.order_id,
    o.order_number,
    o.created_at,
    c.first_name,
    c.last_name,
    c.email,
    c.phone,
    l.store_name,
    os.status_name,
    o.order_type,
    o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN locations l ON o.location_id = l.location_id
JOIN order_statuses os ON o.order_status_id = os.status_id;