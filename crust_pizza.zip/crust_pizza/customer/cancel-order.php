<?php
require_once '../includes/init.php';



// Check if database connection is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$customer_id = $_SESSION['user_id'];
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    echo "<p style='color:red;'>Invalid Order ID.</p>";
    exit;
}

// Check if order belongs to customer and is not already cancelled or completed
$stmt = $conn->prepare("
    SELECT o.*, os.status_name
    FROM orders o
    JOIN order_statuses os ON o.order_status_id = os.status_id
    WHERE o.order_id = ? AND o.customer_id = ? AND o.order_status_id NOT IN (4, 7)
");
$stmt->bind_param("ii", $order_id, $customer_id);
$stmt->execute();
$order_details = $stmt->get_result()->fetch_assoc();

if (!$order_details) {
    echo "<p style='color:red;'>Order not found, already completed, or cannot be cancelled.</p>";
    exit;
}

// Set status to 'Cancelled' (status_id = 7)
$cancel_status_id = 7;
$update = $conn->prepare("UPDATE orders SET order_status_id = ? WHERE order_id = ?");
$update->bind_param("ii", $cancel_status_id, $order_id);
$update->execute();

header("Location: orders.php?order_id=" . $order_id);
exit;

?>
