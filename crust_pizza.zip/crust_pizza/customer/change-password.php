<?php
// customer/change-password.php - Change Customer Password
require_once '../includes/init.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isCustomer()) {
    $_SESSION['redirect_after_login'] = 'customer/change-password.php';
    setFlashMessage('Please login to change your password.', 'info');
    redirect('../login.php');
}

// Get customer details
$customer_id = getCurrentUserId();
$stmt = $conn->prepare("SELECT username, email, first_name, last_name FROM customers WHERE customer_id = ? AND is_active = 1");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

if (!$customer) {
    setFlashMessage('Customer profile not found.', 'error');
    redirect('../index.php');
}

// Handle form submission
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please refresh and try again.';
    } else {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Validate current password
        if (empty($current_password)) {
            $errors[] = 'Current password is required.';
        } else {
            // Verify current password
            $verify_stmt = $conn->prepare("SELECT password FROM customers WHERE customer_id = ?");
            $verify_stmt->bind_param("i", $customer_id);
            $verify_stmt->execute();
            $result = $verify_stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user_data = $result->fetch_assoc();
                if (!password_verify($current_password, $user_data['password'])) {
                    $errors[] = 'Current password is incorrect.';
                }
            } else {
                $errors[] = 'Account verification failed.';
            }
        }
        
        // Validate new password
        if (empty($new_password)) {
            $errors[] = 'New password is required.';
        } else {
            $password_errors = validatePassword($new_password);
            $errors = array_merge($errors, $password_errors);
        }
        
        // Validate password confirmation
        if (empty($confirm_password)) {
            $errors[] = 'Please confirm your new password.';
        } elseif ($new_password !== $confirm_password) {
            $errors[] = 'New password and confirmation do not match.';
        }
        
        // Check if new password is same as current
        if (!empty($current_password) && !empty($new_password) && $current_password === $new_password) {
            $errors[] = 'New password must be different from your current password.';
        }
        
        // If no errors, update the password
        if (empty($errors)) {
            try {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                $update_stmt = $conn->prepare("
                    UPDATE customers 
                    SET password = ?, updated_at = NOW() 
                    WHERE customer_id = ?
                ");
                $update_stmt->bind_param("si", $hashed_password, $customer_id);
                
                if ($update_stmt->execute()) {
                    setFlashMessage('Password changed successfully!', 'success');
                    redirect('profile.php?password_changed=1');
                } else {
                    $errors[] = 'Failed to update password. Please try again.';
                }
                
            } catch (Exception $e) {
                logError('Password change error: ' . $e->getMessage());
                $errors[] = 'An error occurred while changing your password. Please try again.';
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Include header
$current_page = 'change-password';
include '../templates/header2.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/password.css">
</head>
<body>
    <!-- Flash Messages -->
    <?php if (!empty($errors)): ?>
    <div class="flash-message flash-error" id="flashMessage">
        Please fix the errors below and try again.
    </div>
    <?php endif; ?>

    <div class="password-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>🔒 Change Password</h1>
            <p>Update your password to keep your account secure</p>
        </div>

        <!-- Breadcrumb Navigation -->
        <div class="breadcrumb">
            <a href="../index.php">Home</a>
            <span>›</span>
            <a href="profile.php">My Profile</a>
            <span>›</span>
            <span>Change Password</span>
        </div>

        <!-- Password Change Form -->
        <div class="password-form-card">
            <div class="card-header">
                🔐 Update Your Password
            </div>
            
            <div class="card-content">
                <!-- Security Notice -->
                <div class="security-notice">
                    <div class="icon">🛡️</div>
                    <div class="content">
                        <h4>Security Notice</h4>
                        <p>For your security, you'll need to enter your current password before setting a new one. Choose a strong password that you haven't used elsewhere.</p>
                    </div>
                </div>

                <!-- Error Messages -->
                <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <strong>Please fix the following errors:</strong>
                    <ul class="error-list">
                        <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Password Change Form -->
                <form method="POST" action="" id="changePasswordForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                    <!-- Current Password -->
                    <div class="form-group">
                        <label for="current_password" class="form-label required">Current Password</label>
                        <div class="password-input-group">
                            <input type="password" 
                                   id="current_password" 
                                   name="current_password" 
                                   class="form-input" 
                                   required 
                                   placeholder="Enter your current password">
                            <button type="button" class="password-toggle" data-target="current_password">
                                👁️
                            </button>
                        </div>
                        <div class="validation-feedback" id="current_password_feedback"></div>
                        <span class="form-help">Enter your current password to verify your identity</span>
                    </div>

                    <!-- New Password -->
                    <div class="form-group">
                        <label for="new_password" class="form-label required">New Password</label>
                        <div class="password-input-group">
                            <input type="password" 
                                   id="new_password" 
                                   name="new_password" 
                                   class="form-input" 
                                   required 
                                   minlength="<?php echo PASSWORD_MIN_LENGTH; ?>"
                                   placeholder="Enter your new password">
                            <button type="button" class="password-toggle" data-target="new_password">
                                👁️
                            </button>
                        </div>
                        <div class="validation-feedback" id="new_password_feedback"></div>
                        
                        <!-- Password Strength Indicator -->
                        <div class="password-strength" style="display: none;">
                            <div class="strength-bar">
                                <div class="strength-fill" id="strengthFill"></div>
                            </div>
                            <div class="strength-text">
                                <span class="strength-label">Password strength:</span>
                                <span class="strength-level" id="strengthLevel">Weak</span>
                            </div>
                        </div>

                        <!-- Password Requirements -->
                        <div class="password-requirements">
                            <h5>Password must include:</h5>
                            <ul class="requirements-list">
                                <li class="requirement" id="req-length">
                                    <span class="icon"></span>
                                    <span>At least <?php echo PASSWORD_MIN_LENGTH; ?> characters</span>
                                </li>
                                <li class="requirement" id="req-upper">
                                    <span class="icon"></span>
                                    <span>One uppercase letter</span>
                                </li>
                                <li class="requirement" id="req-lower">
                                    <span class="icon"></span>
                                    <span>One lowercase letter</span>
                                </li>
                                <li class="requirement" id="req-number">
                                    <span class="icon"></span>
                                    <span>One number</span>
                                </li>
                                <li class="requirement" id="req-special">
                                    <span class="icon"></span>
                                    <span>One special character</span>
                                </li>
                                <li class="requirement" id="req-different">
                                    <span class="icon"></span>
                                    <span>Different from current</span>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Confirm New Password -->
                    <div class="form-group">
                        <label for="confirm_password" class="form-label required">Confirm New Password</label>
                        <div class="password-input-group">
                            <input type="password" 
                                   id="confirm_password" 
                                   name="confirm_password" 
                                   class="form-input" 
                                   required 
                                   placeholder="Confirm your new password">
                            <button type="button" class="password-toggle" data-target="confirm_password">
                                👁️
                            </button>
                        </div>
                        <div class="validation-feedback" id="confirm_password_feedback"></div>
                        <span class="form-help">Re-enter your new password to confirm</span>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="profile.php" class="btn btn-secondary">
                            ❌ Cancel
                        </a>
                        <button type="submit" class="btn btn-primary" id="changeBtn" disabled>
                            🔒 Change Password
                        </button>
                    </div>
                </form>

                <!-- Password Tips -->
                <div class="password-tips">
                    <h4>💡 Password Security Tips</h4>
                    <div class="tips-grid">
                        <div class="tip">
                            <span class="icon">🔐</span>
                            <span>Use a unique password that you don't use elsewhere</span>
                        </div>
                        <div class="tip">
                            <span class="icon">🔄</span>
                            <span>Change your password regularly (every 3-6 months)</span>
                        </div>
                        <div class="tip">
                            <span class="icon">📱</span>
                            <span>Consider using a password manager</span>
                        </div>
                        <div class="tip">
                            <span class="icon">🚫</span>
                            <span>Never share your password with anyone</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../templates/footer1.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('changePasswordForm');
            const changeBtn = document.getElementById('changeBtn');
            const newPasswordField = document.getElementById('new_password');
            const confirmPasswordField = document.getElementById('confirm_password');
            const currentPasswordField = document.getElementById('current_password');
            const strengthIndicator = document.querySelector('.password-strength');
            const strengthFill = document.getElementById('strengthFill');
            const strengthLevel = document.getElementById('strengthLevel');

            // Password toggle functionality
            document.querySelectorAll('.password-toggle').forEach(toggle => {
                toggle.addEventListener('click', function() {
                    const targetId = this.dataset.target;
                    const targetField = document.getElementById(targetId);
                    
                    if (targetField.type === 'password') {
                        targetField.type = 'text';
                        this.textContent = '🙈';
                    } else {
                        targetField.type = 'password';
                        this.textContent = '👁️';
                    }
                });
            });

            // Password strength checking
            newPasswordField.addEventListener('input', function() {
                const password = this.value;
                strengthIndicator.style.display = password ? 'block' : 'none';
                
                if (password) {
                    updatePasswordStrength(password);
                    validateRequirements(password);
                }
                
                validateForm();
            });

            function updatePasswordStrength(password) {
                let score = 0;
                const checks = [
                    password.length >= <?php echo PASSWORD_MIN_LENGTH; ?>,
                    /[A-Z]/.test(password),
                    /[a-z]/.test(password),
                    /[0-9]/.test(password),
                    /[^A-Za-z0-9]/.test(password)
                ];

                score = checks.filter(Boolean).length;

                // Update strength bar and text
                strengthFill.className = 'strength-fill';
                strengthLevel.className = 'strength-level';

                if (score <= 2) {
                    strengthFill.classList.add('weak');
                    strengthLevel.classList.add('weak');
                    strengthLevel.textContent = 'Weak';
                } else if (score === 3) {
                    strengthFill.classList.add('fair');
                    strengthLevel.classList.add('fair');
                    strengthLevel.textContent = 'Fair';
                } else if (score === 4) {
                    strengthFill.classList.add('good');
                    strengthLevel.classList.add('good');
                    strengthLevel.textContent = 'Good';
                } else {
                    strengthFill.classList.add('strong');
                    strengthLevel.classList.add('strong');
                    strengthLevel.textContent = 'Strong';
                }
            }

            function validateRequirements(password) {
                const requirements = [
                    { id: 'req-length', test: password.length >= <?php echo PASSWORD_MIN_LENGTH; ?> },
                    { id: 'req-upper', test: /[A-Z]/.test(password) },
                    { id: 'req-lower', test: /[a-z]/.test(password) },
                    { id: 'req-number', test: /[0-9]/.test(password) },
                    { id: 'req-special', test: /[^A-Za-z0-9]/.test(password) },
                    { id: 'req-different', test: password !== currentPasswordField.value }
                ];

                requirements.forEach(req => {
                    const element = document.getElementById(req.id);
                    if (req.test) {
                        element.classList.add('valid');
                    } else {
                        element.classList.remove('valid');
                    }
                });
            }

            // Confirm password validation
            confirmPasswordField.addEventListener('input', function() {
                const newPassword = newPasswordField.value;
                const confirmPassword = this.value;
                const feedback = document.getElementById('confirm_password_feedback');

                if (confirmPassword && newPassword !== confirmPassword) {
                    this.classList.add('error');
                    this.classList.remove('success');
                    feedback.textContent = 'Passwords do not match';
                    feedback.className = 'validation-feedback show invalid';
                } else if (confirmPassword && newPassword === confirmPassword) {
                    this.classList.remove('error');
                    this.classList.add('success');
                    feedback.textContent = '✓ Passwords match';
                    feedback.className = 'validation-feedback show valid';
                } else {
                    this.classList.remove('error', 'success');
                    feedback.className = 'validation-feedback';
                }

                validateForm();
            });

            // Current password validation
            currentPasswordField.addEventListener('input', function() {
                validateForm();
                
                // Re-validate "different from current" requirement
                if (newPasswordField.value) {
                    validateRequirements(newPasswordField.value);
                }
            });

            function validateForm() {
                const currentPassword = currentPasswordField.value;
                const newPassword = newPasswordField.value;
                const confirmPassword = confirmPasswordField.value;

                // Check if all requirements are met
                const passwordValid = newPassword.length >= <?php echo PASSWORD_MIN_LENGTH; ?> &&
                                    /[A-Z]/.test(newPassword) &&
                                    /[a-z]/.test(newPassword) &&
                                    /[0-9]/.test(newPassword) &&
                                    /[^A-Za-z0-9]/.test(newPassword) &&
                                    newPassword !== currentPassword;

                const allValid = currentPassword.length > 0 &&
                                passwordValid &&
                                confirmPassword === newPassword;

                changeBtn.disabled = !allValid;
            }

            // Form submission
            form.addEventListener('submit', function(e) {
                if (changeBtn.disabled) {
                    e.preventDefault();
                    return;
                }

                // Show loading state
                changeBtn.classList.add('btn-loading');
                changeBtn.disabled = true;
                changeBtn.textContent = 'Changing Password...';
            });

            // Auto-hide flash messages
            const flashMessage = document.getElementById('flashMessage');
            if (flashMessage) {
                setTimeout(() => {
                    flashMessage.style.opacity = '0';
                    setTimeout(() => flashMessage.remove(), 300);
                }, 5000);
            }

            // Keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                if (e.key === 's' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    if (!changeBtn.disabled) {
                        form.submit();
                    }
                }
                
                if (e.key === 'Escape') {
                    window.location.href = 'profile.php';
                }
            });

            // Generate password suggestion
            function generateStrongPassword() {
                const length = 12;
                const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
                let password = '';
                
                // Ensure at least one of each required type
                password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)];
                password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)];
                password += '0123456789'[Math.floor(Math.random() * 10)];
                password += '!@#$%^&*'[Math.floor(Math.random() * 8)];
                
                // Fill the rest randomly
                for (let i = 4; i < length; i++) {
                    password += charset[Math.floor(Math.random() * charset.length)];
                }
                
                // Shuffle the password
                return password.split('').sort(() => 0.5 - Math.random()).join('');
            }

            // Add generate password button (optional enhancement)
            const generateBtn = document.createElement('button');
            generateBtn.type = 'button';
            generateBtn.className = 'btn btn-secondary';
            generateBtn.style.cssText = 'font-size: 0.9rem; padding: 8px 15px; margin-top: 10px;';
            generateBtn.innerHTML = '🎲 Generate Strong Password';
            generateBtn.addEventListener('click', function() {
                const strongPassword = generateStrongPassword();
                newPasswordField.value = strongPassword;
                confirmPasswordField.value = strongPassword;
                
                // Trigger validation
                newPasswordField.dispatchEvent(new Event('input'));
                confirmPasswordField.dispatchEvent(new Event('input'));
                
                // Show the passwords temporarily
                newPasswordField.type = 'text';
                confirmPasswordField.type = 'text';
                
                setTimeout(() => {
                    newPasswordField.type = 'password';
                    confirmPasswordField.type = 'password';
                }, 3000);
                
                showNotification('Strong password generated and filled in!', 'success');
            });
            
            newPasswordField.parentNode.parentNode.appendChild(generateBtn);
        });

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 8px;
                color: white;
                font-weight: 600;
                z-index: 1000;
                animation: slideIn 0.3s ease;
                box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                max-width: 300px;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = '#00b894';
                    break;
                case 'error':
                    notification.style.background = '#d63031';
                    break;
                default:
                    notification.style.background = '#74b9ff';
            }
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 4000);
        }

        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>