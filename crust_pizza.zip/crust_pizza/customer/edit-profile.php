<?php
// customer/edit-profile.php - Edit Customer Profile
require_once '../includes/init.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isCustomer()) {
    $_SESSION['redirect_after_login'] = 'customer/edit-profile.php';
    setFlashMessage('Please login to edit your profile.', 'info');
    redirect('../login.php');
}

// Get customer details
$customer_id = getCurrentUserId();
$stmt = $conn->prepare("
    SELECT * FROM customers 
    WHERE customer_id = ? AND is_active = 1
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

if (!$customer) {
    setFlashMessage('Customer profile not found.', 'error');
    redirect('../index.php');
}

// Handle form submission
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid form submission. Please refresh and try again.';
    } else {
        // Sanitize and validate input data
        $first_name = sanitizeInput($_POST['first_name'] ?? '');
        $last_name = sanitizeInput($_POST['last_name'] ?? '');
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $phone = sanitizeInput($_POST['phone'] ?? '');
        $address = sanitizeInput($_POST['address'] ?? '');
        $city = sanitizeInput($_POST['city'] ?? '');
        $state = $_POST['state'] ?? '';
        $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
        
        // Validation
        if (empty($first_name)) $errors[] = "First name is required.";
        if (empty($last_name)) $errors[] = "Last name is required.";
        if (empty($email)) $errors[] = "Email address is required.";
        if (empty($phone)) $errors[] = "Phone number is required.";
        if (empty($address)) $errors[] = "Address is required.";
        if (empty($city)) $errors[] = "City is required.";
        if (empty($state)) $errors[] = "State is required.";
        if (empty($postal_code)) $errors[] = "Postal code is required.";
        
        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        
        // Phone number validation (Australian format)
        $phone_clean = preg_replace('/[^0-9]/', '', $phone);
        if (!isValidAustralianPhone($phone_clean)) {
            $errors[] = 'Please enter a valid Australian phone number.';
        }
        
        // Postal code validation (Australian format)
        if (!preg_match('/^[0-9]{4}$/', $postal_code)) {
            $errors[] = 'Please enter a valid 4-digit postal code.';
        }
        
        // State validation
        if (!array_key_exists($state, AU_STATES)) {
            $errors[] = "Please select a valid Australian state.";
        }
        
        // Check if email is already used by another customer
        if (empty($errors) && $email !== $customer['email']) {
            $email_check_stmt = $conn->prepare("SELECT customer_id FROM customers WHERE email = ? AND customer_id != ?");
            $email_check_stmt->bind_param("si", $email, $customer_id);
            $email_check_stmt->execute();
            
            if ($email_check_stmt->get_result()->num_rows > 0) {
                $errors[] = 'This email address is already in use by another account.';
            }
        }
        
        // If no errors, update the profile
        if (empty($errors)) {
            try {
                // Format phone number for storage
                $formatted_phone = formatAustralianPhone($phone_clean);
                
                $update_stmt = $conn->prepare("
                    UPDATE customers SET 
                        first_name = ?,
                        last_name = ?,
                        email = ?,
                        phone = ?,
                        address = ?,
                        city = ?,
                        state = ?,
                        postal_code = ?,
                        updated_at = NOW()
                    WHERE customer_id = ?
                ");
                
                $update_stmt->bind_param(
                    "ssssssssi",
                    $first_name,
                    $last_name,
                    $email,
                    $formatted_phone,
                    $address,
                    $city,
                    $state,
                    $postal_code,
                    $customer_id
                );
                
                if ($update_stmt->execute()) {
                    // Update session data if name changed
                    $_SESSION['user_name'] = $first_name;
                    $_SESSION['full_name'] = $first_name . ' ' . $last_name;
                    
                    setFlashMessage('Profile updated successfully!', 'success');
                    redirect('profile.php?updated=1');
                } else {
                    $errors[] = 'Failed to update profile. Please try again.';
                }
                
            } catch (Exception $e) {
                logError('Profile update error: ' . $e->getMessage());
                $errors[] = 'An error occurred while updating your profile. Please try again.';
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Include header
$current_page = 'edit-profile';
include '../templates/header2.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/edit-profile.css">
</head>
<body>
    <!-- Flash Messages -->
    <?php if (!empty($errors)): ?>
    <div class="flash-message flash-error" id="flashMessage">
        Please fix the errors below and try again.
    </div>
    <?php endif; ?>

    <div class="edit-profile-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>✏️ Edit Profile</h1>
            <p>Update your personal information and preferences</p>
        </div>

        <!-- Breadcrumb Navigation -->
        <div class="breadcrumb">
            <a href="../index.php">Home</a>
            <span>›</span>
            <a href="profile.php">My Profile</a>
            <span>›</span>
            <span>Edit Profile</span>
        </div>

        <!-- Edit Form -->
        <div class="edit-form-card">
            <div class="card-header">
                👤 Profile Information
            </div>
            
            <div class="card-content">
                <!-- Progress Bar -->
                <div class="form-progress">
                    <div class="progress-bar" id="progressBar"></div>
                </div>

                <!-- Profile Preview -->
                <div class="profile-preview">
                    <div class="preview-avatar" id="previewAvatar">
                        <?php echo strtoupper(substr($customer['first_name'], 0, 1) . substr($customer['last_name'], 0, 1)); ?>
                    </div>
                    <div class="preview-name" id="previewName">
                        <?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?>
                    </div>
                    <div class="preview-email" id="previewEmail">
                        <?php echo htmlspecialchars($customer['email']); ?>
                    </div>
                </div>

                <!-- Error Messages -->
                <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <strong>Please fix the following errors:</strong>
                    <ul class="error-list">
                        <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Edit Form -->
                <form method="POST" action="" id="editProfileForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                    <!-- Personal Information Section -->
                    <div class="form-section">
                        <h3>👤 Personal Information</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name" class="form-label required">First Name</label>
                                <div class="input-icon" data-icon="👤">
                                    <input type="text" 
                                           id="first_name" 
                                           name="first_name" 
                                           class="form-input" 
                                           required 
                                           maxlength="50"
                                           value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : htmlspecialchars($customer['first_name']); ?>">
                                </div>
                                <div class="validation-feedback" id="first_name_feedback"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="last_name" class="form-label required">Last Name</label>
                                <div class="input-icon" data-icon="👤">
                                    <input type="text" 
                                           id="last_name" 
                                           name="last_name" 
                                           class="form-input" 
                                           required 
                                           maxlength="50"
                                           value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : htmlspecialchars($customer['last_name']); ?>">
                                </div>
                                <div class="validation-feedback" id="last_name_feedback"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Information Section -->
                    <div class="form-section">
                        <h3>📞 Contact Information</h3>
                        
                        <div class="form-group">
                            <label for="email" class="form-label required">Email Address</label>
                            <div class="input-icon" data-icon="📧">
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-input" 
                                       required 
                                       maxlength="100"
                                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : htmlspecialchars($customer['email']); ?>">
                            </div>
                            <div class="validation-feedback" id="email_feedback"></div>
                            <span class="form-help">This will be used for order confirmations and important updates</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone" class="form-label required">Phone Number</label>
                            <div class="input-icon" data-icon="📱">
                                <input type="tel" 
                                       id="phone" 
                                       name="phone" 
                                       class="form-input" 
                                       required 
                                       placeholder="04XX XXX XXX"
                                       value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : htmlspecialchars($customer['phone']); ?>">
                            </div>
                            <div class="validation-feedback" id="phone_feedback"></div>
                            <span class="form-help">Australian mobile or landline number for delivery contact</span>
                        </div>
                    </div>

                    <!-- Address Information Section -->
                    <div class="form-section">
                        <h3>📍 Default Delivery Address</h3>
                        
                        <div class="form-group">
                            <label for="address" class="form-label required">Street Address</label>
                            <div class="input-icon" data-icon="🏠">
                                <input type="text" 
                                       id="address" 
                                       name="address" 
                                       class="form-input" 
                                       required 
                                       maxlength="255"
                                       placeholder="123 Main Street"
                                       value="<?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : htmlspecialchars($customer['address']); ?>">
                            </div>
                            <div class="validation-feedback" id="address_feedback"></div>
                        </div>
                        
                        <div class="form-row-3">
                            <div class="form-group">
                                <label for="city" class="form-label required">City/Suburb</label>
                                <div class="input-icon" data-icon="🏙️">
                                    <input type="text" 
                                           id="city" 
                                           name="city" 
                                           class="form-input" 
                                           required 
                                           maxlength="100"
                                           placeholder="Melbourne"
                                           value="<?php echo isset($_POST['city']) ? htmlspecialchars($_POST['city']) : htmlspecialchars($customer['city']); ?>">
                                </div>
                                <div class="validation-feedback" id="city_feedback"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="state" class="form-label required">State</label>
                                <select id="state" name="state" class="form-select" required>
                                    <option value="">Select State</option>
                                    <?php foreach (AU_STATES as $code => $name): ?>
                                        <option value="<?php echo $code; ?>" 
                                                <?php echo (isset($_POST['state']) ? $_POST['state'] : $customer['state']) === $code ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="validation-feedback" id="state_feedback"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="postal_code" class="form-label required">Postal Code</label>
                                <div class="input-icon" data-icon="📮">
                                    <input type="text" 
                                           id="postal_code" 
                                           name="postal_code" 
                                           class="form-input" 
                                           required 
                                           pattern="[0-9]{4}"
                                           maxlength="4"
                                           placeholder="3000"
                                           value="<?php echo isset($_POST['postal_code']) ? htmlspecialchars($_POST['postal_code']) : htmlspecialchars($customer['postal_code']); ?>">
                                </div>
                                <div class="validation-feedback" id="postal_code_feedback"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="profile.php" class="btn btn-secondary">
                            ❌ Cancel
                        </a>
                        <button type="submit" class="btn btn-primary" id="saveBtn">
                            💾 Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include '../templates/footer1.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('editProfileForm');
            const saveBtn = document.getElementById('saveBtn');
            const progressBar = document.getElementById('progressBar');
            
            // Form validation
            const validators = {
                first_name: {
                    validate: (value) => value.trim().length >= 2,
                    message: 'First name must be at least 2 characters'
                },
                last_name: {
                    validate: (value) => value.trim().length >= 2,
                    message: 'Last name must be at least 2 characters'
                },
                email: {
                    validate: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
                    message: 'Please enter a valid email address'
                },
                phone: {
                    validate: (value) => {
                        const clean = value.replace(/[^0-9]/g, '');
                        return clean.length === 10 && (clean.startsWith('04') || clean.startsWith('02') || clean.startsWith('03') || clean.startsWith('07') || clean.startsWith('08'));
                    },
                    message: 'Please enter a valid Australian phone number'
                },
                address: {
                    validate: (value) => value.trim().length >= 5,
                    message: 'Please enter a complete street address'
                },
                city: {
                    validate: (value) => value.trim().length >= 2,
                    message: 'Please enter a valid city name'
                },
                state: {
                    validate: (value) => value !== '',
                    message: 'Please select a state'
                },
                postal_code: {
                    validate: (value) => /^[0-9]{4}$/.test(value),
                    message: 'Please enter a valid 4-digit postal code'
                }
            };

            // Real-time validation
            Object.keys(validators).forEach(fieldName => {
                const field = document.getElementById(fieldName);
                const feedback = document.getElementById(fieldName + '_feedback');
                
                if (field && feedback) {
                    field.addEventListener('input', function() {
                        validateField(fieldName, this.value, feedback);
                        updateProgress();
                        updatePreview();
                    });
                    
                    field.addEventListener('blur', function() {
                        validateField(fieldName, this.value, feedback);
                    });
                }
            });

            function validateField(fieldName, value, feedbackElement) {
                const validator = validators[fieldName];
                const field = document.getElementById(fieldName);
                
                if (validator.validate(value)) {
                    field.classList.remove('error');
                    field.classList.add('success');
                    feedbackElement.textContent = '✓ Looks good!';
                    feedbackElement.className = 'validation-feedback show valid';
                    return true;
                } else {
                    field.classList.remove('success');
                    field.classList.add('error');
                    feedbackElement.textContent = validator.message;
                    feedbackElement.className = 'validation-feedback show invalid';
                    return false;
                }
            }

            function updateProgress() {
                const totalFields = Object.keys(validators).length;
                let validFields = 0;

                Object.keys(validators).forEach(fieldName => {
                    const field = document.getElementById(fieldName);
                    if (field && validators[fieldName].validate(field.value)) {
                        validFields++;
                    }
                });

                const progress = (validFields / totalFields) * 100;
                progressBar.style.width = progress + '%';
                
                // Enable/disable save button
                saveBtn.disabled = progress < 100;
            }

            function updatePreview() {
                const firstNameField = document.getElementById('first_name');
                const lastNameField = document.getElementById('last_name');
                const emailField = document.getElementById('email');
                
                const firstName = firstNameField.value.trim();
                const lastName = lastNameField.value.trim();
                const email = emailField.value.trim();
                
                if (firstName || lastName) {
                    const fullName = (firstName + ' ' + lastName).trim();
                    document.getElementById('previewName').textContent = fullName || 'Your Name';
                    
                    // Update avatar initials
                    const initials = (firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
                    document.getElementById('previewAvatar').textContent = initials || '??';
                }
                
                if (email) {
                    document.getElementById('previewEmail').textContent = email;
                }
            }

            // Phone number formatting
            const phoneInput = document.getElementById('phone');
            phoneInput.addEventListener('input', function() {
                let value = this.value.replace(/[^0-9]/g, '');
                
                if (value.length > 10) {
                    value = value.substring(0, 10);
                }
                
                // Format based on length
                if (value.length >= 6) {
                    if (value.startsWith('04')) {
                        // Mobile: 04XX XXX XXX
                        value = value.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
                    } else {
                        // Landline: (0X) XXXX XXXX
                        value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2 $3');
                    }
                }
                
                this.value = value;
            });

            // Postal code formatting
            const postalCodeInput = document.getElementById('postal_code');
            postalCodeInput.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '').substring(0, 4);
            });

            // Auto-suggest city based on postal code
            const postcodeToCity = {
                '3000': 'Melbourne',
                '3001': 'Melbourne',
                '3002': 'East Melbourne',
                '3003': 'West Melbourne',
                '3006': 'Southbank',
                '3008': 'Docklands',
                '3053': 'Carlton',
                '3121': 'Richmond',
                '3141': 'South Yarra',
                '3181': 'Prahran',
                '3182': 'St Kilda'
            };

            postalCodeInput.addEventListener('input', function() {
                const postcode = this.value;
                const cityField = document.getElementById('city');
                
                if (postcode.length === 4 && postcodeToCity[postcode] && !cityField.value) {
                    cityField.value = postcodeToCity[postcode];
                    validateField('city', cityField.value, document.getElementById('city_feedback'));
                    
                    // Visual feedback
                    cityField.style.backgroundColor = '#d4edda';
                    setTimeout(() => {
                        cityField.style.backgroundColor = '';
                    }, 1000);
                }
            });

            // Form submission handling
            form.addEventListener('submit', function(e) {
                // Validate all fields before submission
                let allValid = true;
                Object.keys(validators).forEach(fieldName => {
                    const field = document.getElementById(fieldName);
                    const feedback = document.getElementById(fieldName + '_feedback');
                    if (!validateField(fieldName, field.value, feedback)) {
                        allValid = false;
                    }
                });

                if (!allValid) {
                    e.preventDefault();
                    showNotification('Please fix all errors before saving', 'error');
                    return;
                }

                // Show loading state
                saveBtn.classList.add('btn-loading');
                saveBtn.disabled = true;
                saveBtn.textContent = 'Saving...';
            });

            // Auto-hide flash messages
            const flashMessage = document.getElementById('flashMessage');
            if (flashMessage) {
                setTimeout(() => {
                    flashMessage.style.opacity = '0';
                    setTimeout(() => flashMessage.remove(), 300);
                }, 5000);
            }

            // Initial validation and progress update
            updateProgress();
            updatePreview();

            // Email availability check (debounced)
            let emailCheckTimeout;
            const emailField = document.getElementById('email');
            const originalEmail = '<?php echo htmlspecialchars($customer["email"]); ?>';
            
            emailField.addEventListener('input', function() {
                clearTimeout(emailCheckTimeout);
                const email = this.value.trim();
                
                if (email !== originalEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    emailCheckTimeout = setTimeout(() => {
                        checkEmailAvailability(email);
                    }, 1000);
                }
            });

            function checkEmailAvailability(email) {
                fetch('../api/check-email.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email: email })
                })
                .then(response => response.json())
                .then(data => {
                    const feedback = document.getElementById('email_feedback');
                    const field = document.getElementById('email');
                    
                    if (data.available) {
                        field.classList.remove('error');
                        field.classList.add('success');
                        feedback.textContent = '✓ Email available';
                        feedback.className = 'validation-feedback show valid';
                    } else {
                        field.classList.remove('success');
                        field.classList.add('error');
                        feedback.textContent = '❌ Email already in use';
                        feedback.className = 'validation-feedback show invalid';
                    }
                })
                .catch(() => {
                    // Ignore errors for email checking
                });
            }

            // Keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                if (e.key === 's' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    if (!saveBtn.disabled) {
                        form.submit();
                    }
                }
                
                if (e.key === 'Escape') {
                    window.location.href = 'profile.php';
                }
            });

            // Unsaved changes warning
            let formChanged = false;
            const inputs = form.querySelectorAll('input, select');
            
            inputs.forEach(input => {
                input.addEventListener('change', () => {
                    formChanged = true;
                });
            });

            window.addEventListener('beforeunload', function(e) {
                if (formChanged && !form.submitted) {
                    e.preventDefault();
                    e.returnValue = '';
                }
            });

            form.addEventListener('submit', function() {
                form.submitted = true;
            });
        });

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 8px;
                color: white;
                font-weight: 600;
                z-index: 1000;
                animation: slideIn 0.3s ease;
                box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                max-width: 300px;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = '#00b894';
                    break;
                case 'error':
                    notification.style.background = '#d63031';
                    break;
                default:
                    notification.style.background = '#74b9ff';
            }
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 4000);
        }

        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>