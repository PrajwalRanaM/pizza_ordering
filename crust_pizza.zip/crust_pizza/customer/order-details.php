<?php

/**
 * Order Details Page
 * 
 * This page allows customers to view the details of a specific order.
 * It includes information such as order number, type, status, total amount,
 * payment method, and delivery/pickup details.
 * 
 * @package CustomerPortal
 */



// customer/orders.php - Customer Order details Page
require_once '../includes/init.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isCustomer()) {
    setFlashMessage('Please login to view your order history.', 'info');
    redirect('../login.php');
}

$customer_id = getCurrentUserId();

// Get pagination parameters
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = ORDERS_PER_PAGE;
$offset = ($page - 1) * $per_page;

// Get order details for viewing
$order_details = null;
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) {
    // Invalid order ID
    setFlashMessage('Invalid order ID.', 'error');
    redirect('orders.php');
}

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, c.first_name, c.last_name, c.email, c.phone,
           l.store_name, l.address as store_address, l.city as store_city,
           os.status_name
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
            JOIN locations l ON o.location_id = l.location_id
            JOIN order_statuses os ON o.order_status_id = os.status_id
            WHERE o.order_id = ?
        ");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $order_details = $stmt->get_result()->fetch_assoc();
       
    ?>
    
    <style>

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 2rem;
            color: var(--admin-primary);
            margin: 0;
        }

        .order-details {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }

        .details-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .details-header {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--admin-primary);
            margin-bottom: 20px;
            border-bottom: 2px solid #f8f9fa;
            padding-bottom: 10px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .info-item {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
        }

        .info-label {
            font-size: 0.85rem;
            color: #6c757d;
            margin-bottom: 3px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-value {
            font-weight: 600;
            color: var(--admin-primary);
        }

        .order-timeline {
            position: relative;
        }

        .timeline-item {
            display: flex;
            margin-bottom: 20px;
            position: relative;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 30px;
            bottom: -20px;
            width: 2px;
            background: #ddd;
        }

        .timeline-item:last-child::before {
            display: none;
        }

        .timeline-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: var(--admin-accent);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            margin-right: 15px;
            flex-shrink: 0;
            position: relative;
            z-index: 1;
        }

        .timeline-content {
            flex: 1;
        }

        .timeline-title {
            font-weight: 600;
            color: var(--admin-primary);
            margin-bottom: 3px;
        }

        .timeline-time {
            font-size: 0.85rem;
            color: #6c757d;
            margin-bottom: 5px;
        }

        .timeline-notes {
            font-size: 0.9rem;
            color: #495057;
            font-style: italic;
        }

        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--admin-primary);
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .admin-content {
                margin-left: 0;
            }

            .form-grid,
            .info-grid,
            .order-details {
                grid-template-columns: 1fr;
            }

            .filters {
                flex-direction: column;
                align-items: stretch;
            }

            .quick-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>

<!-- Order Details View -->
                <div class="page-header">
                    <h2 class="page-title">Order #<?php echo ($order_details['order_number']); ?></h2>
                    <a href="orders.php" class="btn btn-secondary">Back to Orders</a>
                </div>

                <div class="order-details">
                    <div class="order-main">
                        <!-- Order Information -->
                        <div class="details-card">
                            <div class="details-header">📋 Order Information</div>
                            
                            <div class="info-grid">
                                <div class="info-item">
                                    <div class="info-label">Order Number</div>
                                    <div class="info-value"><?php echo e($order_details['order_number']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Order Type</div>
                                    <div class="info-value">
                                        <?php echo $order_details['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Current Status</div>
                                    <div class="info-value">
                                        <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $order_details['status_name'])); ?>">
                                            <?php echo e($order_details['status_name']); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Total Amount</div>
                                    <div class="info-value"><?php echo formatPrice($order_details['total_amount']); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Payment Method</div>
                                    <div class="info-value"><?php echo ucfirst(str_replace('_', ' ', $order_details['payment_method'])); ?></div>
                                </div>
                                <div class="info-item">
                                    <div class="info-label">Payment Status</div>
                                    <div class="info-value" style="color: <?php echo $order_details['payment_status'] === 'completed' ? '#28a745' : '#ffc107'; ?>;">
                                        <?php echo ucfirst($order_details['payment_status']); ?>
                                    </div>
                                </div>
                            </div>

                            <?php if ($order_details['order_type'] === 'delivery'): ?>
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>📍 Delivery Address:</strong><br>
                                <?php echo e($order_details['delivery_address']); ?><br>
                                <?php echo e($order_details['delivery_city'] . ', ' . $order_details['delivery_state'] . ' ' . $order_details['delivery_postal_code']); ?>
                            </div>
                            <?php else: ?>
                            <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>🏪 Pickup Location:</strong><br>
                                <?php echo e($order_details['store_name']); ?><br>
                                <?php echo e($order_details['store_address'] . ', ' . $order_details['store_city']); ?>
                            </div>
                            <?php endif; ?>

                            <?php if (!empty($order_details['special_instructions'])): ?>
                            <div style="background: #fff3cd; padding: 15px; border-radius: 4px; margin-top: 15px;">
                                <strong>📝 Special Instructions:</strong><br>
                                <?php echo e($order_details['special_instructions']); ?>
                            </div>
                            <?php endif; ?>
                        </div>

                    
                    </div>