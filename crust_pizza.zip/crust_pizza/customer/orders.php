<?php
// customer/orders.php - Customer Order History Page
require_once '../includes/init.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isCustomer()) {
    setFlashMessage('Please login to view your order history.', 'info');
    redirect('../login.php');
}

$customer_id = getCurrentUserId();

// Get pagination parameters
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = ORDERS_PER_PAGE;
$offset = ($page - 1) * $per_page;

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$date_filter = $_GET['date'] ?? 'all';
$search = trim($_GET['search'] ?? '');

// Build WHERE conditions
$where_conditions = ['o.customer_id = ?'];
$params = [$customer_id];
$types = 'i';

// Status filter
if ($status_filter !== 'all' && is_numeric($status_filter)) {
    $where_conditions[] = 'o.order_status_id = ?';
    $params[] = $status_filter;
    $types .= 'i';
}

// Date filter
if ($date_filter !== 'all') {
    switch ($date_filter) {
        case 'today':
            $where_conditions[] = 'DATE(o.created_at) = CURDATE()';
            break;
        case 'week':
            $where_conditions[] = 'o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
            break;
        case 'month':
            $where_conditions[] = 'o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
            break;
        case 'year':
            $where_conditions[] = 'o.created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)';
            break;
    }
}

// Search filter
if (!empty($search)) {
    $where_conditions[] = '(o.order_number LIKE ? OR os.status_name LIKE ?)';
    $search_term = '%' . $search . '%';
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= 'ss';
}

$where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

// Get total count for pagination
$count_sql = "
    SELECT COUNT(*) as total
    FROM orders o
    JOIN order_statuses os ON o.order_status_id = os.status_id
    $where_clause
";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$total_orders = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_orders / $per_page);

// Get orders with details
$orders_sql = "
    SELECT 
        o.*,
        os.status_name,
        os.status_id,
        l.store_name,
        l.city as store_city,
        COUNT(oi.order_item_id) as item_count
    FROM orders o
    JOIN order_statuses os ON o.order_status_id = os.status_id
    JOIN locations l ON o.location_id = l.location_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    $where_clause
    GROUP BY o.order_id
    ORDER BY o.created_at DESC
    LIMIT ? OFFSET ?
";

// Add pagination parameters
$params[] = $per_page;
$params[] = $offset;
$types .= 'ii';

$orders_stmt = $conn->prepare($orders_sql);
$orders_stmt->bind_param($types, ...$params);
$orders_stmt->execute();
$orders = $orders_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get available order statuses for filter
$status_sql = "SELECT * FROM order_statuses ORDER BY display_order";
$statuses = $conn->query($status_sql)->fetch_all(MYSQLI_ASSOC);

// Helper function to get status badge class
function getStatusBadgeClass($status_id) {
    switch ($status_id) {
        case ORDER_STATUS_PENDING:
            return 'status-pending';
        case ORDER_STATUS_PREPARING:
            return 'status-preparing';
        case ORDER_STATUS_READY:
        case ORDER_STATUS_OUT_FOR_DELIVERY:
            return 'status-progress';
        case ORDER_STATUS_DELIVERED:
        case ORDER_STATUS_PICKED_UP:
            return 'status-completed';
        case ORDER_STATUS_CANCELLED:
        case ORDER_STATUS_FAILED:
            return 'status-cancelled';
        default:
            return 'status-pending';
    }
}

// Include header
$current_page = 'customer/orders.php';
include '../templates/header2.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/orders.css">
</head>
<body>
    <div class="orders-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <span>📋</span>
                My Orders
            </h1>
            <p>Track your order history and reorder your favorites</p>
            
            <?php if ($total_orders > 0): ?>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $total_orders; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">
                        <?php 
                        // Calculate completed orders
                        $completed_count = 0;
                        foreach ($orders as $order) {
                            if (in_array($order['status_id'], [ORDER_STATUS_DELIVERED, ORDER_STATUS_PICKED_UP])) {
                                $completed_count++;
                            }
                        }
                        echo $completed_count;
                        ?>
                    </div>
                    <div class="stat-label">Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">
                        <?php 
                        // Calculate total spent (simplified - in real app, query database)
                        $total_spent = 0;
                        foreach ($orders as $order) {
                            if (in_array($order['status_id'], [ORDER_STATUS_DELIVERED, ORDER_STATUS_PICKED_UP])) {
                                $total_spent += $order['total_amount'];
                            }
                        }
                        echo formatPrice($total_spent);
                        ?>
                    </div>
                    <div class="stat-label">Total Spent</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">
                        <?php
                        // Find favorite order type
                        $delivery_count = 0;
                        foreach ($orders as $order) {
                            if ($order['order_type'] === 'delivery') $delivery_count++;
                        }
                        echo $delivery_count > (count($orders) - $delivery_count) ? '🚚' : '🏪';
                        ?>
                    </div>
                    <div class="stat-label">Preferred</div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Filters Section -->
        <div class="filters-section">
            <div class="filters-header">
                <div class="filters-title">🔍 Filter Orders</div>
                <?php if ($status_filter !== 'all' || $date_filter !== 'all' || !empty($search)): ?>
                <a href="orders.php" class="clear-filters">Clear Filters</a>
                <?php endif; ?>
            </div>
            
            <form method="GET" action="orders.php" id="filtersForm">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">Status</label>
                        <select name="status" class="filter-select">
                            <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Statuses</option>
                            <?php foreach ($statuses as $status): ?>
                            <option value="<?php echo $status['status_id']; ?>" 
                                    <?php echo $status_filter == $status['status_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($status['status_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Date Range</label>
                        <select name="date" class="filter-select">
                            <option value="all" <?php echo $date_filter === 'all' ? 'selected' : ''; ?>>All Time</option>
                            <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                            <option value="week" <?php echo $date_filter === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                            <option value="month" <?php echo $date_filter === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
                            <option value="year" <?php echo $date_filter === 'year' ? 'selected' : ''; ?>>Last Year</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Search</label>
                        <input type="text" 
                               name="search" 
                               class="filter-input" 
                               placeholder="Order number or status..."
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">&nbsp;</label>
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                            <a href="orders.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- Orders List -->
        <div class="orders-list">
            <div class="orders-header">
                <div class="orders-title">
                    📦 Your Orders
                    <?php if ($status_filter !== 'all' || $date_filter !== 'all' || !empty($search)): ?>
                        <span style="font-weight: normal; color: var(--gray-dark); font-size: 0.9rem;">
                            (Filtered Results)
                        </span>
                    <?php endif; ?>
                </div>
                <div class="orders-count">
                    Showing <?php echo count($orders); ?> of <?php echo $total_orders; ?> orders
                </div>
            </div>

            <?php if (empty($orders)): ?>
            <!-- Empty State -->
            <div class="empty-state">
                <div class="empty-icon">📦</div>
                <?php if ($total_orders === 0): ?>
                <h3>No orders yet</h3>
                <p>You haven't placed any orders. Ready to try our delicious pizza?</p>
                <a href="../menu.php" class="btn btn-primary">
                    🍕 Browse Menu
                </a>
                <?php else: ?>
                <h3>No orders found</h3>
                <p>No orders match your current filters. Try adjusting your search criteria.</p>
                <a href="orders.php" class="btn btn-primary">
                    Show All Orders
                </a>
                <?php endif; ?>
            </div>
            
            <?php else: ?>
            
            <!-- Order Cards -->
            <?php foreach ($orders as $order): ?>
            <div class="order-card" data-order-id="<?php echo $order['order_id']; ?>">
                <div class="order-header">
                    <div class="order-info">
                        <div class="order-number">
                            Order #<?php echo htmlspecialchars($order['order_number']); ?>
                        </div>
                        <div class="order-date">
                            Placed on <?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?>
                        </div>
                        <div class="order-details">
                            <div class="order-type">
                                <?php if ($order['order_type'] === 'delivery'): ?>
                                    🚚 Delivery
                                <?php else: ?>
                                    🏪 Pickup
                                <?php endif; ?>
                            </div>
                            <div class="order-location">
                                📍 <?php echo htmlspecialchars($order['store_name'] . ', ' . $order['store_city']); ?>
                            </div>
                            <div class="order-items">
                                🍕 <?php echo $order['item_count']; ?> item<?php echo $order['item_count'] !== 1 ? 's' : ''; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="order-status">
                        <div class="status-badge <?php echo getStatusBadgeClass($order['order_status_id']); ?>">
                            <?php echo htmlspecialchars($order['status_name']); ?>
                        </div>
                        <div class="order-total">
                            <?php echo formatPrice($order['total_amount']); ?>
                        </div>
                    </div>
                </div>
                
                <div class="order-actions">
                    <a href="../order-tracking.php?order=<?php echo urlencode($order['order_number']); ?>" 
                       class="btn btn-primary btn-sm">
                        📱 Track Order
                    </a>

                    <a href="order-details.php?order_id=<?php echo $order['order_id']; ?>" 
                       class="btn btn-secondary btn-sm">
                        👁️ View Details
                    </a>
                    
                    <?php if (in_array($order['order_status_id'], [ORDER_STATUS_DELIVERED, ORDER_STATUS_PICKED_UP])): ?>
                    <button class="btn btn-secondary btn-sm" 
                            onclick="reorderItems(<?php echo $order['order_id']; ?>)">
                        🔄 Reorder
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($order['order_status_id'] === ORDER_STATUS_PENDING): ?>
                        <a class="btn btn-secondary btn-sm" 
                        href="cancel-order.php?order_id=<?= $order['order_id'] ?>" 
                        onclick="return confirm('Are you sure you want to cancel this order?');">
                            ❌ Cancel Order
                        </a>
                    <?php endif; ?>

                    
                    <?php if (in_array($order['order_status_id'], [ORDER_STATUS_DELIVERED, ORDER_STATUS_PICKED_UP])): ?>
                    <button class="btn btn-secondary btn-sm" 
                            onclick="writeReview(<?php echo $order['order_id']; ?>)">
                        ⭐ Review
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <!-- Pagination -->
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($status_filter); ?>&date=<?php echo urlencode($date_filter); ?>&search=<?php echo urlencode($search); ?>" 
               class="prev-page">← Previous</a>
            <?php else: ?>
            <span class="prev-page disabled">← Previous</span>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i == $page): ?>
                <span class="current"><?php echo $i; ?></span>
                <?php else: ?>
                <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>&date=<?php echo urlencode($date_filter); ?>&search=<?php echo urlencode($search); ?>">
                    <?php echo $i; ?>
                </a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($status_filter); ?>&date=<?php echo urlencode($date_filter); ?>&search=<?php echo urlencode($search); ?>" 
               class="next-page">Next →</a>
            <?php else: ?>
            <span class="next-page disabled">Next →</span>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Reorder items function
        function reorderItems(orderId) {
            window.location.href = `reorder.php?order_id=${orderId}`;
        }

        // Cancel order function
        function cancelOrder(orderId) {
            if (confirm('Are you sure you want to cancel this order?')) {
                window.location.href = `cancel-order.php?order_id=${orderId}`;
            }
        }

        // Write review function
        function writeReview(orderId) {
            window.location.href = `write-review.php?order_id=${orderId}`;
        }
        // Close notification
        document.querySelectorAll('.close-notification').forEach(button => {
            button.addEventListener('click', function() {
                this.parentElement.style.display = 'none';
            });
        });
        // Mobile menu toggle
        document.getElementById('mobileMenuToggle').addEventListener('click', function() {
            const menu = document.querySelector('.header .nav-links');
            menu.classList.toggle('active');
            this.classList.toggle('active');
        });
        // Close mobile menu on link click
        document.querySelectorAll('.header .nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                const menu = document.querySelector('.header .nav-links');
                menu.classList.remove('active');
                document.getElementById('mobileMenuToggle').classList.remove('active');
            });
        });
    </script>
</body>
</html>
<?php
// Include footer
include '../templates/footer1.php';
// Close database connection
$conn->close();
?>