<?php
// customer/profile.php - Customer Profile Management
require_once '../includes/init.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isCustomer()) {
    $_SESSION['redirect_after_login'] = 'customer/profile.php';
    setFlashMessage('Please login to view your profile.', 'info');
    redirect('../login.php');
}

// Get customer details
$customer_id = getCurrentUserId();
$stmt = $conn->prepare("
    SELECT * FROM customers 
    WHERE customer_id = ? AND is_active = 1
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();

if (!$customer) {
    setFlashMessage('Customer profile not found.', 'error');
    redirect('../index.php');
}

// Get order statistics
$stats_stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_orders,
        SUM(total_amount) as total_spent,
        AVG(total_amount) as avg_order_value,
        MAX(created_at) as last_order_date
    FROM orders 
    WHERE customer_id = ?
");
$stats_stmt->bind_param("i", $customer_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

// Get recent orders
$recent_orders_stmt = $conn->prepare("
    SELECT 
        o.order_id,
        o.order_number,
        o.created_at,
        o.total_amount,
        o.order_type,
        os.status_name,
        l.store_name
    FROM orders o
    JOIN order_statuses os ON o.order_status_id = os.status_id
    JOIN locations l ON o.location_id = l.location_id
    WHERE o.customer_id = ?
    ORDER BY o.created_at DESC
    LIMIT 5
");
$recent_orders_stmt->bind_param("i", $customer_id);
$recent_orders_stmt->execute();
$recent_orders = $recent_orders_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Include header
$current_page = 'profile';
include '../templates/header2.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>
    <!-- Flash Messages -->
    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('error')): ?>
    <div class="flash-message flash-error" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('info')): ?>
    <div class="flash-message flash-info" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header fade-in">
            <h1>👤 My Profile</h1>
            <p>Manage your account and view your pizza ordering history</p>
        </div>

        <!-- Profile Sidebar -->
        <div class="profile-sidebar">
            <!-- Profile Info Card -->
            <div class="profile-card slide-up">
                <div class="card-content">
                    <div class="profile-avatar">
                        <?php echo strtoupper(substr($customer['first_name'], 0, 1) . substr($customer['last_name'], 0, 1)); ?>
                    </div>
                    
                    <div class="profile-name">
                        <?php echo htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']); ?>
                    </div>
                    
                    <div class="profile-username">
                        @<?php echo htmlspecialchars($customer['username']); ?>
                    </div>

                    <div class="verification-badge">
                        ✓ Verified Customer
                    </div>

                    <div class="member-since">
                        <strong>Member Since</strong>
                        <?php echo date('F Y', strtotime($customer['created_at'])); ?>
                    </div>

                    <div class="profile-actions">
                        <a href="edit-profile.php" class="profile-btn btn-primary">
                            ✏️ Edit Profile
                        </a>
                        <a href="change-password.php" class="profile-btn btn-secondary">
                            🔒 Change Password
                        </a>
                        
                    </div>
                </div>
            </div>

            <!-- Contact Information -->
            <div class="profile-card slide-up">
                <div class="card-header">
                    📞 Contact Information
                </div>
                <div class="card-content">
                    <div class="info-row">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($customer['email']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Phone</span>
                        <span class="info-value"><?php echo htmlspecialchars(formatAustralianPhone($customer['phone'])); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Address</span>
                        <span class="info-value">
                            <?php echo htmlspecialchars($customer['address']); ?><br>
                            <?php echo htmlspecialchars($customer['city'] . ', ' . $customer['state'] . ' ' . $customer['postal_code']); ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Loyalty Points (Optional Feature) -->
            <div class="loyalty-section slide-up">
                <div class="loyalty-title">🏆 Loyalty Points</div>
                <div class="loyalty-points">
                    <?php echo rand(50, 500); ?>
                </div>
                <div class="loyalty-desc">
                    Earn 1 point for every $1 spent!<br>
                    Redeem 100 points for $10 off
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Order Statistics -->
            <div class="stats-grid">
                <div class="stat-card orders slide-up">
                    <div class="stat-icon">📊</div>
                    <div class="stat-number"><?php echo $stats['total_orders'] ?? 0; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                
                <div class="stat-card spent slide-up">
                    <div class="stat-icon">💰</div>
                    <div class="stat-number"><?php echo formatPrice($stats['total_spent'] ?? 0); ?></div>
                    <div class="stat-label">Total Spent</div>
                </div>
                
                <div class="stat-card average slide-up">
                    <div class="stat-icon">📈</div>
                    <div class="stat-number"><?php echo formatPrice($stats['avg_order_value'] ?? 0); ?></div>
                    <div class="stat-label">Average Order</div>
                </div>
                
                <div class="stat-card last-order slide-up">
                    <div class="stat-icon">🕒</div>
                    <div class="stat-number">
                        <?php 
                        if ($stats['last_order_date']) {
                            $days_ago = round((time() - strtotime($stats['last_order_date'])) / (60 * 60 * 24));
                            echo $days_ago == 0 ? 'Today' : $days_ago . 'd';
                        } else {
                            echo 'Never';
                        }
                        ?>
                    </div>
                    <div class="stat-label">Last Order</div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="profile-card slide-up">
                <div class="card-header">
                    ⚡ Quick Actions
                </div>
                <div class="card-content">
                    <div class="quick-actions">
                        <a href="../menu.php" class="quick-action">
                            <span class="quick-action-icon">🍕</span>
                            <span>Order Now</span>
                        </a>
                        <a href="../builder.php" class="quick-action">
                            <span class="quick-action-icon">🎨</span>
                            <span>Build Pizza</span>
                        </a>
                        <a href="orders.php" class="quick-action">
                            <span class="quick-action-icon">📋</span>
                            <span>Order History</span>
                        </a>
                        <a href="../order-tracking.php" class="quick-action">
                            <span class="quick-action-icon">🚚</span>
                            <span>Track Order</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="orders-section slide-up">
                <div class="orders-header">
                    <span>📋 Recent Orders</span>
                    <a href="orders.php" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">
                        View All →
                    </a>
                </div>
                
                <div class="orders-list">
                    <?php if (empty($recent_orders)): ?>
                    <div class="empty-state">
                        <h3>🍕 No orders yet!</h3>
                        <p>You haven't placed any orders yet. Why not start with our delicious pizzas?</p>
                        <a href="../menu.php" class="profile-btn btn-primary" style="display: inline-block; margin-top: 15px;">
                            🛒 Order Now
                        </a>
                    </div>
                    <?php else: ?>
                        <?php foreach ($recent_orders as $order): ?>
                        <div class="order-item">
                            <div class="order-details">
                                <div class="order-number">
                                    Order #<?php echo htmlspecialchars($order['order_number']); ?>
                                </div>
                                <div class="order-meta">
                                    <span><?php echo date('M j, Y g:i A', strtotime($order['created_at'])); ?></span>
                                    <span class="order-type <?php echo 'type-' . $order['order_type']; ?>">
                                        <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                    </span>
                                    <span class="order-status status-<?php echo strtolower(str_replace(' ', '-', $order['status_name'])); ?>">
                                        <?php echo htmlspecialchars($order['status_name']); ?>
                                    </span>
                                    <span style="color: var(--gray-dark);">
                                        📍 <?php echo htmlspecialchars($order['store_name']); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="order-amount">
                                <?php echo formatPrice($order['total_amount']); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include '../templates/footer1.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-hide flash messages
            const flashMessage = document.getElementById('flashMessage');
            if (flashMessage) {
                setTimeout(() => {
                    flashMessage.style.opacity = '0';
                    setTimeout(() => flashMessage.remove(), 300);
                }, 5000);
            }

            // Add animation delays to cards
            const slideUpElements = document.querySelectorAll('.slide-up');
            slideUpElements.forEach((element, index) => {
                element.style.animationDelay = (index * 0.1) + 's';
            });

            // Update member since with more detailed info
            updateMembershipInfo();

            // Add interaction effects
            addInteractionEffects();
        });

        function updateMembershipInfo() {
            const memberDate = new Date('<?php echo $customer["created_at"]; ?>');
            const now = new Date();
            const diffTime = Math.abs(now - memberDate);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            let membershipText = '';
            if (diffDays < 30) {
                membershipText = `${diffDays} days`;
            } else if (diffDays < 365) {
                const months = Math.floor(diffDays / 30);
                membershipText = `${months} month${months > 1 ? 's' : ''}`;
            } else {
                const years = Math.floor(diffDays / 365);
                const remainingMonths = Math.floor((diffDays % 365) / 30);
                membershipText = `${years} year${years > 1 ? 's' : ''}`;
                if (remainingMonths > 0) {
                    membershipText += ` ${remainingMonths} month${remainingMonths > 1 ? 's' : ''}`;
                }
            }

            // Could update a tooltip or additional info element here
        }

        function addInteractionEffects() {
            // Add click effects to stat cards
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'scale(0.98)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 150);
                });
            });

            // Add hover effects to order items
            const orderItems = document.querySelectorAll('.order-item');
            orderItems.forEach(item => {
                item.addEventListener('click', function() {
                    const orderNumber = this.querySelector('.order-number').textContent;
                    const orderNumberOnly = orderNumber.replace('Order #', '');
                    
                    // Redirect to order tracking
                    window.location.href = `../order-tracking.php?order=${orderNumberOnly}`;
                });
                
                // Add hover cursor
                item.style.cursor = 'pointer';
            });

            // Add keyboard navigation
            document.addEventListener('keydown', function(e) {
                if (e.key === 'e' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    window.location.href = 'edit-profile.php';
                }
                
                if (e.key === 'o' && (e.ctrlKey || e.metaKey)) {
                    e.preventDefault();
                    window.location.href = 'orders.php';
                }
            });

            // Add tooltips for stats
            addStatTooltips();
        }

        function addStatTooltips() {
            const stats = [
                { selector: '.orders', text: 'Total number of orders you\'ve placed with us' },
                { selector: '.spent', text: 'Total amount you\'ve spent on delicious pizzas' },
                { selector: '.average', text: 'Your average order value' },
                { selector: '.last-order', text: 'Days since your last order' }
            ];

            stats.forEach(stat => {
                const element = document.querySelector(`.stat-card${stat.selector}`);
                if (element) {
                    element.title = stat.text;
                }
            });
        }

        // Progressive enhancement: Add animations
        function animateNumbers() {
            const numbers = document.querySelectorAll('.stat-number');
            numbers.forEach(number => {
                const finalValue = number.textContent;
                const isPrice = finalValue.includes(');
                const numericValue = parseFloat(finalValue.replace(/[^0-9.]/g, ''));
                
                if (!isNaN(numericValue) && numericValue > 0) {
                    let current = 0;
                    const increment = numericValue / 30; // 30 frames
                    const timer = setInterval(() => {
                        current += increment;
                        if (current >= numericValue) {
                            current = numericValue;
                            clearInterval(timer);
                        }
                        
                        if (isPrice) {
                            number.textContent = ' + current.toFixed(2);
                        } else if (finalValue.includes('d')) {
                            number.textContent = Math.floor(current) + 'd';
                        } else {
                            number.textContent = Math.floor(current);
                        }
                    }, 50);
                }
            });
        }

        // Start number animation after a delay
        setTimeout(animateNumbers, 800);

        // Add notification for profile updates
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 8px;
                color: white;
                font-weight: 600;
                z-index: 1000;
                animation: slideIn 0.3s ease;
                box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                max-width: 300px;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = '#00b894';
                    break;
                case 'error':
                    notification.style.background = '#d63031';
                    break;
                default:
                    notification.style.background = '#74b9ff';
            }
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 4000);
        }

        // Check for URL parameters for success messages
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('updated') === '1') {
            showNotification('Profile updated successfully!', 'success');
        }
        if (urlParams.get('password_changed') === '1') {
            showNotification('Password changed successfully!', 'success');
        }
    </script>

    <style>
    /* Additional animations */
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    /* Accessibility improvements */
    @media (prefers-reduced-motion: reduce) {
        .fade-in,
        .slide-up,
        .stat-card,
        .profile-btn {
            animation: none;
            transition: none;
        }
    }
    
    /* Focus styles for better accessibility */
    .profile-btn:focus,
    .quick-action:focus {
        outline: 2px solid var(--primary-color);
        outline-offset: 2px;
    }
    
    /* High contrast mode */
    @media (prefers-contrast: high) {
        .stat-card {
            border: 2px solid var(--text-dark);
        }
        
        .profile-card {
            border: 1px solid var(--gray-dark);
        }
    }
    
    /* Print styles */
    @media print {
        .profile-actions,
        .quick-actions,
        .flash-message {
            display: none;
        }
        
        .profile-container {
            grid-template-columns: 1fr;
            margin-top: 0;
        }
        
        .profile-card,
        .stat-card {
            box-shadow: none;
            border: 1px solid #000;
        }
    }
    </style>
</body>
</html>