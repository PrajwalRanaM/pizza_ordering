<?php
// includes/auth.php - Authentication functions for Crust Pizza

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']);
}

/**
 * Check if user is a specific type
 */
function isUserType($type) {
    return isLoggedIn() && $_SESSION['user_type'] === $type;
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isUserType('admin');
}

/**
 * Check if user is employee
 */
function isEmployee() {
    return isUserType('employee');
}

/**
 * Check if user is customer
 */
function isCustomer() {
    return isUserType('customer');
}

/**
 * Check if employee has specific role
 */
function hasRole($role_name) {
    return isEmployee() && isset($_SESSION['role_name']) && $_SESSION['role_name'] === $role_name;
}

/**
 * Require login - redirect to login page if not logged in
 */
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: login.php');
        exit();
    }
}

/**
 * Require specific user type
 */
function requireUserType($type) {
    requireLogin();
    if (!isUserType($type)) {
        header('Location: /access-denied.php');
        exit();
    }
}

/**
 * Require admin access
 */
function requireAdmin() {
    requireUserType('admin');
}

/**
 * Require employee access
 */
function requireEmployee() {
    requireUserType('employee');
}

/**
 * Require customer access
 */
function requireCustomer() {
    requireUserType('customer');
}

/**
 * Require specific employee role
 */
function requireRole($role_name) {
    requireEmployee();
    if (!hasRole($role_name)) {
        header('Location: /access-denied.php');
        exit();
    }
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user type
 */
function getCurrentUserType() {
    return $_SESSION['user_type'] ?? null;
}

/**
 * Get current user name
 */
function getCurrentUserName() {
    return $_SESSION['user_name'] ?? 'Guest';
}

/**
 * Get current user full name
 */
function getCurrentUserFullName() {
    return $_SESSION['full_name'] ?? 'Guest User';
}

/**
 * Logout user
 */
function logout() {
    // Ensure session is started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy the session
    session_destroy();
    
    // Redirect to home page
    header('Location: login.php');
    exit();
}

/**
 * Update user last activity
 */
function updateLastActivity($conn) {
    if (!isLoggedIn()) return;
    
    $user_id = getCurrentUserId();
    $user_type = getCurrentUserType();
    
    // Update last activity based on user type
    switch($user_type) {
        case 'customer':
            $stmt = $conn->prepare("UPDATE customers SET updated_at = NOW() WHERE customer_id = ?");
            break;
        case 'employee':
            $stmt = $conn->prepare("UPDATE employees SET updated_at = NOW() WHERE employee_id = ?");
            break;
        case 'admin':
            $stmt = $conn->prepare("UPDATE admins SET updated_at = NOW() WHERE admin_id = ?");
            break;
        default:
            return;
    }
    
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * Check if session has expired (30 minutes of inactivity)
 */
function checkSessionTimeout() {
    $timeout = 1800; // 30 minutes
    
    if (isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > $timeout) {
            logout();
        }
    }
    
    $_SESSION['last_activity'] = time();
}

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Get user's location (for employees)
 */
function getUserLocation($conn) {
    if (!isEmployee()) return null;
    
    $user_id = getCurrentUserId();
    $stmt = $conn->prepare("SELECT location_id FROM employees WHERE employee_id = ?");
    
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return $row['location_id'];
        }
        $stmt->close();
    }
    
    return null;
}

/**
 * Check if user can access specific order
 */
function canAccessOrder($conn, $order_id) {
    if (!isLoggedIn()) return false;
    
    $user_id = getCurrentUserId();
    $user_type = getCurrentUserType();
    
    switch($user_type) {
        case 'customer':
            // Customers can only access their own orders
            $stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ? AND customer_id = ?");
            $stmt->bind_param("ii", $order_id, $user_id);
            break;
            
        case 'employee':
            // Employees can access orders from their location
            $location_id = getUserLocation($conn);
            $stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ? AND location_id = ?");
            $stmt->bind_param("ii", $order_id, $location_id);
            break;
            
        case 'admin':
            // Admins can access all orders
            return true;
            
        default:
            return false;
    }
    
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        $can_access = $result->num_rows > 0;
        $stmt->close();
        return $can_access;
    }
    
    return false;
}

/**
 * Password validation
 */
function validatePassword($password) {
    $errors = [];
    
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter.";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter.";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number.";
    }
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Password must contain at least one special character.";
    }
    
    return $errors;
}

/**
 * Sanitize user input
 */
function sanitizeInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

/**
 * Format phone number for display
 */
function formatPhoneNumber($phone) {
    $clean = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($clean) === 10) {
        return preg_replace('/(\d{4})(\d{3})(\d{3})/', '$1 $2 $3', $clean);
    }
    return $phone;
}

/**
 * Create user session
 */
function createUserSession($user_data, $user_type) {
    $_SESSION['user_id'] = $user_data['user_id'];
    $_SESSION['user_name'] = $user_data['first_name'];
    $_SESSION['user_type'] = $user_type;
    $_SESSION['full_name'] = $user_data['first_name'] . ' ' . $user_data['last_name'];
    $_SESSION['last_activity'] = time();
    
    // Add role info for employees
    if ($user_type === 'employee' && isset($user_data['role_name'])) {
        $_SESSION['role_id'] = $user_data['role_id'];
        $_SESSION['role_name'] = $user_data['role_name'];
    }
}
?>