<?php
// includes/db.php - Database connection file
// This maintains backward compatibility with existing code

// Include the Database class
require_once __DIR__ . '/../config/database.php';

// Get connection using the Database singleton
try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
} catch (Exception $e) {
    // Error is already handled by Database class
    exit();
}
?>