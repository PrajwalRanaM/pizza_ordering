<?php
// includes/init.php - Initialize application settings and dependencies

// Set session configuration BEFORE starting session
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Lax');

// Load configuration files in correct order
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/constants.php';

// Load database connection
require_once __DIR__ . '/db.php';

// Load authentication functions
require_once __DIR__ . '/auth.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// Check session timeout
checkSessionTimeout();

// Update last activity
updateLastActivity($conn);

// Additional initialization tasks

// Set default timezone (in case it wasn't set in config)
if (!ini_get('date.timezone')) {
    date_default_timezone_set('Australia/Melbourne');
}

// Create upload directories if they don't exist
$upload_dirs = [
    UPLOADS_PATH,
    UPLOADS_PATH . 'products/',
    UPLOADS_PATH . 'temp/',
    ROOT_PATH . 'logs/'
];

foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Auto-load classes (simple autoloader)
spl_autoload_register(function ($class_name) {
    $file = CLASSES_PATH . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Global helper functions

/**
 * Redirect to a URL
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Check if request is AJAX
 */
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

/**
 * Get base URL
 */
function baseUrl($path = '') {
    return SITE_URL . ltrim($path, '/');
}

/**
 * Get asset URL
 */
function assetUrl($path = '') {
    return ASSETS_PATH . ltrim($path, '/');
}

/**
 * Display flash message
 */
function getFlashMessage($type = 'info') {
    if (isset($_SESSION['flash_' . $type])) {
        $message = $_SESSION['flash_' . $type];
        unset($_SESSION['flash_' . $type]);
        return $message;
    }
    return null;
}

/**
 * Set flash message
 */
function setFlashMessage($message, $type = 'info') {
    $_SESSION['flash_' . $type] = $message;
}

/**
 * Format price
 */
function formatPrice($price) {
    return CURRENCY_SYMBOL . number_format($price, 2);
}

/**
 * Check if store is open
 */
function isStoreOpen() {
    $current_hour = (int)date('H');
    return $current_hour >= OPENING_HOUR && $current_hour < CLOSING_HOUR;
}

/**
 * Get user's selected location
 */
function getSelectedLocation() {
    return $_SESSION[SESSION_LOCATION_ID] ?? $_COOKIE[COOKIE_LOCATION] ?? null;
}

/**
 * Debug function (only works in development)
 */
function debug($data, $die = false) {
    if (ENVIRONMENT === 'development') {
        echo '<pre>';
        var_dump($data);
        echo '</pre>';
        if ($die) die();
    }
}

/**
 * Log error to file
 */
function logError($message, $context = []) {
    $log_file = ROOT_PATH . 'logs/error.log';
    $timestamp = date('Y-m-d H:i:s');
    $context_string = !empty($context) ? json_encode($context) : '';
    $log_message = "[$timestamp] $message $context_string" . PHP_EOL;
    
    error_log($log_message, 3, $log_file);
}

/**
 * Sanitize output
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Check if user has permission
 */
function hasPermission($permission) {
    // Implement permission checking logic
    if (isAdmin()) return true;
    
    // Add more permission checks as needed
    return false;
}

/**
 * Get current URL
 */
function currentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

/**
 * Validate Australian phone number
 */
function isValidAustralianPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return preg_match('/^(04|05)\d{8}$/', $phone) || preg_match('/^(02|03|07|08)\d{8}$/', $phone);
}

/**
 * Format Australian phone number
 */
function formatAustralianPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    if (strlen($phone) === 10) {
        if (substr($phone, 0, 2) === '04' || substr($phone, 0, 2) === '05') {
            // Mobile
            return preg_replace('/(\d{4})(\d{3})(\d{3})/', '$1 $2 $3', $phone);
        } else {
            // Landline
            return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2 $3', $phone);
        }
    }
    
    return $phone;
}
?>