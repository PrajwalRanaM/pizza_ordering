<?php
// index.php - Homepage with location selection
require_once 'includes/init.php';

// Check if returning from successful registration
$welcome = isset($_GET['welcome']) && $_GET['welcome'] == '1';

// Get selected location from session or cookie
$selected_location = $_SESSION[SESSION_LOCATION_ID] ?? $_COOKIE[COOKIE_LOCATION] ?? null;

// Fetch all active locations
$locations_sql = "SELECT location_id, store_name, address, city, state, postal_code, phone 
                 FROM locations 
                 WHERE is_active = 1 
                 ORDER BY city, store_name";
$locations_result = $conn->query($locations_sql);
$locations = [];
while ($row = $locations_result->fetch_assoc()) {
    $locations[] = $row;
}

// If a location is selected, get featured pizzas
$pizzas = [];
if ($selected_location) {
    // Fetch featured pizzas
    $pizza_sql = "
        SELECT 
            p.product_id, 
            p.product_name, 
            p.description, 
            p.base_price,
            p.image_url,
            pc.category_name,
            p.is_vegetarian,
            p.is_vegan,
            p.is_gluten_free
        FROM products p
        JOIN product_categories pc ON p.category_id = pc.category_id
        WHERE p.is_active = 1 
        AND pc.category_name = 'Pizzas'
        ORDER BY p.product_name
        LIMIT 8
    ";
    
    $result = $conn->query($pizza_sql);
    while ($row = $result->fetch_assoc()) {
        $pizzas[] = $row;
    }
}

// Include header
$current_page = 'index.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo SITE_TAGLINE; ?></title>
    <meta name="description" content="<?php echo DEFAULT_META_DESCRIPTION; ?>">
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/index.css">
    
</head>
<body>
    <?php if (!$selected_location): ?>
    <!-- Location Selection Modal (shows if no location selected) -->
    <div class="location-modal active" id="locationModal">
        <div class="location-modal-content">
            <h2>🍕 Select Your Location</h2>
            <p>Choose your nearest Crust Pizza location to start ordering</p>
            
            <div class="location-grid">
                <?php foreach ($locations as $location): ?>
                <div class="location-card" data-location-id="<?php echo $location['location_id']; ?>">
                    <div class="location-name"><?php echo htmlspecialchars($location['store_name']); ?></div>
                    <div class="location-address">
                        <?php echo htmlspecialchars($location['address']); ?><br>
                        <?php echo htmlspecialchars($location['city']); ?>, <?php echo htmlspecialchars($location['state']); ?> <?php echo htmlspecialchars($location['postal_code']); ?>
                    </div>
                    <div class="location-phone">📞 <?php echo htmlspecialchars($location['phone']); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="location-actions">
                <button class="btn-select-location" id="confirmLocation" disabled>Select Location</button>
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- Location Banner (shows when location is selected) -->
    <div class="location-banner">
        📍 Ordering from: <strong><?php 
            foreach ($locations as $loc) {
                if ($loc['location_id'] == $selected_location) {
                    echo htmlspecialchars($loc['store_name'] . ', ' . $loc['city']);
                    break;
                }
            }
        ?></strong>
        <a href="#" id="changeLocation">Change Location</a>
    </div>
    <?php endif; ?>
    
    <?php if ($welcome): ?>
    <!-- Welcome Message for New Users -->
    <div class="welcome-message">
        🎉 Welcome to <?php echo SITE_NAME; ?>, <?php echo htmlspecialchars(getCurrentUserName()); ?>! Your account has been created successfully.
    </div>
    <?php endif; ?>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h1>Gourmet Pizza Delivered</h1>
            <p>Fresh ingredients, innovative flavors, and lightning-fast delivery to your door</p>
            <div class="hero-buttons">
                <?php if ($selected_location): ?>
                    <a href="menu.php" class="btn btn-primary">Order Now</a>
                    <a href="builder.php" class="btn btn-secondary">Build Your Own</a>
                <?php else: ?>
                    <button class="btn btn-primary" onclick="showLocationModal()">Select Location to Order</button>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="about">
        <div class="features-container">
            <h2 class="section-title">Why Choose <?php echo SITE_NAME; ?>?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🚀</div>
                    <h3 class="feature-title">Lightning Fast Delivery</h3>
                    <p class="feature-description">Fresh, hot pizza delivered to your door in <?php echo ESTIMATED_PREP_TIME + ESTIMATED_DELIVERY_TIME; ?> minutes or less</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🌱</div>
                    <h3 class="feature-title">Fresh Ingredients</h3>
                    <p class="feature-description">Premium ingredients sourced daily from local suppliers</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🍕</div>
                    <h3 class="feature-title">Gourmet Flavors</h3>
                    <p class="feature-description">Award-winning recipes including our famous Peri Peri Chicken</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3 class="feature-title">Easy Ordering</h3>
                    <p class="feature-description">Order online with real-time tracking and updates</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🥗</div>
                    <h3 class="feature-title">Dietary Options</h3>
                    <p class="feature-description">Gluten-free, vegan, and low-carb options available</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⭐</div>
                    <h3 class="feature-title">5-Star Quality</h3>
                    <p class="feature-description">Consistently rated #1 pizza delivery service since 2001</p>
                </div>
            </div>
        </div>
    </section>
    
    <?php if ($selected_location && !empty($pizzas)): ?>
    <!-- Popular Items Section -->
    <section class="popular-items" id="menu">
        <div class="popular-container">
            <h2 class="section-title">Popular Pizzas</h2>
            <div class="items-grid" id="popular-items-grid">
                <?php foreach ($pizzas as $pizza): ?>
                <div class="item-card pizza-card">
                    <img src="<?php echo htmlspecialchars($pizza['image_url'] ?: 'assets/images/default-pizza.jpg'); ?>" 
                         alt="<?php echo htmlspecialchars($pizza['product_name']); ?>" 
                         class="item-image pizza-image">
                    <div class="item-content">
                        <h5 class="item-title"><?php echo htmlspecialchars($pizza['product_name']); ?></h5>
                        <p class="item-description"><?php echo htmlspecialchars($pizza['description']); ?></p>
                        
                        <div class="dietary-badges">
                            <?php if ($pizza['is_vegetarian']): ?>
                                <span class="dietary-badge badge-vegetarian">Vegetarian</span>
                            <?php endif; ?>
                            <?php if ($pizza['is_vegan']): ?>
                                <span class="dietary-badge badge-vegan">Vegan</span>
                            <?php endif; ?>
                            <?php if ($pizza['is_gluten_free']): ?>
                                <span class="dietary-badge badge-gluten-free">Gluten Free</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="price-display">
                            From <?php echo CURRENCY_SYMBOL; ?><?php echo number_format($pizza['base_price'], 2); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div style="text-align: center; margin-top: 3rem;">
                <a href="menu.php" class="btn btn-primary">View Full Menu</a>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Business Hours Section -->
    <section class="business-hours" style="background: #f8f9fa; padding: 60px 0; text-align: center;">
        <div class="container">
            <h2 class="section-title">We're Open</h2>
            <p style="font-size: 1.5rem; color: #d63031; font-weight: 600;">
                <?php echo OPENING_HOUR; ?>:00 AM - <?php echo CLOSING_HOUR - 12; ?>:00 PM Daily
            </p>
            <p style="color: #636e72; margin-top: 10px;">
                Minimum order for delivery: <?php echo CURRENCY_SYMBOL . MIN_ORDER_AMOUNT; ?><br>
                Free delivery on orders over <?php echo CURRENCY_SYMBOL . FREE_DELIVERY_AMOUNT; ?>
            </p>
        </div>
    </section>

    <?php include 'templates/footer.php'; ?>

    <script>
    // Location selection functionality
    document.addEventListener('DOMContentLoaded', function() {
        let selectedLocationId = null;
        
        // Location card selection
        const locationCards = document.querySelectorAll('.location-card');
        const confirmBtn = document.getElementById('confirmLocation');
        
        locationCards.forEach(card => {
            card.addEventListener('click', function() {
                // Remove previous selection
                locationCards.forEach(c => c.classList.remove('selected'));
                
                // Add selection to clicked card
                this.classList.add('selected');
                selectedLocationId = this.dataset.locationId;
                
                // Enable confirm button
                if (confirmBtn) {
                    confirmBtn.disabled = false;
                }
            });
        });
        
        // Confirm location selection
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function() {
                if (selectedLocationId) {
                    // Set location in session via AJAX
                    fetch('api/set-location.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ location_id: selectedLocationId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Set cookie for 30 days
                            document.cookie = `<?php echo COOKIE_LOCATION; ?>=${selectedLocationId};path=/;max-age=${30*24*60*60}`;
                            // Reload page
                            window.location.reload();
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        // Fallback: reload with location in URL
                        window.location.href = '?location=' + selectedLocationId;
                    });
                }
            });
        }
        
        // Change location link
        const changeLocationLink = document.getElementById('changeLocation');
        if (changeLocationLink) {
            changeLocationLink.addEventListener('click', function(e) {
                e.preventDefault();
                // Clear session and cookie
                document.cookie = '<?php echo COOKIE_LOCATION; ?>=;path=/;max-age=0';
                
                fetch('api/clear-location.php', {
                    method: 'POST'
                })
                .then(() => {
                    window.location.reload();
                })
                .catch(() => {
                    window.location.reload();
                });
            });
        }
        
        // Auto-hide welcome message after 5 seconds
        const welcomeMsg = document.querySelector('.welcome-message');
        if (welcomeMsg) {
            setTimeout(() => {
                welcomeMsg.style.opacity = '0';
                setTimeout(() => welcomeMsg.remove(), 500);
            }, 5000);
        }
    });
    
    function showLocationModal() {
        const modal = document.getElementById('locationModal');
        if (modal) {
            modal.classList.add('active');
        }
    }


    </script>
</body>
</html>