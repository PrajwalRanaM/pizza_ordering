<?php
require_once 'includes/init.php';

$error = '';
$max_attempts = MAX_LOGIN_ATTEMPTS;
$lockout_time = LOGIN_LOCKOUT_TIME;

// Check if user is already logged in
if (isLoggedIn()) {
    $redirect_url = $_SESSION[SESSION_REDIRECT_URL] ?? 'index.php';
    unset($_SESSION[SESSION_REDIRECT_URL]);
    header("Location: $redirect_url");
    exit();
}

// Check login attempts
if (!isset($_SESSION[SESSION_LOGIN_ATTEMPTS])) {
    $_SESSION[SESSION_LOGIN_ATTEMPTS] = 0;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = ERR_CSRF_TOKEN;
    } else {
        // Check if locked out
        if ($_SESSION[SESSION_LOGIN_ATTEMPTS] >= $max_attempts) {
            $error = "Too many failed attempts. Please try again later.";
        } else {
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $user_type = $_POST['user_type'] ?? USER_TYPE_CUSTOMER;
            
            $user = null;
            $table = '';
            $id_field = '';
            
            // Check the appropriate table based on user type
            switch($user_type) {
                case USER_TYPE_CUSTOMER:
                    $table = 'customers';
                    $id_field = 'customer_id';
                    $stmt = $conn->prepare("SELECT customer_id as user_id, username, first_name, last_name, password FROM customers WHERE email = ? AND is_active = 1");
                    break;
                    
                case USER_TYPE_EMPLOYEE:
                    $table = 'employees';
                    $id_field = 'employee_id';
                    $stmt = $conn->prepare("SELECT e.employee_id as user_id, e.username, e.first_name, e.last_name, e.password, e.role_id, er.role_name 
                                           FROM employees e 
                                           JOIN employee_roles er ON e.role_id = er.role_id 
                                           WHERE e.email = ? AND e.is_active = 1");
                    break;
                    
                case USER_TYPE_ADMIN:
                    $table = 'admins';
                    $id_field = 'admin_id';
                    $stmt = $conn->prepare("SELECT admin_id as user_id, username, first_name, last_name, password FROM admins WHERE email = ? AND is_active = 1");
                    break;
                    
                default:
                    $error = "Invalid user type selected.";
            }
            
            if (!$error && $stmt) {
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 1) {
                    $user = $result->fetch_assoc();
                    
                    if (password_verify($password, $user['password'])) {
                        // Valid login - reset attempts
                        $_SESSION[SESSION_LOGIN_ATTEMPTS] = 0;
                        
                        // Create user session
                        createUserSession($user, $user_type);
                        
                        // Update last login for admins
                        if ($user_type === USER_TYPE_ADMIN) {
                            $update_stmt = $conn->prepare("UPDATE admins SET last_login = NOW() WHERE admin_id = ?");
                            $update_stmt->bind_param("i", $user['user_id']);
                            $update_stmt->execute();
                        }
                        
                        // Remember me functionality (if checkbox was checked)
                        if (isset($_POST['remember_me'])) {
                            $token = bin2hex(random_bytes(32));
                            setcookie(COOKIE_REMEMBER_ME, $token, time() + (86400 * 30), '/'); // 30 days
                            // Store token in database (you'd need to add a remember_tokens table)
                        }
                        
                        // Redirect based on user type
                        $redirect_url = $_SESSION[SESSION_REDIRECT_URL] ?? null;
                        unset($_SESSION[SESSION_REDIRECT_URL]);
                        
                        if ($redirect_url) {
                            header("Location: $redirect_url");
                        } else {
                            switch($user_type) {
                                case USER_TYPE_ADMIN:
                                    header("Location: admin/dashboard.php");
                                    break;
                                case USER_TYPE_EMPLOYEE:
                                    // Redirect based on role
                                    if ($user['role_name'] === 'Kitchen Staff') {
                                        header("Location: staff/kitchen/dashboard.php");
                                    } elseif ($user['role_name'] === 'Delivery Staff') {
                                        header("Location: staff/delivery/dashboard.php");
                                    } elseif ($user['role_name'] === 'Counter Staff') {
                                        header("Location: staff/counter/dashboard.php");
                                    }
                                    break;
                                default:
                                    header("Location: index.php");
                            }
                        }
                        exit();
                    } else {
                        $_SESSION[SESSION_LOGIN_ATTEMPTS]++;
                        $error = MSG_LOGIN_FAILED;
                    }
                } else {
                    $_SESSION[SESSION_LOGIN_ATTEMPTS]++;
                    $error = "Email not found in " . ucfirst($user_type) . " accounts.";
                }
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/form.css">
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body class="login-page">
    
    <div class="login-container">
        <h1 class="login-title">🍕 <?php echo SITE_NAME; ?> Login</h1>
        
        <!-- User Type Selector -->
        <div class="user-type-selector">
            <label class="user-type-btn active" data-type="<?php echo USER_TYPE_CUSTOMER; ?>">
                <input type="radio" name="user_type" value="<?php echo USER_TYPE_CUSTOMER; ?>" checked style="display: none;">
                Customer
            </label>
            <label class="user-type-btn" data-type="<?php echo USER_TYPE_EMPLOYEE; ?>">
                <input type="radio" name="user_type" value="<?php echo USER_TYPE_EMPLOYEE; ?>" style="display: none;">
                Staff
            </label>
            <label class="user-type-btn" data-type="<?php echo USER_TYPE_ADMIN; ?>">
                <input type="radio" name="user_type" value="<?php echo USER_TYPE_ADMIN; ?>" style="display: none;">
                Admin
            </label>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($_SESSION[SESSION_LOGIN_ATTEMPTS] >= $max_attempts): ?>
            <div class="lockout-message">
                Too many failed attempts. Please try again in <?php echo $lockout_time / 60; ?> minutes.
            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            <input type="hidden" name="user_type" id="user_type" value="<?php echo USER_TYPE_CUSTOMER; ?>">
            
            <div class="form-group">
                <label for="email" class="form-label">Email</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       class="form-input" 
                       required 
                       placeholder="Enter your email address"
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" 
                       id="password" 
                       name="password" 
                       class="form-input" 
                       required 
                       placeholder="Enter your password">
            </div>
            
            <div class="remember-me">
                <input type="checkbox" id="remember_me" name="remember_me" value="1">
                <label for="remember_me">Remember me for 30 days</label>
            </div>
            
            <button type="submit" class="login-btn" <?php echo $_SESSION[SESSION_LOGIN_ATTEMPTS] >= $max_attempts ? 'disabled' : ''; ?>>Login</button>
            
            
        </form>
        
        <div class="signup-section" id="customer-signup" style="display: block;">
            <p class="signup-text">Don't have an account?</p>
            <a href="signup.php" class="signup-btn">Sign Up</a>
        </div>
        
       
        
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // User type selector
        const userTypeBtns = document.querySelectorAll('.user-type-btn');
        const userTypeInput = document.getElementById('user_type');
        const customerSignup = document.getElementById('customer-signup');
        
        userTypeBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all
                userTypeBtns.forEach(b => b.classList.remove('active'));
                
                // Add active class to clicked
                this.classList.add('active');
                
                // Update hidden input
                const type = this.dataset.type;
                userTypeInput.value = type;
                
                // Show/hide signup section (only for customers)
                if (type === '<?php echo USER_TYPE_CUSTOMER; ?>') {
                    customerSignup.style.display = 'block';
                } else {
                    customerSignup.style.display = 'none';
                }
                
                // Update placeholder text
                const emailInput = document.getElementById('email');
                if (type === '<?php echo USER_TYPE_EMPLOYEE; ?>') {
                    emailInput.placeholder = 'Enter your staff email';
                } else if (type === '<?php echo USER_TYPE_ADMIN; ?>') {
                    emailInput.placeholder = 'Enter your admin email';
                } else {
                    emailInput.placeholder = 'Enter your email address';
                }
            });
        });
        
        // Add loading state to login button
        const loginForm = document.querySelector('form');
        const loginBtn = document.querySelector('.login-btn');
        
        if (loginForm && loginBtn) {
            loginForm.addEventListener('submit', function() {
                if (!loginBtn.disabled) {
                    loginBtn.textContent = 'Logging in...';
                    loginBtn.disabled = true;
                }
            });
        }
        
        // Auto-hide error messages after 5 seconds
        const errorMsg = document.querySelector('.error-message');
        if (errorMsg) {
            setTimeout(() => {
                errorMsg.style.opacity = '0';
                setTimeout(() => errorMsg.remove(), 300);
            }, 5000);
        }
    });
    
    
    
    </script>
</body>
</html>