<?php
require_once 'includes/init.php';

// Check if location is selected
$selected_location = getSelectedLocation();
if (!$selected_location) {
    setFlashMessage('Please select a location first to view our menu.', 'warning');
    redirect('index.php');
}

// Get location details
$location_stmt = $conn->prepare("SELECT store_name, city FROM locations WHERE location_id = ?");
$location_stmt->bind_param("i", $selected_location);
$location_stmt->execute();
$location = $location_stmt->get_result()->fetch_assoc();

// Fetch pizza categories
$category_sql = "SELECT category_id, category_name, description 
                FROM product_categories 
                WHERE is_active = 1 
                ORDER BY display_order";
$categories_result = $conn->query($category_sql);
$categories = [];
while ($row = $categories_result->fetch_assoc()) {
    $categories[$row['category_id']] = $row;
}

// Fetch all active pizzas with their base prices
$pizza_sql = "
    SELECT 
        p.product_id,
        p.product_name,
        p.description,
        p.category_id,
        p.base_price,
        p.image_url,
        p.is_vegetarian,
        p.is_vegan,
        p.is_gluten_free,
        p.is_active,
        pc.category_name
    FROM products p
    JOIN product_categories pc ON p.category_id = pc.category_id
    WHERE p.is_active = 1 
    AND pc.category_name = 'Pizzas'
    ORDER BY p.category_id, p.product_name
";

$result = $conn->query($pizza_sql);
$pizzas = [];
while ($row = $result->fetch_assoc()) {
    $pizzas[] = $row;
}

// Fetch crust sizes for pricing
$sizes_sql = "SELECT size_id, size_name, size_code, price_multiplier 
              FROM crust_sizes 
              WHERE is_active = 1 
              ORDER BY size_id";
$sizes_result = $conn->query($sizes_sql);
$sizes = [];
while ($row = $sizes_result->fetch_assoc()) {
    $sizes[] = $row;
}

// Include header
$current_page = 'menu.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/menu.css">
    
</head>
<body>
    <?php if (!isStoreOpen()): ?>
    <div class="store-closed-banner">
        🕐 Sorry, we're currently closed. We're open from <?php echo OPENING_HOUR; ?>:00 AM to <?php echo CLOSING_HOUR - 12; ?>:00 PM daily.
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success"><?php echo e($message); ?></div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('warning')): ?>
    <div class="flash-message flash-warning"><?php echo e($message); ?></div>
    <?php endif; ?>

    <!-- Menu Header -->
    <section class="menu-header">
        <h1>🍕 Our Delicious Menu</h1>
        <p>Handcrafted pizzas made with premium ingredients and lots of love</p>
        <div class="location-info">
            📍 Ordering from: <?php echo e($location['store_name']); ?>, <?php echo e($location['city']); ?>
        </div>
    </section>

    <!-- Filter and Search Controls -->
    <section class="menu-filters">
        <div class="filter-container">
            <div class="filter-tabs">
                <button class="filter-tab active" data-filter="all">All Pizzas</button>
                <button class="filter-tab" data-filter="vegetarian">🥗 Vegetarian</button>
                <button class="filter-tab" data-filter="vegan">🌱 Vegan</button>
                <button class="filter-tab" data-filter="gluten-free">🌾 Gluten Free</button>
            </div>
            
            <div class="menu-controls">
                <input type="text" class="search-box" placeholder="🔍 Search pizzas..." id="pizza-search">
                <select class="sort-select" id="sort-options">
                    <option value="name">Sort by Name</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                </select>
            </div>
        </div>
    </section>

    <!-- Menu Section -->
    <section class="menu-section">
        <div class="menu-grid" id="menu-grid">
            <?php foreach ($pizzas as $pizza): ?>
            <div class="menu-card" 
                 data-name="<?php echo e(strtolower($pizza['product_name'])); ?>"
                 data-price="<?php echo $pizza['base_price']; ?>"
                 data-vegetarian="<?php echo $pizza['is_vegetarian'] ? 'true' : 'false'; ?>"
                 data-vegan="<?php echo $pizza['is_vegan'] ? 'true' : 'false'; ?>"
                 data-gluten-free="<?php echo $pizza['is_gluten_free'] ? 'true' : 'false'; ?>">
                
                <img src="<?php echo e($pizza['image_url'] ?: ASSETS_PATH . 'images/default-pizza.jpg'); ?>" 
                     alt="<?php echo e($pizza['product_name']); ?>" 
                     class="pizza-image">
                
                <div class="menu-content">
                    <h5 class="menu-title"><?php echo e($pizza['product_name']); ?></h5>
                    
                    <div class="dietary-badges">
                        <?php if ($pizza['is_vegetarian']): ?>
                        <span class="dietary-badge badge-vegetarian">Vegetarian</span>
                        <?php endif; ?>
                        <?php if ($pizza['is_vegan']): ?>
                        <span class="dietary-badge badge-vegan">Vegan</span>
                        <?php endif; ?>
                        <?php if ($pizza['is_gluten_free']): ?>
                        <span class="dietary-badge badge-gluten-free">Gluten Free</span>
                        <?php endif; ?>
                    </div>
                    
                    <p class="menu-description"><?php echo e($pizza['description']); ?></p>
                    
                    <div class="size-selector">
                        <label><strong>Choose Size:</strong></label>
                        <div class="size-options">
                            <?php foreach ($sizes as $index => $size): ?>
                            <?php $price = $pizza['base_price'] * $size['price_multiplier']; ?>
                            <div class="size-option <?php echo $index === 1 ? 'selected' : ''; ?>" 
                                 data-size-id="<?php echo $size['size_id']; ?>"
                                 data-price="<?php echo $price; ?>">
                                <span class="size-name"><?php echo e($size['size_name']); ?></span>
                                <span class="size-price"><?php echo formatPrice($price); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <?php if (isLoggedIn() && isStoreOpen()): ?>
                    <div class="order-controls">
                        <div class="quantity-control">
                            <button class="qty-btn" onclick="changeQuantity(this, -1)">-</button>
                            <input type="number" class="qty-input" value="1" min="1" max="20">
                            <button class="qty-btn" onclick="changeQuantity(this, 1)">+</button>
                        </div>
                        <button class="add-to-cart-btn" 
                                onclick="addToCart(this)" 
                                data-product-id="<?php echo $pizza['product_id']; ?>"
                                data-product-name="<?php echo e($pizza['product_name']); ?>">
                            Add to Cart
                        </button>
                    </div>
                    <?php elseif (!isLoggedIn()): ?>
                    <div class="login-prompt">
                        <p>Please log in to place an order</p>
                        <a href="login.php" class="login-btn">Login to Order</a>
                    </div>
                    <?php elseif (!isStoreOpen()): ?>
                    <div class="login-prompt">
                        <p>Orders can only be placed during business hours</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Build Your Own CTA -->
    <section class="build-cta">
        <h2>🎨 Create Your Masterpiece</h2>
        <p>Not finding exactly what you want? Build your perfect pizza from scratch!</p>
        <a href="builder.php" class="btn-build">🍕 Build Your Own Pizza</a>
    </section>

    <?php include 'templates/footer.php'; ?>

    <script>
    // Menu functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Filter functionality
        const filterBtns = document.querySelectorAll('.filter-tab');
        const menuCards = document.querySelectorAll('.menu-card');
        
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Update active button
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                const filter = this.dataset.filter;
                
                // Filter cards
                menuCards.forEach(card => {
                    if (filter === 'all') {
                        card.style.display = 'block';
                    } else {
                        const matchesFilter = card.dataset[filter] === 'true';
                        card.style.display = matchesFilter ? 'block' : 'none';
                    }
                });
            });
        });
        
        // Search functionality
        const searchBox = document.getElementById('pizza-search');
        if (searchBox) {
            searchBox.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                menuCards.forEach(card => {
                    const name = card.dataset.name;
                    const matches = name.includes(searchTerm);
                    card.style.display = matches ? 'block' : 'none';
                });
            });
        }
        
        // Sort functionality
        const sortSelect = document.getElementById('sort-options');
        if (sortSelect) {
            sortSelect.addEventListener('change', function() {
                const sortBy = this.value;
                const cardsArray = Array.from(menuCards);
                const menuGrid = document.getElementById('menu-grid');
                
                cardsArray.sort((a, b) => {
                    switch(sortBy) {
                        case 'name':
                            return a.dataset.name.localeCompare(b.dataset.name);
                        case 'price-low':
                            return parseFloat(a.dataset.price) - parseFloat(b.dataset.price);
                        case 'price-high':
                            return parseFloat(b.dataset.price) - parseFloat(a.dataset.price);
                        default:
                            return 0;
                    }
                });
                
                // Re-append cards in sorted order
                cardsArray.forEach(card => menuGrid.appendChild(card));
            });
        }
        
        // Size selection
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('size-option') || e.target.parentElement.classList.contains('size-option')) {
                const sizeOption = e.target.classList.contains('size-option') ? e.target : e.target.parentElement;
                const card = sizeOption.closest('.menu-card');
                
                // Update selection
                card.querySelectorAll('.size-option').forEach(opt => opt.classList.remove('selected'));
                sizeOption.classList.add('selected');
                
                // Update button price
                updateCartButtonPrice(card);
            }
        });
    });
    
    // Global functions
    function changeQuantity(button, change) {
        const input = button.parentElement.querySelector('.qty-input');
        const currentValue = parseInt(input.value) || 1;
        const newValue = Math.max(1, Math.min(20, currentValue + change));
        input.value = newValue;
        
        updateCartButtonPrice(button.closest('.menu-card'));
    }
    
    function updateCartButtonPrice(card) {
        const selectedSize = card.querySelector('.size-option.selected');
        const quantity = parseInt(card.querySelector('.qty-input').value) || 1;
        const button = card.querySelector('.add-to-cart-btn');
        
        if (selectedSize && button) {
            const price = parseFloat(selectedSize.dataset.price);
            const total = price * quantity;
            button.textContent = `Add to Cart - ${formatPrice(total)}`;
        }
    }
    
    function formatPrice(price) {
        return '<?php echo CURRENCY_SYMBOL; ?>' + price.toFixed(2);
    }
    
    function addToCart(button) {
        const card = button.closest('.menu-card');
        const selectedSize = card.querySelector('.size-option.selected');
        const quantity = parseInt(card.querySelector('.qty-input').value) || 1;
        
        if (!selectedSize) {
            alert('Please select a size');
            return;
        }
        
        const productId = button.dataset.productId;
        const productName = button.dataset.productName;
        const sizeId = selectedSize.dataset.sizeId;
        const sizeName = selectedSize.querySelector('.size-name').textContent;
        
        // Show loading state
        button.disabled = true;
        button.textContent = 'Adding...';
        
        // Make AJAX request
        fetch('api/add-to-cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                size_id: sizeId,
                quantity: quantity,
                type: 'preset'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                showNotification(`Added ${quantity}x ${productName} (${sizeName}) to cart!`);
                
                // Update cart count in header
                updateCartCount(data.cart_count);
                
                // Reset button
                setTimeout(() => {
                    button.disabled = false;
                    updateCartButtonPrice(card);
                }, 1000);
            } else {
                alert(data.message || 'Failed to add to cart');
                button.disabled = false;
                updateCartButtonPrice(card);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to add to cart. Please try again.');
            button.disabled = false;
            updateCartButtonPrice(card);
        });
    }
    
    function showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: #00b894;
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    function updateCartCount(count) {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = count;
            cartBadge.style.display = count > 0 ? 'inline-block' : 'none';
        }
    }
    </script>
    
    <style>
    /* Notification animations */
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    </style>
</body>
</html>