<?php
// public/order-confirmation.php - Order Confirmation Page
require_once 'includes/init.php';

// Check if user is logged in
if (!isLoggedIn() || !isCustomer()) {
    setFlashMessage('Please login to view order details.', 'info');
    redirect('login.php');
}

// Get order number from URL
$order_number = $_GET['order'] ?? '';
if (empty($order_number)) {
    setFlashMessage('Order not found.', 'error');
    redirect('index.php');
}

// Fetch order details
$customer_id = getCurrentUserId();
$stmt = $conn->prepare("
    SELECT o.*, l.store_name, l.address as store_address, l.city as store_city, 
           l.phone as store_phone, os.status_name
    FROM orders o
    JOIN locations l ON o.location_id = l.location_id
    JOIN order_statuses os ON o.order_status_id = os.status_id
    WHERE o.order_number = ? AND o.customer_id = ?
");
$stmt->bind_param("si", $order_number, $customer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    setFlashMessage('Order not found or you do not have permission to view it.', 'error');
    redirect('index.php');
}

$order = $result->fetch_assoc();

// Fetch order items
$items_stmt = $conn->prepare("
    SELECT oi.*, p.image_url
    FROM order_items oi
    LEFT JOIN products p ON oi.product_id = p.product_id
    WHERE oi.order_id = ?
    ORDER BY oi.order_item_id
");
$items_stmt->bind_param("i", $order['order_id']);
$items_stmt->execute();
$order_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch custom pizza details for custom items
foreach ($order_items as &$item) {
    if ($item['item_type'] === 'custom') {
        $custom_stmt = $conn->prepare("
            SELECT cp.*, cs.size_name, ct.crust_name, s.sauce_name, ch.cheese_name
            FROM custom_pizzas cp
            JOIN crust_sizes cs ON cp.size_id = cs.size_id
            JOIN crust_types ct ON cp.crust_type_id = ct.crust_type_id
            LEFT JOIN sauces s ON cp.sauce_id = s.sauce_id
            LEFT JOIN cheese_types ch ON cp.cheese_id = ch.cheese_id
            WHERE cp.order_item_id = ?
        ");
        $custom_stmt->bind_param("i", $item['order_item_id']);
        $custom_stmt->execute();
        $custom_details = $custom_stmt->get_result()->fetch_assoc();
        
        if ($custom_details) {
            $item['custom_details'] = $custom_details;
            
            // Get toppings
            $toppings_stmt = $conn->prepare("
                SELECT i.ingredient_name
                FROM custom_pizza_toppings cpt
                JOIN ingredients i ON cpt.ingredient_id = i.ingredient_id
                WHERE cpt.custom_pizza_id = ?
            ");
            $toppings_stmt->bind_param("i", $custom_details['custom_pizza_id']);
            $toppings_stmt->execute();
            $toppings_result = $toppings_stmt->get_result();
            
            $toppings = [];
            while ($topping = $toppings_result->fetch_assoc()) {
                $toppings[] = $topping['ingredient_name'];
            }
            $item['custom_details']['toppings'] = $toppings;
        }
    }
}

// Calculate estimated delivery/pickup time
$estimated_time = new DateTime($order['estimated_time']);
$current_time = new DateTime();
$time_diff = $estimated_time->diff($current_time);

$is_future = $estimated_time > $current_time;
$time_display = $estimated_time->format('g:i A');

// Include header
$current_page = 'order-confirmation.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/confirmation.css">
    
</head>
<body>
    <div class="confirmation-container">
        <!-- Success Banner -->
        <div class="success-banner fade-in">
            <div class="success-icon">✅</div>
            <h1>Order Confirmed!</h1>
            <p>Thank you for your order. We're preparing your delicious pizza!</p>
            <div class="order-number">
                Order #<?php echo htmlspecialchars($order['order_number']); ?>
            </div>
        </div>

        <div class="content-grid">
            <!-- Main Content -->
            <div class="main-content">
                <!-- Order Status -->
                <div class="info-card slide-up">
                    <div class="card-header">
                        📋 Order Status
                    </div>
                    <div class="card-content">
                        <div class="status-display">
                            <div class="status-icon">⏱️</div>
                            <div class="status-text"><?php echo htmlspecialchars($order['status_name']); ?></div>
                            <div class="status-time">
                                Estimated <?php echo ucfirst($order['order_type']); ?> Time: 
                                <strong><?php echo $time_display; ?></strong>
                                <?php if ($is_future): ?>
                                    (in <?php echo $time_diff->i; ?> minutes)
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="order-details">
                            <div class="detail-item">
                                <div class="detail-label">Order Type</div>
                                <div class="detail-value">
                                    <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                </div>
                            </div>
                            
                            <div class="detail-item">
                                <div class="detail-label">Payment</div>
                                <div class="detail-value">
                                    <?php 
                                    $payment_methods = [
                                        'credit_card' => '💳 Credit Card',
                                        'debit_card' => '💳 Debit Card',
                                        'internet_banking' => '🏦 Internet Banking',
                                        'cash_on_delivery' => '💵 Cash on Delivery'
                                    ];
                                    echo $payment_methods[$order['payment_method']] ?? ucfirst(str_replace('_', ' ', $order['payment_method']));
                                    ?>
                                </div>
                            </div>
                            
                            <div class="detail-item">
                                <div class="detail-label">Payment Status</div>
                                <div class="detail-value" style="color: <?php echo $order['payment_status'] === 'completed' ? 'var(--success-color)' : 'var(--warning-color)'; ?>">
                                    <?php echo ucfirst($order['payment_status']); ?>
                                </div>
                            </div>
                        </div>

                        <?php if ($order['order_type'] === 'delivery'): ?>
                        <div class="address-info">
                            <h4>📍 Delivery Address</h4>
                            <p>
                                <?php echo htmlspecialchars($order['delivery_address']); ?><br>
                                <?php echo htmlspecialchars($order['delivery_city'] . ', ' . $order['delivery_state'] . ' ' . $order['delivery_postal_code']); ?>
                            </p>
                        </div>
                        <?php else: ?>
                        <div class="address-info">
                            <h4>🏪 Pickup Location</h4>
                            <p>
                                <strong><?php echo htmlspecialchars($order['store_name']); ?></strong><br>
                                <?php echo htmlspecialchars($order['store_address']); ?><br>
                                <?php echo htmlspecialchars($order['store_city']); ?><br>
                                📞 <?php echo htmlspecialchars($order['store_phone']); ?>
                            </p>
                        </div>
                        <?php endif; ?>

                        <div class="progress-tracker">
                            <div class="progress-steps">
                                <div class="progress-line">
                                    <div class="progress-fill" id="progressFill"></div>
                                </div>
                                
                                <div class="progress-step">
                                    <div class="step-circle completed">✓</div>
                                    <div class="step-label">Order Placed</div>
                                    <div class="step-time"><?php echo date('g:i A', strtotime($order['created_at'])); ?></div>
                                </div>
                                
                                <div class="progress-step">
                                    <div class="step-circle active" id="preparingStep">⏱️</div>
                                    <div class="step-label">Preparing</div>
                                    <div class="step-time">~<?php echo ESTIMATED_PREP_TIME; ?> min</div>
                                </div>
                                
                                <?php if ($order['order_type'] === 'delivery'): ?>
                                <div class="progress-step">
                                    <div class="step-circle" id="deliveryStep">🚚</div>
                                    <div class="step-label">Out for Delivery</div>
                                    <div class="step-time">~<?php echo ESTIMATED_DELIVERY_TIME; ?> min</div>
                                </div>
                                
                                <div class="progress-step">
                                    <div class="step-circle" id="completedStep">🎉</div>
                                    <div class="step-label">Delivered</div>
                                    <div class="step-time"><?php echo $time_display; ?></div>
                                </div>
                                <?php else: ?>
                                <div class="progress-step">
                                    <div class="step-circle" id="readyStep">✅</div>
                                    <div class="step-label">Ready for Pickup</div>
                                    <div class="step-time"><?php echo $time_display; ?></div>
                                </div>
                                
                                <div class="progress-step">
                                    <div class="step-circle" id="completedStep">🎉</div>
                                    <div class="step-label">Picked Up</div>
                                    <div class="step-time">When collected</div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="next-steps">
                            <h4>What happens next?</h4>
                            <ul>
                                <?php if ($order['order_type'] === 'delivery'): ?>
                                <li>We'll start preparing your order immediately</li>
                                <li>You'll receive SMS updates on your order status</li>
                                <li>Our driver will contact you when they're nearby</li>
                                <li>Have your payment ready if paying cash on delivery</li>
                                <?php else: ?>
                                <li>We'll start preparing your order immediately</li>
                                <li>You'll receive an SMS when your order is ready</li>
                                <li>Bring this confirmation or your order number</li>
                                <li>Check in at the counter when you arrive</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="info-card slide-up">
                    <div class="card-header">
                        🍕 Your Order (<?php echo count($order_items); ?> item<?php echo count($order_items) !== 1 ? 's' : ''; ?>)
                    </div>
                    <div class="card-content">
                        <div class="order-items">
                            <?php foreach ($order_items as $item): ?>
                            <div class="order-item">
                                <div class="item-image">
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        🎨
                                    <?php else: ?>
                                        🍕
                                    <?php endif; ?>
                                </div>
                                
                                <div class="item-details">
                                    <div class="item-name"><?php echo htmlspecialchars($item['item_name']); ?></div>
                                    
                                    <?php if ($item['item_type'] === 'custom' && isset($item['custom_details'])): ?>
                                    <div class="item-customizations">
                                        <strong>Size:</strong> <?php echo htmlspecialchars($item['custom_details']['size_name']); ?><br>
                                        <strong>Crust:</strong> <?php echo htmlspecialchars($item['custom_details']['crust_name']); ?><br>
                                        <?php if ($item['custom_details']['sauce_name']): ?>
                                        <strong>Sauce:</strong> <?php echo htmlspecialchars($item['custom_details']['sauce_name']); ?><br>
                                        <?php endif; ?>
                                        <?php if ($item['custom_details']['cheese_amount'] !== 'none'): ?>
                                        <strong>Cheese:</strong> 
                                        <?php echo htmlspecialchars($item['custom_details']['cheese_name'] ?? 'Regular'); ?>
                                        <?php if ($item['custom_details']['cheese_amount'] === 'extra'): ?> (Extra)<?php endif; ?><br>
                                        <?php endif; ?>
                                        <?php if (!empty($item['custom_details']['toppings'])): ?>
                                        <strong>Toppings:</strong> <?php echo htmlspecialchars(implode(', ', $item['custom_details']['toppings'])); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="item-quantity">
                                        Quantity: <?php echo $item['quantity']; ?> × <?php echo formatPrice($item['unit_price']); ?>
                                    </div>
                                </div>
                                
                                <div class="item-price">
                                    <?php echo formatPrice($item['total_price']); ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if (!empty($order['special_instructions'])): ?>
                        <div style="background: var(--gray-light); padding: 15px; border-radius: 8px; margin-top: 20px;">
                            <h4 style="color: var(--primary-color); margin-bottom: 5px;">📝 Special Instructions</h4>
                            <p><?php echo htmlspecialchars($order['special_instructions']); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Order Summary Sidebar -->
            <div class="order-summary slide-up">
                <div class="summary-header">
                    <h3>Order Summary</h3>
                    <p style="color: var(--gray-dark); font-size: 0.9rem;">
                        Order #<?php echo htmlspecialchars($order['order_number']); ?>
                    </p>
                </div>

                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span><?php echo formatPrice($order['subtotal']); ?></span>
                </div>
                
                <?php if ($order['delivery_fee'] > 0): ?>
                <div class="summary-row">
                    <span>Delivery Fee:</span>
                    <span><?php echo formatPrice($order['delivery_fee']); ?></span>
                </div>
                <?php endif; ?>
                
                <div class="summary-row">
                    <span>Tax (GST):</span>
                    <span><?php echo formatPrice($order['tax_amount']); ?></span>
                </div>
                
                <div class="summary-row total">
                    <span>Total:</span>
                    <span><?php echo formatPrice($order['total_amount']); ?></span>
                </div>

                <div class="action-buttons">
                    <a href="order-tracking.php?order=<?php echo urlencode($order['order_number']); ?>" class="btn btn-primary">
                        📱 Track Your Order
                    </a>
                    
                    <a href="menu.php" class="btn btn-secondary">
                        🍕 Order Again
                    </a>
                    
                    <button onclick="window.print()" class="btn btn-secondary">
                        🖨️ Print Receipt
                    </button>
                </div>

                <div style="background: var(--gray-light); padding: 15px; border-radius: 8px; margin-top: 20px; text-align: center;">
                    <p style="font-size: 0.85rem; color: var(--gray-dark); margin-bottom: 10px;">
                        Need help? Contact us:
                    </p>
                    <p style="font-weight: 600;">
                        📞 <?php echo htmlspecialchars($order['store_phone']); ?><br>
                        📧 <?php echo SUPPORT_EMAIL; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php include 'templates/footer.php'; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Animate progress bar
        setTimeout(() => {
            const progressFill = document.getElementById('progressFill');
            if (progressFill) {
                progressFill.style.width = '25%'; // Adjust based on order status
            }
        }, 500);

        // Auto-refresh page every 30 seconds to check for status updates
        setInterval(() => {
            // In a real implementation, you might make an AJAX call to check status
            // For now, we'll just reload the page
            if (document.hidden === false) { // Only refresh if page is visible
                location.reload();
            }
        }, 30000); // 30 seconds

        // Add animation delays to cards
        const cards = document.querySelectorAll('.slide-up');
        cards.forEach((card, index) => {
            card.style.animationDelay = (index * 0.2) + 's';
        });

        // Show notification about order confirmation
        showNotification('Order confirmation email sent to <?php echo htmlspecialchars($customer["email"]); ?>', 'success');
    });

    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            max-width: 350px;
        `;
        
        switch(type) {
            case 'success':
                notification.style.background = '#00b894';
                break;
            case 'error':
                notification.style.background = '#d63031';
                break;
            case 'warning':
                notification.style.background = '#fdcb6e';
                notification.style.color = '#2d3436';
                break;
            default:
                notification.style.background = '#74b9ff';
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Celebration animation on page load
    function celebrate() {
        const successIcon = document.querySelector('.success-icon');
        if (successIcon) {
            successIcon.style.animation = 'none';
            setTimeout(() => {
                successIcon.style.animation = 'bounce 1s ease infinite alternate';
            }, 10);
        }
    }

    // Trigger celebration
    setTimeout(celebrate, 1000);

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 't' || e.key === 'T') {
            // Press 'T' to track order
            const trackLink = document.querySelector('a[href*="order-tracking"]');
            if (trackLink) {
                window.location.href = trackLink.href;
            }
        }
        
        if (e.key === 'm' || e.key === 'M') {
            // Press 'M' to go to menu
            window.location.href = 'menu.php';
        }
        
        if (e.ctrlKey && e.key === 'p') {
            // Ctrl+P to print
            e.preventDefault();
            window.print();
        }
    });

    // Check if user navigated back to this page
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            // Page was restored from cache, refresh it
            location.reload();
        }
    });
    </script>

    
</body>
</html>