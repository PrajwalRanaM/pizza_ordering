<?php
// public/order-tracking.php - Order Tracking Page with Real Data
require_once 'includes/init.php';

// Initialize variables
$order = null;
$order_items = [];
$status_history = [];
$error = '';
$show_order = false;

// Check if order lookup is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['order'])) {
    $order_number = '';
    $phone_last_four = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $order_number = sanitizeInput($_POST['order_number'] ?? '');
        $phone_last_four = sanitizeInput($_POST['phone'] ?? '');
    } else {
        // Coming from order confirmation page
        $order_number = sanitizeInput($_GET['order'] ?? '');
        $phone_last_four = ''; // Skip phone verification for logged-in users from confirmation
    }
    
    // Validate input
    if (empty($order_number)) {
        $error = 'Please enter your order number.';
    } elseif (!preg_match('/^CP[0-9]{8,}$/', $order_number)) {
        $error = 'Please enter a valid order number (format: CP20250609001).';
    } else {
        try {
            // Base query to fetch order details
            $sql = "
                SELECT 
                    o.*,
                    c.first_name,
                    c.last_name,
                    c.phone,
                    l.store_name,
                    l.address as store_address,
                    l.city as store_city,
                    l.phone as store_phone,
                    os.status_name,
                    os.display_order
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                JOIN locations l ON o.location_id = l.location_id
                JOIN order_statuses os ON o.order_status_id = os.status_id
                WHERE o.order_number = ?
            ";
            
            $params = [$order_number];
            $types = 's';
            
            // Add phone verification if not coming from logged-in session
            if (!empty($phone_last_four) || !isLoggedIn()) {
                if (empty($phone_last_four)) {
                    $error = 'Please enter the last 4 digits of your phone number.';
                } elseif (!preg_match('/^[0-9]{4}$/', $phone_last_four)) {
                    $error = 'Please enter exactly 4 digits.';
                } else {
                    $sql .= " AND RIGHT(REPLACE(c.phone, ' ', ''), 4) = ?";
                    $params[] = $phone_last_four;
                    $types .= 's';
                }
            } elseif (isLoggedIn()) {
                // If user is logged in, verify they own this order
                $sql .= " AND o.customer_id = ?";
                $params[] = getCurrentUserId();
                $types .= 'i';
            }
            
            if (empty($error)) {
                $stmt = $conn->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 1) {
                    $order = $result->fetch_assoc();
                    $show_order = true;
                    
                    // Fetch order items
                    $items_stmt = $conn->prepare("
                        SELECT oi.*, p.image_url
                        FROM order_items oi
                        LEFT JOIN products p ON oi.product_id = p.product_id
                        WHERE oi.order_id = ?
                        ORDER BY oi.order_item_id
                    ");
                    $items_stmt->bind_param("i", $order['order_id']);
                    $items_stmt->execute();
                    $order_items = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    
                    // Fetch status history
                    $history_stmt = $conn->prepare("
                        SELECT 
                            osh.*,
                            os.status_name,
                            CASE 
                                WHEN osh.changed_by_type = 'employee' THEN 
                                    CONCAT(e.first_name, ' ', e.last_name)
                                WHEN osh.changed_by_type = 'customer' THEN 
                                    CONCAT(c.first_name, ' ', c.last_name)
                                ELSE 'System'
                            END as changed_by_name
                        FROM order_status_history osh
                        JOIN order_statuses os ON osh.status_id = os.status_id
                        LEFT JOIN employees e ON osh.changed_by_id = e.employee_id 
                            AND osh.changed_by_type = 'employee'
                        LEFT JOIN customers c ON osh.changed_by_id = c.customer_id 
                            AND osh.changed_by_type = 'customer'
                        WHERE osh.order_id = ?
                        ORDER BY osh.created_at ASC
                    ");
                    $history_stmt->bind_param("i", $order['order_id']);
                    $history_stmt->execute();
                    $status_history = $history_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    
                } else {
                    $error = 'Order not found. Please check your order number and phone number.';
                }
            }
            
        } catch (Exception $e) {
            logError('Order tracking error: ' . $e->getMessage());
            $error = 'An error occurred while looking up your order. Please try again.';
        }
    }
}

// Helper function to get status info
function getStatusInfo($status_id, $order_type) {
    $statuses = [
        ORDER_STATUS_PENDING => [
            'icon' => '📝',
            'title' => 'Order Received',
            'description' => 'Your order has been confirmed and is waiting to be prepared',
            'color' => '#74b9ff'
        ],
        ORDER_STATUS_PREPARING => [
            'icon' => '👨‍🍳',
            'title' => 'Preparing',
            'description' => 'Our chefs are hand-crafting your delicious pizza',
            'color' => '#fdcb6e'
        ],
        ORDER_STATUS_READY => [
            'icon' => '✅',
            'title' => $order_type === 'delivery' ? 'Ready for Delivery' : 'Ready for Pickup',
            'description' => $order_type === 'delivery' ? 'Your order is ready and will be out for delivery soon' : 'Your order is ready for collection',
            'color' => '#00b894'
        ],
        ORDER_STATUS_OUT_FOR_DELIVERY => [
            'icon' => '🚚',
            'title' => 'Out for Delivery',
            'description' => 'Your order is on its way to you',
            'color' => '#0984e3'
        ],
        ORDER_STATUS_DELIVERED => [
            'icon' => '🎉',
            'title' => 'Delivered',
            'description' => 'Your order has been delivered. Enjoy!',
            'color' => '#00b894'
        ],
        ORDER_STATUS_PICKED_UP => [
            'icon' => '🎉',
            'title' => 'Picked Up',
            'description' => 'Your order has been collected. Enjoy!',
            'color' => '#00b894'
        ],
        ORDER_STATUS_CANCELLED => [
            'icon' => '❌',
            'title' => 'Cancelled',
            'description' => 'This order has been cancelled',
            'color' => '#d63031'
        ],
        ORDER_STATUS_FAILED => [
            'icon' => '⚠️',
            'title' => 'Delivery Failed',
            'description' => 'We were unable to deliver your order',
            'color' => '#d63031'
        ]
    ];
    
    return $statuses[$status_id] ?? $statuses[ORDER_STATUS_PENDING];
}

// Calculate progress percentage
function getProgressPercentage($current_status, $order_type) {
    if ($order_type === 'delivery') {
        $steps = [
            ORDER_STATUS_PENDING => 0,
            ORDER_STATUS_PREPARING => 25,
            ORDER_STATUS_READY => 50,
            ORDER_STATUS_OUT_FOR_DELIVERY => 75,
            ORDER_STATUS_DELIVERED => 100
        ];
    } else {
        $steps = [
            ORDER_STATUS_PENDING => 0,
            ORDER_STATUS_PREPARING => 33,
            ORDER_STATUS_READY => 66,
            ORDER_STATUS_PICKED_UP => 100
        ];
    }
    
    return $steps[$current_status] ?? 0;
}

// Include header
$current_page = 'order-tracking.php';
include 'templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Your Order - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/main.css">
    <link rel="stylesheet" href="assets/css/tracking.css">
    
</head>
<body>
    <div class="tracking-container">
        <!-- Header -->
        <div class="tracking-header">
            <h1>🚚 Track Your Order</h1>
            <p>Get real-time updates on your delicious pizza delivery</p>
        </div>

        <?php if (!$show_order): ?>
        <!-- Order Lookup Form -->
        <div class="order-lookup">
            <form class="lookup-form" method="POST">
                <div class="form-group">
                    <label for="order_number" class="form-label">Order Number</label>
                    <input type="text" 
                           id="order_number" 
                           name="order_number" 
                           class="form-input" 
                           placeholder="CP20250609001"
                           value="<?php echo isset($_POST['order_number']) ? htmlspecialchars($_POST['order_number']) : ''; ?>"
                           required>
                </div>
                
                <div class="form-group">
                    <label for="phone" class="form-label">Last 4 digits of phone</label>
                    <input type="text" 
                           id="phone" 
                           name="phone" 
                           class="form-input" 
                           placeholder="1234"
                           pattern="[0-9]{4}"
                           maxlength="4"
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>"
                           required>
                </div>
                
                <button type="submit" class="btn-track">
                    🔍 Track Order
                </button>
            </form>
        </div>

        <?php if (!empty($error)): ?>
        <div class="error-message">
            <h3>❌ <?php echo $error === 'Order not found. Please check your order number and phone number.' ? 'Order Not Found' : 'Error'; ?></h3>
            <p><?php echo htmlspecialchars($error); ?></p>
            <?php if (strpos($error, 'Order not found') !== false): ?>
            <p style="margin-top: 10px; font-size: 0.9rem;">
                <strong>Tips:</strong><br>
                • Make sure you entered the complete order number (starts with CP)<br>
                • Use the last 4 digits of the phone number used for the order<br>
                • Check your order confirmation email for the correct details
            </p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php else: ?>
        
        <!-- Auto-refresh notice -->
        <div class="refresh-notice">
            🔄 This page automatically refreshes every 30 seconds to show the latest updates
        </div>

        <!-- Order Status Card -->
        <div class="order-status-card">
            <?php 
            $status_info = getStatusInfo($order['order_status_id'], $order['order_type']);
            $progress_percentage = getProgressPercentage($order['order_status_id'], $order['order_type']);
            ?>
            
            <div class="status-header" style="background: <?php echo $status_info['color']; ?>;">
                <div class="status-icon"><?php echo $status_info['icon']; ?></div>
                <div class="status-text"><?php echo $status_info['title']; ?></div>
                <div class="status-subtitle"><?php echo $status_info['description']; ?></div>
            </div>

            <div class="order-info">
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Order Number</div>
                        <div class="info-value"><?php echo htmlspecialchars($order['order_number']); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Order Type</div>
                        <div class="info-value">
                            <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Estimated Time</div>
                        <div class="info-value">
                            <?php 
                            if ($order['estimated_time']) {
                                echo date('g:i A', strtotime($order['estimated_time']));
                            } else {
                                echo 'TBD';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Total Amount</div>
                        <div class="info-value"><?php echo formatPrice($order['total_amount']); ?></div>
                    </div>
                </div>

                <!-- Location Information -->
                <?php if ($order['order_type'] === 'delivery'): ?>
                <div class="location-info">
                    <h4>📍 Delivery Address</h4>
                    <div class="location-details">
                        <?php echo htmlspecialchars($order['delivery_address']); ?><br>
                        <?php echo htmlspecialchars($order['delivery_city'] . ', ' . $order['delivery_state'] . ' ' . $order['delivery_postal_code']); ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="location-info">
                    <h4>🏪 Pickup Location</h4>
                    <div class="location-details">
                        <strong><?php echo htmlspecialchars($order['store_name']); ?></strong><br>
                        <?php echo htmlspecialchars($order['store_address']); ?><br>
                        <?php echo htmlspecialchars($order['store_city']); ?><br>
                        📞 <?php echo htmlspecialchars($order['store_phone']); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Progress Timeline -->
                <div class="progress-timeline">
                    <div class="timeline-line"></div>
                    <div class="timeline-progress" style="height: <?php echo $progress_percentage; ?>%;"></div>

                    <?php
                    // Define timeline steps based on order type
                    if ($order['order_type'] === 'delivery') {
                        $timeline_steps = [
                            ORDER_STATUS_PENDING => ['title' => 'Order Placed', 'icon' => '📝'],
                            ORDER_STATUS_PREPARING => ['title' => 'Preparing', 'icon' => '👨‍🍳'],
                            ORDER_STATUS_READY => ['title' => 'Ready for Delivery', 'icon' => '✅'],
                            ORDER_STATUS_OUT_FOR_DELIVERY => ['title' => 'Out for Delivery', 'icon' => '🚚'],
                            ORDER_STATUS_DELIVERED => ['title' => 'Delivered', 'icon' => '🎉']
                        ];
                    } else {
                        $timeline_steps = [
                            ORDER_STATUS_PENDING => ['title' => 'Order Placed', 'icon' => '📝'],
                            ORDER_STATUS_PREPARING => ['title' => 'Preparing', 'icon' => '👨‍🍳'],
                            ORDER_STATUS_READY => ['title' => 'Ready for Pickup', 'icon' => '✅'],
                            ORDER_STATUS_PICKED_UP => ['title' => 'Picked Up', 'icon' => '🎉']
                        ];
                    }

                    foreach ($timeline_steps as $step_status => $step_info):
                        // Find if this step has been completed
                        $step_history = null;
                        foreach ($status_history as $history) {
                            if ($history['status_id'] == $step_status) {
                                $step_history = $history;
                                break;
                            }
                        }
                        
                        $is_completed = $step_history !== null;
                        $is_current = $order['order_status_id'] == $step_status;
                        $step_class = $is_completed ? 'completed' : ($is_current ? 'active' : '');
                    ?>
                    <div class="timeline-step">
                        <div class="step-icon <?php echo $step_class; ?>">
                            <?php echo $is_completed ? '✓' : $step_info['icon']; ?>
                        </div>
                        <div class="step-content">
                            <div class="step-title"><?php echo $step_info['title']; ?></div>
                            <?php if ($step_history): ?>
                                <div class="step-time">
                                    <?php echo date('M j, g:i A', strtotime($step_history['created_at'])); ?>
                                </div>
                                <?php if (!empty($step_history['notes'])): ?>
                                    <div class="step-description">
                                        <?php echo htmlspecialchars($step_history['notes']); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($step_history['changed_by_name'] !== 'System'): ?>
                                    <div class="step-updated-by">
                                        Updated by <?php echo htmlspecialchars($step_history['changed_by_name']); ?>
                                    </div>
                                <?php endif; ?>
                            <?php elseif ($is_current): ?>
                                <div class="step-time">In Progress</div>
                                <div class="step-description">
                                    <?php echo $status_info['description']; ?>
                                </div>
                            <?php else: ?>
                                <div class="step-time">Pending</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Special Instructions -->
                <?php if (!empty($order['special_instructions'])): ?>
                <div class="location-info">
                    <h4>📝 Special Instructions</h4>
                    <div class="location-details">
                        <?php echo htmlspecialchars($order['special_instructions']); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Order Items Summary -->
                <div class="location-info">
                    <h4>🍕 Your Order (<?php echo count($order_items); ?> item<?php echo count($order_items) !== 1 ? 's' : ''; ?>)</h4>
                    <div class="location-details">
                        <?php foreach ($order_items as $item): ?>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                <span>
                                    <?php echo $item['quantity']; ?>x <?php echo htmlspecialchars($item['item_name']); ?>
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        <em style="color: var(--gray-dark);">(Custom)</em>
                                    <?php endif; ?>
                                </span>
                                <span style="font-weight: 600;">
                                    <?php echo formatPrice($item['total_price']); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                        <hr style="margin: 10px 0; border: 1px solid var(--gray-medium);">
                        <div style="display: flex; justify-content: space-between; font-weight: 700; color: var(--primary-color);">
                            <span>Total:</span>
                            <span><?php echo formatPrice($order['total_amount']); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Payment Information -->
                <div class="location-info">
                    <h4>💳 Payment Information</h4>
                    <div class="location-details">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Method:</span>
                            <span style="font-weight: 600;">
                                <?php 
                                $payment_methods = [
                                    'credit_card' => '💳 Credit Card',
                                    'debit_card' => '💳 Debit Card',
                                    'internet_banking' => '🏦 Internet Banking',
                                    'cash_on_delivery' => '💵 Cash on Delivery'
                                ];
                                echo $payment_methods[$order['payment_method']] ?? ucfirst(str_replace('_', ' ', $order['payment_method']));
                                ?>
                            </span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Status:</span>
                            <span style="font-weight: 600; color: <?php echo $order['payment_status'] === 'completed' ? 'var(--success-color)' : 'var(--warning-color)'; ?>">
                                <?php echo ucfirst($order['payment_status']); ?>
                                <?php if ($order['payment_status'] === 'completed'): ?>
                                    ✓
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="contact-section">
                    <h3>Need Help with Your Order?</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <span>📞</span>
                            <span><?php echo htmlspecialchars($order['store_phone']); ?></span>
                        </div>
                        <div class="contact-item">
                            <span>📧</span>
                            <span><?php echo SUPPORT_EMAIL; ?></span>
                        </div>
                        <div class="contact-item">
                            <span>🏪</span>
                            <span><?php echo htmlspecialchars($order['store_name']); ?></span>
                        </div>
                    </div>
                    
                    <div style="margin-top: 15px; font-size: 0.9rem; color: var(--gray-dark);">
                        <p><strong>Store Hours:</strong> <?php echo OPENING_HOUR; ?>:00 AM - <?php echo CLOSING_HOUR - 12; ?>:00 PM Daily</p>
                        <?php if ($order['order_type'] === 'delivery'): ?>
                        <p><strong>Delivery Area:</strong> Orders typically arrive within <?php echo ESTIMATED_PREP_TIME + ESTIMATED_DELIVERY_TIME; ?> minutes</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div style="display: flex; gap: 15px; margin-top: 25px; flex-wrap: wrap;">
                    <a href="menu.php" 
                       style="flex: 1; min-width: 200px; background: var(--primary-color); color: white; padding: 15px; text-align: center; text-decoration: none; border-radius: 8px; font-weight: 600; transition: var(--transition);"
                       onmouseover="this.style.background='var(--primary-dark)'"
                       onmouseout="this.style.background='var(--primary-color)'">
                        🍕 Order Again
                    </a>
                    
                    <?php if (isLoggedIn()): ?>
                    <a href="customer/orders.php" 
                       style="flex: 1; min-width: 200px; background: var(--gray-medium); color: var(--text-dark); padding: 15px; text-align: center; text-decoration: none; border-radius: 8px; font-weight: 600; transition: var(--transition);"
                       onmouseover="this.style.background='var(--gray-dark)'; this.style.color='white'"
                       onmouseout="this.style.background='var(--gray-medium)'; this.style.color='var(--text-dark)'">
                        📋 Order History
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Track Another Order -->
        <div style="text-align: center; margin-top: 30px;">
            <a href="order-tracking.php" 
               style="color: var(--primary-color); text-decoration: none; font-weight: 600; font-size: 1.1rem; display: inline-flex; align-items: center; gap: 8px;"
               onmouseover="this.style.textDecoration='underline'"
               onmouseout="this.style.textDecoration='none'">
                🔍 Track Another Order
            </a>
        </div>

        <?php endif; ?>
    </div>

    <!-- Auto-refresh indicator -->
    <div class="auto-refresh" id="autoRefreshIndicator">
        🔄 Checking for updates...
    </div>

    <?php include 'templates/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Format order number input
            const orderNumberInput = document.getElementById('order_number');
            if (orderNumberInput) {
                orderNumberInput.addEventListener('input', function() {
                    let value = this.value.toUpperCase();
                    // Remove any non-alphanumeric characters except for the CP prefix
                    value = value.replace(/[^A-Z0-9]/g, '');
                    
                    // Ensure it starts with CP
                    if (value && !value.startsWith('CP')) {
                        if (value.match(/^[0-9]/)) {
                            value = 'CP' + value;
                        }
                    }
                    
                    this.value = value;
                });
            }

            // Format phone input
            const phoneInput = document.getElementById('phone');
            if (phoneInput) {
                phoneInput.addEventListener('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '').substring(0, 4);
                });
            }

            <?php if ($show_order): ?>
            // Auto-refresh functionality for active orders
            let refreshInterval;
            let nextRefreshTime = 30; // seconds
            
            function startAutoRefresh() {
                // Only auto-refresh for active orders
                const currentStatus = <?php echo $order['order_status_id']; ?>;
                const completedStatuses = [<?php echo ORDER_STATUS_DELIVERED; ?>, <?php echo ORDER_STATUS_PICKED_UP; ?>, <?php echo ORDER_STATUS_CANCELLED; ?>];
                
                if (!completedStatuses.includes(currentStatus)) {
                    refreshInterval = setInterval(function() {
                        showRefreshIndicator();
                        
                        // Reload the page to get updated order status
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    }, 30000); // 30 seconds
                }
            }
            
            function showRefreshIndicator() {
                const indicator = document.getElementById('autoRefreshIndicator');
                indicator.classList.add('active');
                
                setTimeout(function() {
                    indicator.classList.remove('active');
                }, 3000);
            }
            
            // Start auto-refresh
            startAutoRefresh();
            
            // Pause auto-refresh when page is not visible
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    clearInterval(refreshInterval);
                } else {
                    startAutoRefresh();
                }
            });
            
            // Manual refresh button (hidden, can be triggered with keyboard shortcut)
            document.addEventListener('keydown', function(e) {
                if (e.key === 'r' && e.ctrlKey) {
                    e.preventDefault();
                    showRefreshIndicator();
                    setTimeout(() => window.location.reload(), 500);
                }
            });
            
            // Animate timeline progress on load
            setTimeout(function() {
                const progressElement = document.querySelector('.timeline-progress');
                if (progressElement) {
                    const targetHeight = progressElement.style.height;
                    progressElement.style.height = '0%';
                    setTimeout(() => {
                        progressElement.style.height = targetHeight;
                    }, 500);
                }
            }, 300);
            
            // Show notification about auto-refresh
            setTimeout(function() {
                showNotification('This page will automatically refresh every 30 seconds to show the latest updates', 'info');
            }, 2000);
            
            <?php endif; ?>
        });

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 8px;
                color: white;
                font-weight: 600;
                z-index: 1000;
                animation: slideInRight 0.3s ease;
                box-shadow: var(--shadow-medium);
                max-width: 350px;
                font-size: 0.9rem;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = '#00b894';
                    break;
                case 'error':
                    notification.style.background = '#d63031';
                    break;
                case 'info':
                    notification.style.background = '#74b9ff';
                    break;
                default:
                    notification.style.background = '#74b9ff';
            }
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 5000);
        }

        // Add slide animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>