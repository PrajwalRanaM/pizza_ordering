-- Crust Pizza Database Seed Data
-- Melbourne, Victoria locations with Nepalese names

USE crust_pizza_db;

-- =====================================================
-- LOCATIONS (Melbourne, Victoria stores)
-- =====================================================
INSERT INTO locations (store_name, address, city, state, postal_code, phone, email) VALUES
('Crust Pizza CBD', '123 Collins Street', 'Melbourne', 'VIC', '3000', '03 9123 4567', 'cbd@crustpizza.com.au'),
('Crust Pizza Docklands', '456 Harbour Esplanade', 'Docklands', 'VIC', '3008', '03 9234 5678', 'docklands@crustpizza.com.au'),
('Crust Pizza Carlton', '789 Lygon Street', 'Carlton', 'VIC', '3053', '03 9345 6789', 'carlton@crustpizza.com.au'),
('Crust Pizza Richmond', '321 Swan Street', 'Richmond', 'VIC', '3121', '03 9456 7890', 'richmond@crustpizza.com.au'),
('Crust Pizza St Kilda', '654 Fitzroy Street', 'St Kilda', 'VIC', '3182', '03 9567 8901', 'stkilda@crustpizza.com.au');

-- =====================================================
-- EMPLOYEE ROLES
-- =====================================================
INSERT INTO employee_roles (role_name, description) VALUES
('Kitchen Staff', 'Responsible for preparing pizzas and managing kitchen operations'),
('Delivery Staff', 'Responsible for delivering orders to customers'),
('Counter Staff', 'Responsible for handling pickup orders and customer service');

-- =====================================================
-- ADMINS (Nepalese names)
-- =====================================================
INSERT INTO admins (username, password, email, first_name, last_name) VALUES
('admin', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'admin@crustpizza.com.au', 'Admin', 'User'),
('sshiva', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'sshiva@crustpizza.com.au', 'Sshiva', 'Bhandari');

-- =====================================================
-- EMPLOYEES (Nepalese names)
-- =====================================================
-- Kitchen Staff
INSERT INTO employees (username, password, email, first_name, last_name, phone, role_id, location_id) VALUES
('kitchen', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'kitchen@crustpizza.com.au', 'Kitchen', 'Staff', '0412 345 678', 1, 1),
('sandip', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'sandip@crustpizza.com.au', 'Sandip', 'Limbu', '0423 456 789', 1, 1),
('kitchen_rai1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'prakash.rai@crustpizza.com.au', 'Prakash', 'Rai', '0434 567 890', 1, 2),
('kitchen_tamang1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'anita.tamang@crustpizza.com.au', 'Anita', 'Tamang', '0445 678 901', 1, 2),
('kitchen_magar1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'krishna.magar@crustpizza.com.au', 'Krishna', 'Magar', '0456 789 012', 1, 3);

-- Delivery Staff
INSERT INTO employees (username, password, email, first_name, last_name, phone, role_id, location_id) VALUES
('delivery', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'delivery@crustpizza.com.au', 'Delivery', 'Staff', '0467 890 123', 2, 1),
('prajwal', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'prajwal@crustpizza.com.au', 'Prajwal', 'Rana', '0478 901 234', 2, 1),
('delivery_basnet1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'sujan.basnet@crustpizza.com.au', 'Sujan', 'Basnet', '0489 012 345', 2, 2),
('delivery_khadka1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'dipak.khadka@crustpizza.com.au', 'Dipak', 'Khadka', '0490 123 456', 2, 3),
('delivery_adhikari1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'priya.adhikari@crustpizza.com.au', 'Priya', 'Adhikari', '0401 234 567', 2, 4);

-- Counter Staff
INSERT INTO employees (username, password, email, first_name, last_name, phone, role_id, location_id) VALUES
('counter', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'counter@crustpizza.com.au', 'Counter', 'Staff', '0412 345 678', 3, 1),
('counter_poudel1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'santosh.poudel@crustpizza.com.au', 'Santosh', 'Poudel', '0423 456 789', 3, 2),
('counter_bhattarai1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'gita.bhattarai@crustpizza.com.au', 'Gita', 'Bhattarai', '0434 567 890', 3, 3),
('counter_karki1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'bijay.karki@crustpizza.com.au', 'Bijay', 'Karki', '0445 678 901', 3, 4),
('counter_nepal1', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'sarita.nepal@crustpizza.com.au', 'Sarita', 'Nepal', '0456 789 012', 3, 5);

-- =====================================================
-- CUSTOMERS (Nepalese names with Melbourne addresses)
-- =====================================================
INSERT INTO customers (username, password, email, first_name, last_name, phone, address, city, state, postal_code) VALUES
('customer', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'customer@crustpizza.com.au', 'Customer', 'User', '0412 111 222', '123 Swanston Street', 'Melbourne', 'VIC', '3000'),
('sunita_gurung', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'sunita.gurung@gmail.com', 'Sunita', 'Gurung', '0423 222 333', '456 Elizabeth Street', 'Melbourne', 'VIC', '3000'),
('ram_sharma', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'ram.sharma@yahoo.com', 'Ram', 'Sharma', '0434 333 444', '789 Chapel Street', 'South Yarra', 'VIC', '3141'),
('mina_rai', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'mina.rai@gmail.com', 'Mina', 'Rai', '0445 444 555', '321 High Street', 'Prahran', 'VIC', '3181'),
('krishna_lama', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'krishna.lama@outlook.com', 'Krishna', 'Lama', '0456 555 666', '654 Smith Street', 'Collingwood', 'VIC', '3066'),
('anjali_shrestha', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'anjali.shrestha@gmail.com', 'Anjali', 'Shrestha', '0467 666 777', '987 Brunswick Street', 'Fitzroy', 'VIC', '3065'),
('bikas_tamang', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'bikas.tamang@gmail.com', 'Bikas', 'Tamang', '0478 777 888', '147 Bourke Street', 'Melbourne', 'VIC', '3000'),
('puja_magar', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'puja.magar@gmail.com', 'Puja', 'Magar', '0489 888 999', '258 Johnston Street', 'Abbotsford', 'VIC', '3067'),
('nabin_basnet', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'nabin.basnet@gmail.com', 'Nabin', 'Basnet', '0490 999 000', '369 Victoria Street', 'Richmond', 'VIC', '3121'),
('rita_khadka', '$2y$12$1Mv36X1AZbCyHaEYB9.oM.vgMcXXFothUlYtpcW4xRo4uxx5wKkau', 'rita.khadka@gmail.com', 'Rita', 'Khadka', '0401 000 111', '741 Sydney Road', 'Brunswick', 'VIC', '3056');

-- =====================================================
-- PRODUCT CATEGORIES
-- =====================================================
INSERT INTO product_categories (category_name, description, display_order) VALUES
('Pizzas', 'Our signature gourmet pizzas', 1),
('Drinks', 'Refreshing beverages', 2),
('Sides', 'Delicious side dishes', 3),
('Desserts', 'Sweet treats to finish your meal', 4);

-- =====================================================
-- CRUST SIZES
-- =====================================================
INSERT INTO crust_sizes (size_name, size_code, price_multiplier) VALUES
('Small', 'S', 1.00),
('Medium', 'M', 1.30),
('Large', 'L', 1.60);

-- =====================================================
-- CRUST TYPES
-- =====================================================
INSERT INTO crust_types (crust_name, description, additional_price, is_gluten_free, is_vegan) VALUES
('Traditional', 'Our classic hand-tossed crust', 0.00, FALSE, FALSE),
('Thin & Crispy', 'Extra thin and crispy base', 0.00, FALSE, FALSE),
('Gluten Free', 'Delicious gluten-free option', 3.00, TRUE, FALSE),
('Cauliflower', 'Low carb cauliflower base', 4.00, TRUE, TRUE),
('Wholemeal', 'Healthy wholemeal option', 2.00, FALSE, FALSE);

-- =====================================================
-- SAUCES
-- =====================================================
INSERT INTO sauces (sauce_name, description, is_vegan) VALUES
('Marinara', 'Traditional tomato sauce', TRUE),
('BBQ', 'Smoky barbecue sauce', TRUE),
('Garlic Butter', 'Creamy garlic butter sauce', FALSE),
('Pesto', 'Fresh basil pesto', FALSE),
('Hot Chilli', 'Spicy chilli sauce', TRUE),
('Ranch', 'Creamy ranch sauce', FALSE);

-- =====================================================
-- CHEESE TYPES
-- =====================================================
INSERT INTO cheese_types (cheese_name, description, is_vegan) VALUES
('Mozzarella', 'Traditional mozzarella cheese', FALSE),
('Vegan Cheese', 'Plant-based cheese alternative', TRUE),
('Cheddar', 'Sharp cheddar cheese', FALSE),
('Feta', 'Crumbled feta cheese', FALSE),
('Parmesan', 'Grated parmesan cheese', FALSE);

-- =====================================================
-- INGREDIENTS (TOPPINGS)
-- =====================================================
-- Vegetarian Toppings
INSERT INTO ingredients (ingredient_name, description, category, price, is_vegan, is_gluten_free) VALUES
('Mushrooms', 'Fresh button mushrooms', 'vegetarian', 2.50, TRUE, TRUE),
('Capsicum', 'Red and green capsicum', 'vegetarian', 2.50, TRUE, TRUE),
('Onion', 'Red onion slices', 'vegetarian', 2.00, TRUE, TRUE),
('Olives', 'Kalamata olives', 'vegetarian', 3.00, TRUE, TRUE),
('Pineapple', 'Fresh pineapple pieces', 'vegetarian', 2.50, TRUE, TRUE),
('Tomato', 'Fresh tomato slices', 'vegetarian', 2.00, TRUE, TRUE),
('Spinach', 'Baby spinach leaves', 'vegetarian', 2.50, TRUE, TRUE),
('Jalapeños', 'Pickled jalapeños', 'vegetarian', 2.50, TRUE, TRUE),
('Corn', 'Sweet corn kernels', 'vegetarian', 2.00, TRUE, TRUE),
('Broccoli', 'Fresh broccoli florets', 'vegetarian', 2.50, TRUE, TRUE);

-- Non-Vegetarian Toppings
INSERT INTO ingredients (ingredient_name, description, category, price, is_vegan, is_gluten_free) VALUES
('Pepperoni', 'Spicy pepperoni slices', 'non-vegetarian', 4.00, FALSE, TRUE),
('Ham', 'Smoked ham pieces', 'non-vegetarian', 3.50, FALSE, TRUE),
('Bacon', 'Crispy bacon bits', 'non-vegetarian', 4.50, FALSE, TRUE),
('Chicken', 'Grilled chicken pieces', 'non-vegetarian', 4.00, FALSE, TRUE),
('Beef', 'Ground beef', 'non-vegetarian', 4.50, FALSE, TRUE),
('Prawns', 'Tiger prawns', 'non-vegetarian', 5.00, FALSE, TRUE),
('Anchovies', 'Marinated anchovies', 'non-vegetarian', 3.50, FALSE, TRUE),
('Salami', 'Italian salami', 'non-vegetarian', 4.00, FALSE, TRUE),
('Peri Peri Chicken', 'Spicy peri peri chicken', 'non-vegetarian', 4.50, FALSE, TRUE),
('BBQ Pulled Pork', 'Slow-cooked pulled pork', 'non-vegetarian', 5.00, FALSE, TRUE);

-- =====================================================
-- PRODUCTS (Preset Pizzas)
-- =====================================================
INSERT INTO products (product_name, description, category_id, base_price, image_url, is_customizable, is_vegetarian, is_vegan) VALUES
('Margherita', 'Traditional pizza with mozzarella, tomato sauce and basil', 1, 18.90,'uploads/products/Margherita.jpg', TRUE, TRUE, FALSE),
('Pepperoni', 'Classic pepperoni with mozzarella and tomato sauce', 1, 21.90,'uploads/products/pepperoni.jpg', TRUE, FALSE, FALSE),
('Hawaiian', 'Ham, pineapple, mozzarella and tomato sauce', 1, 22.90,'uploads/products/hawaiian.jpg', TRUE, FALSE, FALSE),
('Peri Peri Chicken', 'Our famous peri peri chicken with capsicum and onion', 1, 24.90,'uploads/products/PeriPeriChicken.jpg', TRUE, FALSE, FALSE),
('Vegetarian Supreme', 'Mushrooms, capsicum, onion, olives, tomato', 1, 23.90,'uploads/products/veggie_supreme.jpg', TRUE, TRUE, FALSE),
('Meat Lovers', 'Pepperoni, ham, bacon, beef, BBQ sauce', 1, 26.90,'uploads/products/meat_lovers.jpg', TRUE, FALSE, FALSE),
('BBQ Chicken', 'BBQ chicken, bacon, onion, BBQ sauce', 1, 24.90,'uploads/products/bbq_chicken.jpg', TRUE, FALSE, FALSE),
('Vegan Delight', 'Vegan cheese, mushrooms, capsicum, spinach, olives', 1, 25.90,'uploads/products/vegan_veggie.jpg', TRUE, TRUE, TRUE),
('Prawn Special', 'Tiger prawns, garlic, chilli, rocket', 1, 27.90,'uploads/products/prawn_garlic.jpg', TRUE, FALSE, FALSE),
('Four Cheese', 'Mozzarella, cheddar, feta, parmesan', 1, 23.90,'uploads/products/four_cheese.jpg', TRUE, FALSE, FALSE),
('Garlic Prawn', 'Garlic prawns, mozzarella, fresh herbs', 1, 26.90,'uploads/products/garlic_prawn.jpg', TRUE, FALSE, FALSE),
('Spicy Veggie', 'Spicy jalapeños, olives, capsicum, onion', 1, 22.90,'uploads/products/spicy_veggie.jpg', TRUE, TRUE, FALSE),
('Buffalo Chicken', 'Spicy buffalo chicken, ranch sauce, mozzarella', 1, 25.90,'uploads/products/buffalo_chicken.jpg', TRUE, FALSE, FALSE),
('Capricciosa', 'Ham, mushrooms, artichokes, olives', 1, 24.90,'uploads/products/capricciosa.jpg', TRUE, FALSE, FALSE),
('Tandoori Chicken', 'Tandoori chicken, red onion, mint yogurt sauce', 1, 25.90,'uploads/products/tandoori_chicken.jpg', TRUE, FALSE, FALSE)
;



-- Non-pizza items
INSERT INTO products (product_name, description, category_id, base_price, is_customizable) VALUES
('Garlic Bread', 'Fresh baked garlic bread', 3, 8.90, FALSE),
('Cheesy Garlic Bread', 'Garlic bread topped with mozzarella', 3, 11.90, FALSE),
('Chicken Wings', 'BBQ or Hot & Spicy chicken wings', 3, 12.90, FALSE),
('Caesar Salad', 'Classic caesar salad', 3, 14.90, FALSE),
('Wedges', 'Seasoned potato wedges with sour cream', 3, 9.90, FALSE),
('Coca Cola 1.25L', 'Coca Cola soft drink', 2, 4.90, FALSE),
('Sprite 1.25L', 'Sprite lemon-lime', 2, 4.90, FALSE),
('Orange Juice', 'Fresh orange juice', 2, 5.90, FALSE),
('Chocolate Mousse', 'Rich chocolate mousse', 4, 7.90, FALSE),
('Tiramisu', 'Traditional Italian tiramisu', 4, 8.90, FALSE);

-- =====================================================
-- ORDER STATUSES
-- =====================================================
INSERT INTO order_statuses (status_name, description, display_order) VALUES
('Pending', 'Order received and pending preparation', 1),
('Preparing', 'Order is being prepared in kitchen', 2),
('Ready', 'Order is ready for delivery/pickup', 3),
('Out for Delivery', 'Order is on the way', 4),
('Delivered', 'Order has been delivered', 5),
('Picked Up', 'Order has been picked up by customer', 6),
('Cancelled', 'Order has been cancelled', 7),
('Failed', 'Delivery failed', 8);

-- =====================================================
-- SAMPLE ORDERS
-- =====================================================
-- Order 1: Delivery order
INSERT INTO orders (order_number, customer_id, location_id, order_type, delivery_address, delivery_city, delivery_state, delivery_postal_code, order_status_id, subtotal, tax_amount, delivery_fee, total_amount, payment_method, payment_status, estimated_time) VALUES
('ORD20240001', 1, 1, 'delivery', '123 Swanston Street', 'Melbourne', 'VIC', '3000', 1, 45.80, 4.58, 5.00, 55.38, 'credit_card', 'completed', DATE_ADD(NOW(), INTERVAL 45 MINUTE));

-- Order items for Order 1
INSERT INTO order_items (order_id, product_id, item_name, item_type, quantity, unit_price, total_price) VALUES
(1, 2, 'Pepperoni Pizza - Large', 'preset', 1, 35.04, 35.04),
(1, 11, 'Garlic Bread', 'preset', 1, 8.90, 8.90);

-- Order 2: Pickup order
INSERT INTO orders (order_number, customer_id, location_id, order_type, pickup_time, order_status_id, subtotal, tax_amount, delivery_fee, total_amount, payment_method, payment_status, estimated_time) VALUES
('ORD20240002', 3, 2, 'pickup', DATE_ADD(NOW(), INTERVAL 30 MINUTE), 2, 24.90, 2.49, 0.00, 27.39, 'cash_on_delivery', 'pending', DATE_ADD(NOW(), INTERVAL 30 MINUTE));

-- Order items for Order 2
INSERT INTO order_items (order_id, product_id, item_name, item_type, quantity, unit_price, total_price) VALUES
(2, 4, 'Peri Peri Chicken - Medium', 'preset', 1, 24.90, 24.90);

-- =====================================================
-- SAMPLE CART ITEMS
-- =====================================================
INSERT INTO cart_items (session_id, customer_id, product_id, item_type, quantity, unit_price) VALUES
('session_123456', 2, 1, 'preset', 1, 18.90),
('session_123456', 2, 16, 'preset', 2, 4.90);

-- =====================================================
-- PRODUCT INGREDIENTS (Linking ingredients to preset pizzas)
-- =====================================================
-- Margherita
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(1, 6); -- Tomato

-- Pepperoni
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(2, 11); -- Pepperoni

-- Hawaiian
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(3, 12), -- Ham
(3, 5);  -- Pineapple

-- Peri Peri Chicken
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(4, 19), -- Peri Peri Chicken
(4, 2),  -- Capsicum
(4, 3);  -- Onion

-- Vegetarian Supreme
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(5, 1),  -- Mushrooms
(5, 2),  -- Capsicum
(5, 3),  -- Onion
(5, 4),  -- Olives
(5, 6);  -- Tomato

-- Meat Lovers
INSERT INTO product_ingredients (product_id, ingredient_id) VALUES
(6, 11), -- Pepperoni
(6, 12), -- Ham
(6, 13), -- Bacon
(6, 15); -- Beef

-- This completes the basic seeding data
-- All passwords are placeholder hashes and should be properly hashed in production