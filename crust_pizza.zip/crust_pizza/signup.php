<?php
// signup.php - Updated with configuration system
require_once 'includes/init.php';

// Generate CSRF token
$csrf_token = generateCSRFToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = ERR_CSRF_TOKEN;
    } else {
        // Sanitize and validate input data
        $username = sanitizeInput($_POST['username'] ?? '');
        $first_name = sanitizeInput($_POST['first_name'] ?? '');
        $last_name = sanitizeInput($_POST['last_name'] ?? '');
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';
        $phone = sanitizeInput($_POST['phone'] ?? '');
        $address = sanitizeInput($_POST['address'] ?? '');
        $city = sanitizeInput($_POST['city'] ?? '');
        $state = $_POST['state'] ?? '';
        $postal_code = sanitizeInput($_POST['postal_code'] ?? '');
        
        // Validation
        $errors = [];
        
        // Required field validation
        if (empty($username)) $errors[] = "Username is required.";
        if (empty($first_name)) $errors[] = "First name is required.";
        if (empty($last_name)) $errors[] = "Last name is required.";
        if (empty($email)) $errors[] = "Email address is required.";
        if (empty($password)) $errors[] = "Password is required.";
        if (empty($phone)) $errors[] = "Phone number is required.";
        if (empty($address)) $errors[] = "Address is required.";
        if (empty($city)) $errors[] = "City is required.";
        if (empty($state)) $errors[] = "State is required.";
        if (empty($postal_code)) $errors[] = "Postal code is required.";
        
        // Username validation
        if (!preg_match(REGEX_USERNAME, $username)) {
            $errors[] = "Username must be 3-20 characters and contain only letters, numbers, and underscores.";
        }
        
        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = ERR_INVALID_EMAIL;
        }
        
        // Password validation
        $password_errors = validatePassword($password);
        $errors = array_merge($errors, $password_errors);
        
        // Phone number validation (Australian format)
        $phone_clean = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone_clean) !== 10) {
            $errors[] = ERR_INVALID_PHONE;
        }
        
        // Postal code validation (Australian format)
        if (!preg_match(REGEX_POSTCODE_AU, $postal_code)) {
            $errors[] = ERR_INVALID_POSTCODE;
        }
        
        // State validation
        if (!array_key_exists($state, AU_STATES)) {
            $errors[] = "Please select a valid Australian state.";
        }
        
        // Check if username or email already exists
        if (empty($errors)) {
            try {
                // Check for existing username
                $stmt = $conn->prepare("SELECT customer_id FROM customers WHERE username = ?");
                if ($stmt) {
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $errors[] = ERR_USERNAME_EXISTS;
                    }
                    $stmt->close();
                }
                
                // Check for existing email
                $stmt = $conn->prepare("SELECT customer_id FROM customers WHERE email = ?");
                if ($stmt) {
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $errors[] = ERR_EMAIL_EXISTS;
                    }
                    $stmt->close();
                }
            } catch (Exception $e) {
                $errors[] = ERR_DATABASE_ERROR;
                if (SHOW_SQL_ERRORS) {
                    $errors[] = $e->getMessage();
                }
            }
        }
        
        // If no errors, proceed with registration
        if (empty($errors)) {
            try {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Format phone number for storage
                $formatted_phone = formatPhoneNumber($phone_clean);
                
                // Begin transaction
                $conn->begin_transaction();
                
                // Insert customer into database
                $stmt = $conn->prepare("
                    INSERT INTO customers (
                        username,
                        password,
                        email,
                        first_name, 
                        last_name, 
                        phone, 
                        address,
                        city,
                        state, 
                        postal_code,
                        is_active,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
                ");
                
                if ($stmt === false) {
                    throw new Exception(ERR_DATABASE_ERROR);
                }
                
                $stmt->bind_param(
                    "ssssssssss", 
                    $username,
                    $hashed_password,
                    $email,
                    $first_name, 
                    $last_name, 
                    $formatted_phone, 
                    $address,
                    $city,
                    $state, 
                    $postal_code
                );
                
                if ($stmt->execute()) {
                    // Registration successful
                    $customer_id = $conn->insert_id;
                    
                    // Commit transaction
                    $conn->commit();
                    
                    // Create user session
                    $user_data = [
                        'user_id' => $customer_id,
                        'first_name' => $first_name,
                        'last_name' => $last_name
                    ];
                    createUserSession($user_data, USER_TYPE_CUSTOMER);
                    
                    // Send welcome email (if email is configured)
                    // sendWelcomeEmail($email, $first_name);
                    
                    // Redirect to welcome page or home
                    header("Location: index.php?welcome=1");
                    exit();
                    
                } else {
                    throw new Exception(MSG_REGISTER_FAILED);
                }
                
            } catch (Exception $e) {
                // Rollback transaction on error
                $conn->rollback();
                $error = $e->getMessage();
                if (SHOW_SQL_ERRORS && $conn->error) {
                    $error .= "<br>Debug: " . $conn->error;
                }
            }
        } else {
            $error = implode("<br>", $errors);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - <?php echo SITE_NAME; ?></title>
    <meta name="description" content="Create your account and start ordering delicious gourmet pizzas from <?php echo SITE_NAME; ?>.">
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>css/form.css">
    <link rel="stylesheet" href="assets/css/signup.css">
    
</head>
<body class="signup-page">
    <div class="signup-container">
        <h1 class="signup-title">🍕 Join <?php echo SITE_NAME; ?></h1>
        <p class="signup-subtitle">Create your account and start ordering delicious pizzas!</p>

        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="signupForm">
            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
            
            <!-- Account Information -->
            <div class="form-section">
                <h3>Account Information</h3>
                
                <div class="form-group">
                    <label for="username" class="form-label required">Username</label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           class="form-input" 
                           required 
                           placeholder="Choose a username (3-20 characters)"
                           pattern="[a-zA-Z0-9_]{3,20}"
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    <small class="form-hint">Letters, numbers, and underscores only</small>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email" class="form-label required">Email Address</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               class="form-input" 
                               required 
                               placeholder="your.email@example.com"
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label required">Password</label>
                        <input type="password" 
                               id="password" 
                               name="password" 
                               class="form-input" 
                               required 
                               placeholder="Create a strong password"
                               minlength="<?php echo PASSWORD_MIN_LENGTH; ?>">
                    </div>
                </div>
                
                <div class="password-requirements">
                    <h4>Password must include:</h4>
                    <ul>
                        <li id="length-req">At least <?php echo PASSWORD_MIN_LENGTH; ?> characters</li>
                        <li id="upper-req">One uppercase letter</li>
                        <li id="lower-req">One lowercase letter</li>
                        <li id="number-req">One number</li>
                        <li id="special-req">One special character</li>
                    </ul>
                </div>
                
                <div class="password-strength" style="display: none;">
                    <div class="strength-bar">
                        <div class="strength-fill"></div>
                    </div>
                    <div class="strength-text">Password strength: <span class="strength-level">Weak</span></div>
                </div>
            </div>
            
            <!-- Personal Information -->
            <div class="form-section">
                <h3>Personal Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name" class="form-label required">First Name</label>
                        <input type="text" 
                               id="first_name" 
                               name="first_name" 
                               class="form-input" 
                               required 
                               placeholder="Your first name"
                               value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name" class="form-label required">Last Name</label>
                        <input type="text" 
                               id="last_name" 
                               name="last_name" 
                               class="form-input" 
                               required 
                               placeholder="Your last name"
                               value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="phone" class="form-label required">Phone Number</label>
                    <input type="tel" 
                           id="phone" 
                           name="phone" 
                           class="form-input" 
                           required 
                           placeholder="04XX XXX XXX"
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>
            </div>
            
            <!-- Delivery Address -->
            <div class="form-section address-section">
                <h3>📍 Delivery Address</h3>
                
                <div class="form-group">
                    <label for="address" class="form-label required">Street Address</label>
                    <input type="text" 
                           id="address" 
                           name="address" 
                           class="form-input" 
                           required 
                           placeholder="123 Main Street"
                           maxlength="<?php echo MAX_ADDRESS_LENGTH; ?>"
                           value="<?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="city" class="form-label required">City/Suburb</label>
                        <input type="text" 
                               id="city" 
                               name="city" 
                               class="form-input" 
                               required 
                               placeholder="Melbourne"
                               value="<?php echo isset($_POST['city']) ? htmlspecialchars($_POST['city']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="state" class="form-label required">State</label>
                        <select id="state" name="state" class="form-select" required>
                            <option value="">Select State</option>
                            <?php foreach (AU_STATES as $code => $name): ?>
                                <option value="<?php echo $code; ?>" <?php echo (isset($_POST['state']) && $_POST['state'] === $code) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="postal_code" class="form-label required">Postal Code</label>
                        <input type="text" 
                               id="postal_code" 
                               name="postal_code" 
                               class="form-input" 
                               required 
                               placeholder="3000"
                               pattern="[0-9]{4}"
                               maxlength="4"
                               value="<?php echo isset($_POST['postal_code']) ? htmlspecialchars($_POST['postal_code']) : ''; ?>">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="register-btn" id="registerBtn">Create Account</button>
        </form>

        <div class="login-section">
            <p class="login-text">Already have an account?</p>
            <a href="login.php" class="login-btn-link">Login Here</a>
        </div>
    </div>
    
    <script>
        // Updated JavaScript with proper validation
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('signupForm');
            const registerBtn = document.getElementById('registerBtn');
            const passwordInput = document.getElementById('password');
            const usernameInput = document.getElementById('username');
            const strengthBar = document.querySelector('.password-strength');
            
            // Show password strength indicator when user starts typing
            passwordInput.addEventListener('focus', function() {
                strengthBar.style.display = 'block';
            });
            
            // Real-time password validation
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                const minLength = <?php echo PASSWORD_MIN_LENGTH; ?>;
                
                // Check each requirement
                const requirements = {
                    length: password.length >= minLength,
                    upper: /[A-Z]/.test(password),
                    lower: /[a-z]/.test(password),
                    number: /[0-9]/.test(password),
                    special: /[^A-Za-z0-9]/.test(password)
                };
                
                // Update requirement indicators
                document.getElementById('length-req').classList.toggle('valid', requirements.length);
                document.getElementById('upper-req').classList.toggle('valid', requirements.upper);
                document.getElementById('lower-req').classList.toggle('valid', requirements.lower);
                document.getElementById('number-req').classList.toggle('valid', requirements.number);
                document.getElementById('special-req').classList.toggle('valid', requirements.special);
                
                // Calculate strength score
                const score = Object.values(requirements).filter(Boolean).length;
                updatePasswordStrength(score);
                
                // Update password requirements box color
                const requirementsBox = document.querySelector('.password-requirements');
                if (score === 5) {
                    requirementsBox.style.borderColor = '#00b894';
                    requirementsBox.style.backgroundColor = '#d4edda';
                } else {
                    requirementsBox.style.borderColor = '#bee5eb';
                    requirementsBox.style.backgroundColor = '#e8f4f8';
                }
            });
            
            function updatePasswordStrength(score) {
                const strengthFill = document.querySelector('.strength-fill');
                const strengthLevel = document.querySelector('.strength-level');
                
                const percentage = (score / 5) * 100;
                strengthFill.style.width = percentage + '%';
                
                if (score <= 2) {
                    strengthFill.style.background = '#ff7675';
                    strengthLevel.textContent = 'Weak';
                    strengthLevel.style.color = '#ff7675';
                } else if (score <= 3) {
                    strengthFill.style.background = '#fdcb6e';
                    strengthLevel.textContent = 'Fair';
                    strengthLevel.style.color = '#fdcb6e';
                } else if (score <= 4) {
                    strengthFill.style.background = '#e17055';
                    strengthLevel.textContent = 'Good';
                    strengthLevel.style.color = '#e17055';
                } else {
                    strengthFill.style.background = '#00b894';
                    strengthLevel.textContent = 'Strong';
                    strengthLevel.style.color = '#00b894';
                }
            }
            
            // Username validation
            usernameInput.addEventListener('input', function() {
                const username = this.value;
                const isValid = /^[a-zA-Z0-9_]{3,20}$/.test(username);
                
                if (username.length > 0) {
                    this.style.borderColor = isValid ? '#00b894' : '#ff7675';
                }
            });
            
            // Phone number formatting (Australian format)
            const phoneInput = document.getElementById('phone');
            phoneInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                if (value.length >= 10) {
                    value = value.substring(0, 10);
                    value = value.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
                }
                this.value = value;
            });
            
            // Form submission handling
            form.addEventListener('submit', function() {
                registerBtn.textContent = 'Creating Account...';
                registerBtn.disabled = true;
            });
            
            // Postal code validation (Australian postcodes)
            const postalCodeInput = document.getElementById('postal_code');
            postalCodeInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '').substring(0, 4);
            });

            // Auto-hide error messages after 5 seconds
            const errorMsg = document.querySelector('.error-message');
            if (errorMsg) {
                setTimeout(() => {
                    errorMsg.style.opacity = '0';
                    setTimeout(() => errorMsg.remove(), 300);
                }, 5000);
            }
            
            // Postal code to suburb mapping (simplified for demo)
            const postcodeMap = {
                '3000': 'Melbourne',
                '3001': 'Melbourne',
                '3002': 'East Melbourne',
                '3003': 'West Melbourne',
                '3004': 'Melbourne',
                '3006': 'Southbank',
                '3008': 'Docklands',
                '3053': 'Carlton',
                '3121': 'Richmond',
                '3141': 'South Yarra',
                '3181': 'Prahran',
                '3182': 'St Kilda'
            };
            
            // Auto-suggest suburb based on postcode
            postalCodeInput.addEventListener('input', function() {
                const postcode = this.value;
                const cityInput = document.getElementById('city');
                
                if (postcode.length === 4 && postcodeMap[postcode] && !cityInput.value) {
                    cityInput.value = postcodeMap[postcode];
                    cityInput.style.backgroundColor = '#d4edda';
                    setTimeout(() => {
                        cityInput.style.backgroundColor = '';
                    }, 1000);
                }
            });
        });
    </script>
</body>
</html>