<?php
// staff/counter/dashboard.php - Fixed version with correct parameter binding
require_once '../../includes/init.php';

// Check if user is logged in and is counter staff
if (!isLoggedIn() || !isEmployee()) {
    setFlashMessage('Please login with your staff credentials.', 'warning');
    redirect('../../login.php');
}

// Check if user has counter staff role
if (!hasRole('Counter Staff')) {
    setFlashMessage('Access denied. Counter staff only.', 'error');
    redirect('../../index.php');
}

// Get employee details
$employee_id = getCurrentUserId();
$employee_location = getUserLocation($conn);

// Get location details
$location_stmt = $conn->prepare("SELECT store_name, city, address, phone FROM locations WHERE location_id = ?");
$location_stmt->bind_param("i", $employee_location);
$location_stmt->execute();
$location = $location_stmt->get_result()->fetch_assoc();

// Handle status updates and order completion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $order_id = $_POST['order_id'] ?? 0;
    $notes = sanitizeInput($_POST['notes'] ?? '');
    
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('Invalid form submission. Please try again.', 'error');
    } else {
        try {
            if ($action === 'mark_ready_pickup') {
                // Mark order as ready for pickup
                $order_status_ready = ORDER_STATUS_READY; // FIX: Use variable instead of constant
                
                $verify_stmt = $conn->prepare("
                    SELECT order_id, order_number, customer_id
                    FROM orders 
                    WHERE order_id = ? AND location_id = ? 
                    AND order_status_id = ? AND order_type = 'pickup'
                ");
                $verify_stmt->bind_param("iii", $order_id, $employee_location, $order_status_ready);
                $verify_stmt->execute();
                $order_check = $verify_stmt->get_result()->fetch_assoc();
                
                if (!$order_check) {
                    setFlashMessage('Order not found or cannot be updated.', 'error');
                } else {
                    // Add to status history (order remains READY, just adding notification)
                    $changed_by_type = 'employee'; // FIX: Use variable instead of literal
                    $history_stmt = $conn->prepare("
                        INSERT INTO order_status_history 
                        (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                        VALUES (?, ?, ?, ?, ?, NOW())
                    ");
                    $ready_note = !empty($notes) ? $notes : "Order ready for customer pickup";
                    $history_stmt->bind_param("iisis", $order_id, $order_status_ready, $changed_by_type, $employee_id, $ready_note);
                    $history_stmt->execute();
                    
                    setFlashMessage('Customer notified - Order #' . $order_check['order_number'] . ' ready for pickup', 'success');
                }
                
            } elseif ($action === 'complete_pickup') {
                // Mark pickup order as completed
                $customer_phone = sanitizeInput($_POST['customer_phone'] ?? '');
                
                if (empty($customer_phone)) {
                    setFlashMessage('Please verify customer phone number before completing pickup.', 'error');
                } else {
                    // Verify order and customer phone
                    $order_status_ready = ORDER_STATUS_READY; // FIX: Use variable
                    
                    $verify_stmt = $conn->prepare("
                        SELECT o.order_id, o.order_number, c.phone, o.customer_id
                        FROM orders o
                        JOIN customers c ON o.customer_id = c.customer_id
                        WHERE o.order_id = ? AND o.location_id = ? 
                        AND o.order_status_id = ? AND o.order_type = 'pickup'
                        AND RIGHT(REPLACE(c.phone, ' ', ''), 4) = ?
                    ");
                    $phone_last_four = substr(preg_replace('/[^0-9]/', '', $customer_phone), -4);
                    $verify_stmt->bind_param("iiis", $order_id, $employee_location, $order_status_ready, $phone_last_four);
                    $verify_stmt->execute();
                    $order_check = $verify_stmt->get_result()->fetch_assoc();
                    
                    if (!$order_check) {
                        setFlashMessage('Order not found or phone verification failed. Please check the last 4 digits of customer phone.', 'error');
                    } else {
                        $conn->begin_transaction();
                        
                        // Update order status to picked up
                        $order_status_picked_up = ORDER_STATUS_PICKED_UP; // FIX: Use variable
                        
                        $update_stmt = $conn->prepare("
                            UPDATE orders 
                            SET order_status_id = ?, updated_at = NOW() 
                            WHERE order_id = ?
                        ");
                        $update_stmt->bind_param("ii", $order_status_picked_up, $order_id);
                        $update_stmt->execute();
                        
                        // Add to status history
                        $changed_by_type = 'employee'; // FIX: Use variable
                        $history_stmt = $conn->prepare("
                            INSERT INTO order_status_history 
                            (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                            VALUES (?, ?, ?, ?, ?, NOW())
                        ");
                        $pickup_note = !empty($notes) ? $notes : "Order picked up by customer";
                        $history_stmt->bind_param("iisis", $order_id, $order_status_picked_up, $changed_by_type, $employee_id, $pickup_note);
                        $history_stmt->execute();
                        
                        $conn->commit();
                        setFlashMessage('Order #' . $order_check['order_number'] . ' completed - customer pickup confirmed', 'success');
                    }
                }
                
            } elseif ($action === 'lookup_order') {
                // This will be handled in the lookup section
                $lookup_performed = true;
            }
        } catch (Exception $e) {
            if (isset($conn)) {
                $conn->rollback();
            }
            logError('Counter status update error: ' . $e->getMessage());
            setFlashMessage('Error updating order status. Please try again.', 'error');
        }
    }
}

// Handle order lookup
$lookup_results = [];
$lookup_error = '';
if (isset($_POST['action']) && $_POST['action'] === 'lookup_order') {
    $search_term = sanitizeInput($_POST['search_term'] ?? '');
    $search_type = $_POST['search_type'] ?? 'order_number';
    
    if (!empty($search_term)) {
        try {
            if ($search_type === 'order_number') {
                // Search by order number
                $pickup_order_type = 'pickup'; // FIX: Use variable for string literal
                
                $lookup_stmt = $conn->prepare("
                    SELECT 
                        o.order_id, o.order_number, o.created_at, o.order_status_id,
                        o.total_amount, o.special_instructions, o.estimated_time,
                        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
                        c.phone, c.email,
                        os.status_name
                    FROM orders o
                    JOIN customers c ON o.customer_id = c.customer_id
                    JOIN order_statuses os ON o.order_status_id = os.status_id
                    WHERE o.order_number LIKE ? AND o.location_id = ? AND o.order_type = ?
                    ORDER BY o.created_at DESC
                    LIMIT 5
                ");
                $search_param = '%' . $search_term . '%';
                $lookup_stmt->bind_param("sis", $search_param, $employee_location, $pickup_order_type);
                
            } else {
                // Search by phone number
                $pickup_order_type = 'pickup'; // FIX: Use variable for string literal
                
                $lookup_stmt = $conn->prepare("
                    SELECT 
                        o.order_id, o.order_number, o.created_at, o.order_status_id,
                        o.total_amount, o.special_instructions, o.estimated_time,
                        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
                        c.phone, c.email,
                        os.status_name
                    FROM orders o
                    JOIN customers c ON o.customer_id = c.customer_id
                    JOIN order_statuses os ON o.order_status_id = os.status_id
                    WHERE c.phone LIKE ? AND o.location_id = ? AND o.order_type = ?
                    ORDER BY o.created_at DESC
                    LIMIT 10
                ");
                $search_param = '%' . $search_term . '%';
                $lookup_stmt->bind_param("sis", $search_param, $employee_location, $pickup_order_type);
            }
            
            $lookup_stmt->execute();
            $lookup_results = $lookup_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            if (empty($lookup_results)) {
                $lookup_error = 'No pickup orders found matching your search.';
            }
            
        } catch (Exception $e) {
            logError('Order lookup error: ' . $e->getMessage());
            $lookup_error = 'Error searching for orders. Please try again.';
        }
    } else {
        $lookup_error = 'Please enter a search term.';
    }
}

// Fetch pickup orders that are ready
$order_status_ready = ORDER_STATUS_READY; // FIX: Use variable for constant
$pickup_order_type = 'pickup'; // FIX: Use variable for string literal

$ready_orders_sql = "
    SELECT 
        o.order_id,
        o.order_number,
        o.created_at,
        o.estimated_time,
        o.special_instructions,
        o.total_amount,
        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
        c.phone,
        c.email,
        TIMESTAMPDIFF(MINUTE, o.created_at, NOW()) as minutes_since_order,
        CASE 
            WHEN o.estimated_time IS NOT NULL THEN
                TIMESTAMPDIFF(MINUTE, NOW(), o.estimated_time)
            ELSE NULL
        END as minutes_until_due
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.location_id = ?
    AND o.order_type = ?
    AND o.order_status_id = ?
    ORDER BY o.created_at ASC
";

$stmt = $conn->prepare($ready_orders_sql);
$stmt->bind_param("isi", $employee_location, $pickup_order_type, $order_status_ready);
$stmt->execute();
$ready_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch preparing orders (to show what's coming up)
$order_status_preparing = ORDER_STATUS_PREPARING; // FIX: Use variable for constant

$preparing_orders_sql = "
    SELECT 
        o.order_id,
        o.order_number,
        o.created_at,
        o.estimated_time,
        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
        TIMESTAMPDIFF(MINUTE, o.created_at, NOW()) as minutes_since_order
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.location_id = ?
    AND o.order_type = ?
    AND o.order_status_id = ?
    ORDER BY o.created_at ASC
    LIMIT 10
";

$stmt = $conn->prepare($preparing_orders_sql);
$stmt->bind_param("isi", $employee_location, $pickup_order_type, $order_status_preparing);
$stmt->execute();
$preparing_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch order items for ready orders
foreach ($ready_orders as &$order) {
    $items_stmt = $conn->prepare("
        SELECT 
            oi.item_name,
            oi.quantity,
            oi.item_type
        FROM order_items oi
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id
    ");
    $items_stmt->bind_param("i", $order['order_id']);
    $items_stmt->execute();
    $order['items'] = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Calculate stats
$total_ready = count($ready_orders);
$total_preparing = count($preparing_orders);
$overdue_count = count(array_filter($ready_orders, function($order) {
    return isset($order['minutes_until_due']) && $order['minutes_until_due'] < 0;
}));

// Generate CSRF token
$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Counter Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../../assets/css/main.css">
    <style>
        :root {
            --primary-color: #d63031;
            --primary-dark: #c0392b;
            --text-dark: #2d3436;
            --text-light: #ffffff;
            --gray-light: #f5f6fa;
            --gray-medium: #dfe6e9;
            --gray-dark: #636e72;
            --success-color: #00b894;
            --warning-color: #fdcb6e;
            --danger-color: #ff7675;
            --info-color: #74b9ff;
            --counter-color: #6c5ce7;
            --border-radius: 12px;
            --shadow-light: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-medium: 0 4px 20px rgba(0,0,0,0.15);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: var(--gray-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .counter-header {
            background: linear-gradient(135deg, var(--counter-color) 0%, #5f3dc4 100%);
            color: var(--text-light);
            padding: 20px 0;
            box-shadow: var(--shadow-medium);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .location-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 100px auto 50px;
            padding: 0 20px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray-dark);
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .ready-orders .stat-number { color: var(--success-color); }
        .preparing-orders .stat-number { color: var(--warning-color); }
        .overdue-orders .stat-number { color: var(--danger-color); }
        .store-hours .stat-number { color: var(--info-color); }

        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .orders-section {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .lookup-section {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .section-header {
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .ready-header {
            background: linear-gradient(135deg, var(--success-color) 0%, #00a085 100%);
            color: white;
        }

        .lookup-header {
            background: linear-gradient(135deg, var(--info-color) 0%, #0984e3 100%);
            color: white;
        }

        .pickup-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            overflow: hidden;
            transition: var(--transition);
            border-left: 5px solid var(--success-color);
        }

        .pickup-card.overdue {
            border-left-color: var(--danger-color);
            animation: urgentPulse 2s infinite;
        }

        @keyframes urgentPulse {
            0%, 100% { box-shadow: var(--shadow-light); }
            50% { box-shadow: 0 4px 20px rgba(255, 118, 117, 0.3); }
        }

        .pickup-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }

        .order-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-medium);
        }

        .order-number {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .order-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-dark);
            margin-bottom: 10px;
        }

        .customer-info {
            font-weight: 600;
            color: var(--text-dark);
        }

        .order-time {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .time-overdue {
            color: var(--danger-color);
            font-weight: 600;
        }

        .order-total {
            background: var(--success-color);
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .customer-details {
            background: var(--gray-light);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 20px;
        }

        .details-header {
            font-weight: 600;
            color: var(--counter-color);
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .customer-contact {
            color: var(--text-dark);
            line-height: 1.4;
        }

        .phone-number {
            color: var(--counter-color);
            font-weight: 600;
            margin-top: 5px;
        }

        .order-items {
            padding: 20px;
        }

        .items-header {
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--gray-dark);
        }

        .item-list {
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }

        .special-instructions {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 12px;
            border-radius: 6px;
            margin: 15px 20px;
        }

        .special-instructions h5 {
            color: #856404;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .special-instructions p {
            color: #856404;
            font-size: 0.85rem;
            margin: 0;
        }

        .pickup-actions {
            padding: 20px;
            background: var(--gray-light);
        }

        .action-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .verification-section {
            background: #fff8dc;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .verification-header {
            font-weight: 600;
            color: var(--warning-color);
            margin-bottom: 10px;
        }

        .phone-input {
            width: 100%;
            padding: 10px;
            border: 2px solid var(--gray-medium);
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            text-align: center;
        }

        .phone-input:focus {
            outline: none;
            border-color: var(--counter-color);
        }

        .notes-input {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-medium);
            border-radius: 6px;
            font-size: 0.9rem;
            resize: vertical;
            min-height: 60px;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .counter-btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
        }

        .btn-notify {
            background: var(--info-color);
            color: white;
        }

        .btn-notify:hover {
            background: #0984e3;
            transform: translateY(-1px);
        }

        .btn-complete {
            background: var(--success-color);
            color: white;
        }

        .btn-complete:hover {
            background: #00a085;
            transform: translateY(-1px);
        }

        .order-lookup {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            padding: 25px;
        }

        .lookup-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }

        .search-controls {
            display: flex;
            gap: 10px;
        }

        .search-input {
            flex: 1;
            padding: 12px;
            border: 2px solid var(--gray-medium);
            border-radius: 6px;
            font-size: 1rem;
        }

        .search-input:focus {
            outline: none;
            border-color: var(--info-color);
        }

        .search-type {
            padding: 12px;
            border: 2px solid var(--gray-medium);
            border-radius: 6px;
            background: white;
            min-width: 150px;
        }

        .search-btn {
            background: var(--info-color);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
        }

        .search-btn:hover {
            background: #0984e3;
        }

        .lookup-results {
            margin-top: 20px;
        }

        .result-item {
            border: 1px solid var(--gray-medium);
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 10px;
            background: var(--gray-light);
        }

        .result-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .result-order-number {
            font-weight: 700;
            color: var(--primary-color);
        }

        .result-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-ready {
            background: var(--success-color);
            color: white;
        }

        .status-preparing {
            background: var(--warning-color);
            color: white;
        }

        .status-picked-up {
            background: var(--gray-dark);
            color: white;
        }

        .result-details {
            font-size: 0.9rem;
            color: var(--gray-dark);
        }

        .preparing-queue {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            padding: 25px;
            margin-top: 20px;
        }

        .queue-header {
            background: linear-gradient(135deg, var(--warning-color) 0%, #e17055 100%);
            color: white;
            padding: 15px;
            border-radius: var(--border-radius);
            text-align: center;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .queue-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid var(--gray-light);
        }

        .queue-item:last-child {
            border-bottom: none;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-dark);
        }

        .empty-state h3 {
            margin-bottom: 10px;
        }

        .error-message {
            background: #fff5f5;
            color: var(--danger-color);
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
            border: 1px solid #fed7d7;
        }

        .flash-message {
            position: fixed;
            top: 90px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 25px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 1001;
            box-shadow: var(--shadow-medium);
            animation: slideDown 0.3s ease;
        }

        .flash-success {
            background: var(--success-color);
            color: white;
        }

        .flash-error {
            background: var(--danger-color);
            color: white;
        }

        @keyframes slideDown {
            from { transform: translate(-50%, -100%); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                margin-top: 80px;
                padding: 0 15px;
            }
            
            .header-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
            
            .header-title h1 {
                font-size: 1.5rem;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .order-meta {
                flex-direction: column;
                gap: 5px;
                align-items: flex-start;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .search-controls {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="counter-header">
        <div class="header-content">
            <div class="header-title">
                <h1>🏪 Counter Dashboard</h1>
                <div class="location-badge">
                    📍 <?php echo htmlspecialchars($location['store_name']); ?>
                </div>
            </div>
            <div class="header-actions">
                <div class="user-info">
                    Welcome, <?php echo htmlspecialchars(getCurrentUserName()); ?>
                </div>
                <a href="../../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </header>

    <!-- Flash Messages -->
    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('error')): ?>
    <div class="flash-message flash-error" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <!-- Stats Dashboard -->
        <div class="dashboard-stats">
            <div class="stat-card ready-orders">
                <div class="stat-icon">✅</div>
                <div class="stat-number"><?php echo $total_ready; ?></div>
                <div class="stat-label">Ready for Pickup</div>
            </div>
            
            <div class="stat-card preparing-orders">
                <div class="stat-icon">👨‍🍳</div>
                <div class="stat-number"><?php echo $total_preparing; ?></div>
                <div class="stat-label">Being Prepared</div>
            </div>
            
            <div class="stat-card overdue-orders">
                <div class="stat-icon">⚠️</div>
                <div class="stat-number"><?php echo $overdue_count; ?></div>
                <div class="stat-label">Overdue Orders</div>
            </div>
            
            <div class="stat-card store-hours">
                <div class="stat-icon">🕐</div>
                <div class="stat-number"><?php echo isStoreOpen() ? 'OPEN' : 'CLOSED'; ?></div>
                <div class="stat-label">Store Status</div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Ready Orders Section -->
            <div class="orders-section">
                <div class="section-header ready-header">
                    ✅ Ready for Pickup (<?php echo $total_ready; ?>)
                </div>

                <?php if (empty($ready_orders)): ?>
                <div class="empty-state">
                    <h3>🎉 No orders waiting</h3>
                    <p>All pickup orders have been collected or none are ready yet.</p>
                </div>
                <?php else: ?>
                    <?php foreach ($ready_orders as $order): ?>
                    <?php 
                    $is_overdue = isset($order['minutes_until_due']) && $order['minutes_until_due'] < 0;
                    $card_class = $is_overdue ? 'pickup-card overdue' : 'pickup-card';
                    ?>
                    
                    <div class="<?php echo $card_class; ?>">
                        <!-- Order Header -->
                        <div class="order-header">
                            <div class="order-number">Order #<?php echo htmlspecialchars($order['order_number']); ?></div>
                            <div class="order-meta">
                                <div class="customer-info"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                <div class="order-time <?php echo $is_overdue ? 'time-overdue' : ''; ?>">
                                    ⏰ <?php echo $order['minutes_since_order']; ?> min ago
                                    <?php if ($is_overdue): ?>
                                        <strong>(OVERDUE!)</strong>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="order-total"><?php echo formatPrice($order['total_amount']); ?></div>
                        </div>

                        <!-- Customer Details -->
                        <div class="customer-details">
                            <div class="details-header">
                                👤 Customer Information
                            </div>
                            <div class="customer-contact">
                                <strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?><br>
                                <strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?>
                            </div>
                            <div class="phone-number">
                                📞 <?php echo htmlspecialchars($order['phone']); ?>
                                <small style="color: var(--gray-dark);">(Last 4 digits: <?php echo substr(preg_replace('/[^0-9]/', '', $order['phone']), -4); ?>)</small>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <div class="order-items">
                            <div class="items-header">🍕 Order Items:</div>
                            <div class="item-list">
                                <?php foreach ($order['items'] as $item): ?>
                                <div class="item">
                                    <span><?php echo $item['quantity']; ?>x <?php echo htmlspecialchars($item['item_name']); ?></span>
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        <span class="badge" style="background: var(--counter-color); color: white; padding: 2px 6px; border-radius: 10px; font-size: 0.7rem;">Custom</span>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Special Instructions -->
                        <?php if (!empty($order['special_instructions'])): ?>
                        <div class="special-instructions">
                            <h5>📝 Special Instructions:</h5>
                            <p><?php echo htmlspecialchars($order['special_instructions']); ?></p>
                        </div>
                        <?php endif; ?>

                        <!-- Actions -->
                        <div class="pickup-actions">
                            <!-- Notify Customer Form -->
                            <form method="POST" class="action-form" style="margin-bottom: 20px;">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="mark_ready_pickup">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                
                                <textarea name="notes" class="notes-input" placeholder="Optional notification message..."></textarea>
                                
                                <div class="action-buttons">
                                    <button type="submit" class="counter-btn btn-notify">
                                        📱 Notify Customer
                                    </button>
                                </div>
                            </form>

                            <!-- Complete Pickup Form -->
                            <form method="POST" class="action-form">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="complete_pickup">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                
                                <div class="verification-section">
                                    <div class="verification-header">🔐 Customer Verification Required</div>
                                    <label for="phone_<?php echo $order['order_id']; ?>" style="font-size: 0.9rem; color: var(--gray-dark); margin-bottom: 5px; display: block;">
                                        Ask customer for last 4 digits of phone number:
                                    </label>
                                    <input type="text" 
                                           id="phone_<?php echo $order['order_id']; ?>"
                                           name="customer_phone" 
                                           class="phone-input" 
                                           placeholder="XXXX"
                                           pattern="[0-9]{4}"
                                           maxlength="4"
                                           required>
                                </div>
                                
                                <textarea name="notes" class="notes-input" placeholder="Pickup completion notes (optional)..."></textarea>
                                
                                <div class="action-buttons">
                                    <button type="submit" class="counter-btn btn-complete">
                                        ✅ Complete Pickup
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Lookup & Queue Section -->
            <div class="lookup-section">
                <!-- Order Lookup -->
                <div class="section-header lookup-header">
                    🔍 Order Lookup
                </div>
                
                <div class="order-lookup">
                    <form method="POST" class="lookup-form">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" name="action" value="lookup_order">
                        
                        <div class="search-controls">
                            <input type="text" 
                                   name="search_term" 
                                   class="search-input" 
                                   placeholder="Enter order number or phone number..."
                                   value="<?php echo isset($_POST['search_term']) ? htmlspecialchars($_POST['search_term']) : ''; ?>"
                                   required>
                            
                            <select name="search_type" class="search-type">
                                <option value="order_number" <?php echo (isset($_POST['search_type']) && $_POST['search_type'] === 'order_number') ? 'selected' : ''; ?>>
                                    Order Number
                                </option>
                                <option value="phone" <?php echo (isset($_POST['search_type']) && $_POST['search_type'] === 'phone') ? 'selected' : ''; ?>>
                                    Phone Number
                                </option>
                            </select>
                            
                            <button type="submit" class="search-btn">🔍 Search</button>
                        </div>
                    </form>

                    <!-- Lookup Results -->
                    <?php if (!empty($lookup_error)): ?>
                        <div class="error-message">
                            <?php echo htmlspecialchars($lookup_error); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($lookup_results)): ?>
                        <div class="lookup-results">
                            <h4 style="margin-bottom: 15px; color: var(--info-color);">Search Results:</h4>
                            <?php foreach ($lookup_results as $result): ?>
                                <div class="result-item">
                                    <div class="result-header">
                                        <span class="result-order-number">
                                            Order #<?php echo htmlspecialchars($result['order_number']); ?>
                                        </span>
                                        <span class="result-status status-<?php echo strtolower(str_replace(' ', '-', $result['status_name'])); ?>">
                                            <?php echo htmlspecialchars($result['status_name']); ?>
                                        </span>
                                    </div>
                                    <div class="result-details">
                                        <strong><?php echo htmlspecialchars($result['customer_name']); ?></strong><br>
                                        📞 <?php echo htmlspecialchars($result['phone']); ?><br>
                                        💰 <?php echo formatPrice($result['total_amount']); ?> • 
                                        📅 <?php echo date('M j, g:i A', strtotime($result['created_at'])); ?>
                                        <?php if ($result['estimated_time']): ?>
                                            <br>⏰ Est. pickup: <?php echo date('g:i A', strtotime($result['estimated_time'])); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Preparing Queue -->
                <div class="preparing-queue">
                    <div class="queue-header">
                        👨‍🍳 Currently Being Prepared (<?php echo $total_preparing; ?>)
                    </div>
                    
                    <?php if (empty($preparing_orders)): ?>
                        <div class="empty-state">
                            <h4>No orders being prepared</h4>
                            <p>Kitchen is ready for new orders!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($preparing_orders as $prep_order): ?>
                            <div class="queue-item">
                                <div>
                                    <strong>Order #<?php echo htmlspecialchars($prep_order['order_number']); ?></strong><br>
                                    <span style="color: var(--gray-dark); font-size: 0.9rem;">
                                        <?php echo htmlspecialchars($prep_order['customer_name']); ?>
                                    </span>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 0.9rem; color: var(--warning-color); font-weight: 600;">
                                        <?php echo $prep_order['minutes_since_order']; ?> min
                                    </div>
                                    <?php if ($prep_order['estimated_time']): ?>
                                        <div style="font-size: 0.8rem; color: var(--gray-dark);">
                                            ETA: <?php echo date('g:i A', strtotime($prep_order['estimated_time'])); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Store Information -->
        <div style="background: white; border-radius: var(--border-radius); box-shadow: var(--shadow-light); padding: 25px; margin-top: 30px;">
            <h3 style="color: var(--counter-color); margin-bottom: 15px; text-align: center;">
                🏪 Store Information
            </h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; text-align: center;">
                <div>
                    <strong>📍 Address</strong><br>
                    <?php echo htmlspecialchars($location['address']); ?><br>
                    <?php echo htmlspecialchars($location['city']); ?>
                </div>
                <div>
                    <strong>📞 Phone</strong><br>
                    <?php echo htmlspecialchars($location['phone']); ?>
                </div>
                <div>
                    <strong>🕐 Hours</strong><br>
                    <?php echo OPENING_HOUR; ?>:00 AM - <?php echo CLOSING_HOUR - 12; ?>:00 PM<br>
                    Daily
                </div>
                <div>
                    <strong>⏱️ Pickup Time</strong><br>
                    ~<?php echo ESTIMATED_PREP_TIME; ?> minutes<br>
                    from order placement
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-refresh every 45 seconds (slower than kitchen/delivery)
        let refreshInterval;
        let isPageVisible = true;

        function startAutoRefresh() {
            refreshInterval = setInterval(() => {
                if (isPageVisible) {
                    // Check if any forms have active input before refreshing
                    const activeElement = document.activeElement;
                    const isFormActive = activeElement && (
                        activeElement.tagName === 'TEXTAREA' || 
                        activeElement.tagName === 'INPUT' ||
                        activeElement.tagName === 'BUTTON'
                    );
                    
                    if (!isFormActive) {
                        location.reload();
                    }
                }
            }, 45000); // 45 seconds
        }

        // Handle page visibility changes
        document.addEventListener('visibilitychange', function() {
            isPageVisible = !document.hidden;
            
            if (isPageVisible) {
                startAutoRefresh();
            } else {
                clearInterval(refreshInterval);
            }
        });

        // Phone input formatting and validation
        const phoneInputs = document.querySelectorAll('.phone-input');
        phoneInputs.forEach(input => {
            input.addEventListener('input', function() {
                // Only allow numbers
                this.value = this.value.replace(/[^0-9]/g, '').substring(0, 4);
                
                // Add visual feedback for 4 digits
                if (this.value.length === 4) {
                    this.style.backgroundColor = '#d4edda';
                    this.style.borderColor = 'var(--success-color)';
                } else {
                    this.style.backgroundColor = '';
                    this.style.borderColor = 'var(--gray-medium)';
                }
            });

            // Auto-focus next element when 4 digits entered
            input.addEventListener('keyup', function() {
                if (this.value.length === 4) {
                    const nextElement = this.closest('form').querySelector('button[type="submit"]');
                    if (nextElement) {
                        nextElement.focus();
                    }
                }
            });
        });

        // Form submission enhancements
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    const originalText = submitBtn.textContent;
                    submitBtn.disabled = true;
                    submitBtn.style.opacity = '0.7';
                    
                    // Add loading indicator based on action
                    if (submitBtn.classList.contains('btn-complete')) {
                        submitBtn.textContent = '⏳ Verifying...';
                    } else if (submitBtn.classList.contains('btn-notify')) {
                        submitBtn.textContent = '📱 Sending...';
                    } else {
                        submitBtn.textContent = 'Processing...';
                    }
                    
                    // Reset if form fails to submit
                    setTimeout(() => {
                        submitBtn.disabled = false;
                        submitBtn.style.opacity = '1';
                        submitBtn.textContent = originalText;
                    }, 5000);
                }
            });
        });

        // Auto-hide flash messages
        const flashMessage = document.getElementById('flashMessage');
        if (flashMessage) {
            setTimeout(() => {
                flashMessage.style.opacity = '0';
                setTimeout(() => flashMessage.remove(), 300);
            }, 5000);
        }

        // Add confirmation for pickup completion
        const completeButtons = document.querySelectorAll('.btn-complete');
        completeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                const phoneInput = this.closest('form').querySelector('.phone-input');
                if (phoneInput && phoneInput.value.length !== 4) {
                    e.preventDefault();
                    alert('Please enter the 4-digit phone verification code first.');
                    phoneInput.focus();
                    return false;
                }
                
                if (!confirm('Are you sure you want to mark this order as picked up? This action cannot be undone.')) {
                    e.preventDefault();
                    return false;
                }
            });
        });

        // Start auto-refresh
        startAutoRefresh();
    });
    </script>
</body>
</html>