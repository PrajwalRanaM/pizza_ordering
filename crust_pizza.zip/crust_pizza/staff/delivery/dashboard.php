<?php
// staff/delivery/dashboard.php - Fixed Delivery Staff Dashboard
require_once '../../includes/init.php';

// Check if user is logged in and is delivery staff
if (!isLoggedIn() || !isEmployee()) {
    setFlashMessage('Please login with your staff credentials.', 'warning');
    redirect('../login.php');
}

// Check if user has delivery staff role
if (!hasRole('Delivery Staff')) {
    setFlashMessage('Access denied. Delivery staff only.', 'error');
    redirect('../../index.php');
}

// Get employee details
$employee_id = getCurrentUserId();
$employee_location = getUserLocation($conn);

// Get location details
$location_stmt = $conn->prepare("SELECT store_name, city, address, phone FROM locations WHERE location_id = ?");
$location_stmt->bind_param("i", $employee_location);
$location_stmt->execute();
$location = $location_stmt->get_result()->fetch_assoc();

// Handle status updates and delivery assignments
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $order_id = $_POST['order_id'] ?? 0;
    $notes = sanitizeInput($_POST['notes'] ?? '');
    
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('Invalid form submission. Please try again.', 'error');
    } else {
        try {
            if ($action === 'assign_delivery') {
                // Assign delivery order to this driver
                $order_status_ready = ORDER_STATUS_READY;  // FIX: Store in variable
                
                $verify_stmt = $conn->prepare("
                    SELECT order_id, order_number, delivery_address, delivery_city 
                    FROM orders 
                    WHERE order_id = ? AND location_id = ? 
                    AND order_status_id = ? AND order_type = 'delivery'
                ");
                $verify_stmt->bind_param("iii", $order_id, $employee_location, $order_status_ready);
                $verify_stmt->execute();
                $order_check = $verify_stmt->get_result()->fetch_assoc();
                
                if (!$order_check) {
                    setFlashMessage('Order not found or cannot be assigned.', 'error');
                } else {
                    $conn->begin_transaction();
                    
                    // Update order status to "Out for Delivery"
                    $order_status_out_for_delivery = ORDER_STATUS_OUT_FOR_DELIVERY;  // FIX: Store in variable
                    $update_stmt = $conn->prepare("
                        UPDATE orders 
                        SET order_status_id = ?, updated_at = NOW() 
                        WHERE order_id = ?
                    ");
                    $update_stmt->bind_param("ii", $order_status_out_for_delivery, $order_id);
                    $update_stmt->execute();
                    
                    // Create delivery assignment
                    $assign_stmt = $conn->prepare("
                        INSERT INTO delivery_assignments 
                        (order_id, employee_id, assigned_at, delivery_status)
                        VALUES (?, ?, NOW(), 'assigned')
                    ");
                    $assign_stmt->bind_param("ii", $order_id, $employee_id);
                    $assign_stmt->execute();
                    
                    // Add to status history
                    $history_stmt = $conn->prepare("
                        INSERT INTO order_status_history 
                        (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                        VALUES (?, ?, 'employee', ?, ?, NOW())
                    ");
                    $departure_note = "Order assigned to delivery driver";
                    $changed_by_type = 'employee';  // FIX: Store literal in variable
                    $history_stmt->bind_param("iisiss", $order_id, $order_status_out_for_delivery, $changed_by_type, $employee_id, $departure_note);
                    $history_stmt->execute();
                    
                    $conn->commit();
                    setFlashMessage('Order #' . $order_check['order_number'] . ' assigned for delivery', 'success');
                }
                
            } elseif ($action === 'depart_delivery') {
                // Mark as departed for delivery
                $delivery_status_assigned = 'assigned';  // FIX: Store literal in variable
                
                $verify_stmt = $conn->prepare("
                    SELECT da.assignment_id, o.order_number 
                    FROM delivery_assignments da
                    JOIN orders o ON da.order_id = o.order_id
                    WHERE da.order_id = ? AND da.employee_id = ? 
                    AND da.delivery_status = ?
                ");
                $verify_stmt->bind_param("iis", $order_id, $employee_id, $delivery_status_assigned);
                $verify_stmt->execute();
                $assignment_check = $verify_stmt->get_result()->fetch_assoc();
                
                if (!$assignment_check) {
                    setFlashMessage('Delivery assignment not found.', 'error');
                } else {
                    // Update delivery assignment
                    $delivery_status_departed = 'departed';  // FIX: Store literal in variable
                    $update_stmt = $conn->prepare("
                        UPDATE delivery_assignments 
                        SET departed_at = NOW(), delivery_status = ?
                        WHERE assignment_id = ?
                    ");
                    $update_stmt->bind_param("si", $delivery_status_departed, $assignment_check['assignment_id']);
                    $update_stmt->execute();
                    
                    // Add to status history
                    $order_status_out_for_delivery = ORDER_STATUS_OUT_FOR_DELIVERY;  // FIX: Store in variable
                    $history_stmt = $conn->prepare("
                        INSERT INTO order_status_history 
                        (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                        VALUES (?, ?, 'employee', ?, ?, NOW())
                    ");
                    $departure_note = !empty($notes) ? $notes : "Driver departed for delivery";
                    $changed_by_type = 'employee';  // FIX: Store literal in variable
                    $history_stmt->bind_param("iisis", $order_id, $order_status_out_for_delivery, $changed_by_type, $employee_id, $departure_note);
                    $history_stmt->execute();
                    
                    setFlashMessage('Marked as departed for delivery', 'success');
                }
                
            } elseif ($action === 'complete_delivery') {
                // Mark delivery as completed
                $delivery_status_assigned = 'assigned';  // FIX: Store literal in variable
                $delivery_status_departed = 'departed';   // FIX: Store literal in variable
                
                $verify_stmt = $conn->prepare("
                    SELECT da.assignment_id, o.order_number 
                    FROM delivery_assignments da
                    JOIN orders o ON da.order_id = o.order_id
                    WHERE da.order_id = ? AND da.employee_id = ? 
                    AND da.delivery_status IN (?, ?)
                ");
                $verify_stmt->bind_param("iiss", $order_id, $employee_id, $delivery_status_assigned, $delivery_status_departed);
                $verify_stmt->execute();
                $assignment_check = $verify_stmt->get_result()->fetch_assoc();
                
                if (!$assignment_check) {
                    setFlashMessage('Delivery assignment not found.', 'error');
                } else {
                    $conn->begin_transaction();
                    
                    // Update order status to delivered
                    $order_status_delivered = ORDER_STATUS_DELIVERED;  // FIX: Store in variable
                    $update_order_stmt = $conn->prepare("
                        UPDATE orders 
                        SET order_status_id = ?, updated_at = NOW() 
                        WHERE order_id = ?
                    ");
                    $update_order_stmt->bind_param("ii", $order_status_delivered, $order_id);
                    $update_order_stmt->execute();
                    
                    // Update delivery assignment
                    $delivery_status_delivered = 'delivered';  // FIX: Store literal in variable
                    $update_delivery_stmt = $conn->prepare("
                        UPDATE delivery_assignments 
                        SET delivered_at = NOW(), delivery_status = ?
                        WHERE assignment_id = ?
                    ");
                    $update_delivery_stmt->bind_param("si", $delivery_status_delivered, $assignment_check['assignment_id']);
                    $update_delivery_stmt->execute();
                    
                    // Add to status history
                    $history_stmt = $conn->prepare("
                        INSERT INTO order_status_history 
                        (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                        VALUES (?, ?, 'employee', ?, ?, NOW())
                    ");
                    $delivery_note = !empty($notes) ? $notes : "Order delivered successfully";
                    $changed_by_type = 'employee';  // FIX: Store literal in variable
                    $history_stmt->bind_param("iisis", $order_id, $order_status_delivered, $changed_by_type, $employee_id, $delivery_note);
                    $history_stmt->execute();
                    
                    $conn->commit();
                    setFlashMessage('Order #' . $assignment_check['order_number'] . ' marked as delivered', 'success');
                }
                
            } elseif ($action === 'delivery_failed') {
                // Mark delivery as failed
                $failure_reason = sanitizeInput($_POST['failure_reason'] ?? '');
                
                if (empty($failure_reason)) {
                    setFlashMessage('Please provide a reason for delivery failure.', 'error');
                } else {
                    $delivery_status_assigned = 'assigned';  // FIX: Store literal in variable
                    $delivery_status_departed = 'departed';   // FIX: Store literal in variable
                    
                    $verify_stmt = $conn->prepare("
                        SELECT da.assignment_id, o.order_number 
                        FROM delivery_assignments da
                        JOIN orders o ON da.order_id = o.order_id
                        WHERE da.order_id = ? AND da.employee_id = ? 
                        AND da.delivery_status IN (?, ?)
                    ");
                    $verify_stmt->bind_param("iiss", $order_id, $employee_id, $delivery_status_assigned, $delivery_status_departed);
                    $verify_stmt->execute();
                    $assignment_check = $verify_stmt->get_result()->fetch_assoc();
                    
                    if (!$assignment_check) {
                        setFlashMessage('Delivery assignment not found.', 'error');
                    } else {
                        $conn->begin_transaction();
                        
                        // Update order status to failed
                        $order_status_failed = ORDER_STATUS_FAILED;  // FIX: Store in variable
                        $update_order_stmt = $conn->prepare("
                            UPDATE orders 
                            SET order_status_id = ?, updated_at = NOW() 
                            WHERE order_id = ?
                        ");
                        $update_order_stmt->bind_param("ii", $order_status_failed, $order_id);
                        $update_order_stmt->execute();
                        
                        // Update delivery assignment
                        $delivery_status_failed = 'failed';  // FIX: Store literal in variable
                        $update_delivery_stmt = $conn->prepare("
                            UPDATE delivery_assignments 
                            SET delivery_status = ?, failure_reason = ?
                            WHERE assignment_id = ?
                        ");
                        $update_delivery_stmt->bind_param("ssi", $delivery_status_failed, $failure_reason, $assignment_check['assignment_id']);
                        $update_delivery_stmt->execute();
                        
                        // Add to status history
                        $history_stmt = $conn->prepare("
                            INSERT INTO order_status_history 
                            (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                            VALUES (?, ?, 'employee', ?, ?, NOW())
                        ");
                        $failure_note = "Delivery failed: " . $failure_reason;
                        $changed_by_type = 'employee';  // FIX: Store literal in variable
                        $history_stmt->bind_param("iisis", $order_id, $order_status_failed, $changed_by_type, $employee_id, $failure_note);
                        $history_stmt->execute();
                        
                        $conn->commit();
                        setFlashMessage('Order #' . $assignment_check['order_number'] . ' marked as delivery failed', 'success');
                    }
                }
            }
        } catch (Exception $e) {
            $conn->rollback();
            logError('Delivery status update error: ' . $e->getMessage());
            setFlashMessage('Error updating delivery status. Please try again.', 'error');
        }
    }
}

// Fetch available delivery orders (ready for pickup)
$order_status_ready = ORDER_STATUS_READY;  // FIX: Store in variable for bind_param
$delivery_type = 'delivery';               // FIX: Store literal in variable

$available_orders_sql = "
    SELECT 
        o.order_id,
        o.order_number,
        o.created_at,
        o.estimated_time,
        o.delivery_address,
        o.delivery_city,
        o.delivery_state,
        o.delivery_postal_code,
        o.special_instructions,
        o.total_amount,
        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
        c.phone,
        TIMESTAMPDIFF(MINUTE, o.created_at, NOW()) as minutes_since_order
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    WHERE o.location_id = ?
    AND o.order_type = ?
    AND o.order_status_id = ?
    ORDER BY o.created_at ASC
";

$stmt = $conn->prepare($available_orders_sql);
$stmt->bind_param("isi", $employee_location, $delivery_type, $order_status_ready);
$stmt->execute();
$available_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch assigned delivery orders for this driver
$order_status_out_for_delivery = ORDER_STATUS_OUT_FOR_DELIVERY;  // FIX: Store in variable
$delivery_status_assigned = 'assigned';  // FIX: Store literal in variable
$delivery_status_departed = 'departed';   // FIX: Store literal in variable

$assigned_orders_sql = "
    SELECT 
        o.order_id,
        o.order_number,
        o.created_at,
        o.estimated_time,
        o.delivery_address,
        o.delivery_city,
        o.delivery_state,
        o.delivery_postal_code,
        o.special_instructions,
        o.total_amount,
        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
        c.phone,
        da.assigned_at,
        da.departed_at,
        da.delivery_status,
        TIMESTAMPDIFF(MINUTE, da.assigned_at, NOW()) as minutes_since_assigned
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    JOIN delivery_assignments da ON o.order_id = da.order_id
    WHERE o.location_id = ?
    AND da.employee_id = ?
    AND o.order_status_id = ?
    AND da.delivery_status IN (?, ?)
    ORDER BY da.assigned_at ASC
";

$stmt = $conn->prepare($assigned_orders_sql);
$stmt->bind_param("iiiss", $employee_location, $employee_id, $order_status_out_for_delivery, $delivery_status_assigned, $delivery_status_departed);
$stmt->execute();
$assigned_orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch order items for all orders
function fetchOrderItems($conn, $orders) {
    foreach ($orders as &$order) {
        $items_stmt = $conn->prepare("
            SELECT item_name, quantity, item_type
            FROM order_items 
            WHERE order_id = ?
            ORDER BY order_item_id
        ");
        $items_stmt->bind_param("i", $order['order_id']);
        $items_stmt->execute();
        $order['items'] = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    return $orders;
}

$available_orders = fetchOrderItems($conn, $available_orders);
$assigned_orders = fetchOrderItems($conn, $assigned_orders);

// Calculate delivery stats
$total_available = count($available_orders);
$total_assigned = count($assigned_orders);

// Generate CSRF token
$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../../assets/css/main.css">
    <style>
        :root {
            --primary-color: #d63031;
            --primary-dark: #c0392b;
            --text-dark: #2d3436;
            --text-light: #ffffff;
            --gray-light: #f5f6fa;
            --gray-medium: #dfe6e9;
            --gray-dark: #636e72;
            --success-color: #00b894;
            --warning-color: #fdcb6e;
            --danger-color: #ff7675;
            --info-color: #74b9ff;
            --delivery-color: #0984e3;
            --border-radius: 12px;
            --shadow-light: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-medium: 0 4px 20px rgba(0,0,0,0.15);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: var(--gray-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .delivery-header {
            background: linear-gradient(135deg, var(--delivery-color) 0%, #0984e3 100%);
            color: var(--text-light);
            padding: 20px 0;
            box-shadow: var(--shadow-medium);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .location-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 100px auto 50px;
            padding: 0 20px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray-dark);
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .available-orders .stat-number { color: var(--warning-color); }
        .assigned-orders .stat-number { color: var(--delivery-color); }
        .avg-time .stat-number { color: var(--success-color); }
        .store-location .stat-number { color: var(--info-color); }

        .orders-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .orders-column {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .column-header {
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .available-header {
            background: linear-gradient(135deg, var(--warning-color) 0%, #e17055 100%);
            color: white;
        }

        .assigned-header {
            background: linear-gradient(135deg, var(--delivery-color) 0%, #0984e3 100%);
            color: white;
        }

        .delivery-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            overflow: hidden;
            transition: var(--transition);
            border-left: 5px solid var(--gray-medium);
        }

        .delivery-card.available {
            border-left-color: var(--warning-color);
        }

        .delivery-card.assigned {
            border-left-color: var(--delivery-color);
        }

        .delivery-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }

        .order-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-medium);
        }

        .order-number {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .order-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-dark);
            margin-bottom: 10px;
        }

        .customer-info {
            font-weight: 600;
            color: var(--text-dark);
        }

        .order-time {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .order-total {
            background: var(--success-color);
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .delivery-address {
            background: var(--gray-light);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 20px;
        }

        .address-header {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .address-details {
            color: var(--text-dark);
            line-height: 1.4;
        }

        .phone-number {
            color: var(--delivery-color);
            font-weight: 600;
            margin-top: 5px;
        }

        .order-items {
            padding: 20px;
        }

        .items-header {
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--gray-dark);
        }

        .item-list {
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }

        .special-instructions {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 12px;
            border-radius: 6px;
            margin: 15px 20px;
        }

        .special-instructions h5 {
            color: #856404;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .special-instructions p {
            color: #856404;
            font-size: 0.85rem;
            margin: 0;
        }

        .delivery-actions {
            padding: 20px;
            background: var(--gray-light);
        }

        .action-form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .notes-input {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-medium);
            border-radius: 6px;
            font-size: 0.9rem;
            resize: vertical;
            min-height: 60px;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .delivery-btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
        }

        .btn-assign {
            background: var(--delivery-color);
            color: white;
        }

        .btn-assign:hover {
            background: #0984e3;
            transform: translateY(-1px);
        }

        .btn-depart {
            background: var(--info-color);
            color: white;
        }

        .btn-depart:hover {
            background: #74b9ff;
            transform: translateY(-1px);
        }

        .btn-complete {
            background: var(--success-color);
            color: white;
        }

        .btn-complete:hover {
            background: #00a085;
            transform: translateY(-1px);
        }

        .btn-failed {
            background: var(--danger-color);
            color: white;
        }

        .btn-failed:hover {
            background: #e84393;
            transform: translateY(-1px);
        }

        .delivery-status {
            text-align: center;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 6px;
            font-weight: 600;
        }

        .status-assigned {
            background: #e3f2fd;
            color: #1976d2;
        }

        .status-departed {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-dark);
        }

        .empty-state h3 {
            margin-bottom: 10px;
        }

        .failure-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .failure-modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: var(--border-radius);
            max-width: 500px;
            width: 90%;
            box-shadow: var(--shadow-medium);
        }

        .modal-header {
            margin-bottom: 20px;
        }

        .modal-header h3 {
            color: var(--danger-color);
            margin-bottom: 10px;
        }

        .failure-reasons {
            display: grid;
            gap: 10px;
            margin: 20px 0;
        }

        .failure-reason {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            border: 1px solid var(--gray-medium);
            border-radius: 6px;
            cursor: pointer;
            transition: var(--transition);
        }

        .failure-reason:hover {
            background: var(--gray-light);
        }

        .failure-reason input[type="radio"] {
            margin: 0;
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
        }

        .btn-cancel {
            background: var(--gray-medium);
            color: var(--text-dark);
        }

        .btn-confirm {
            background: var(--danger-color);
            color: white;
        }

        .flash-message {
            position: fixed;
            top: 90px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 25px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 1001;
            box-shadow: var(--shadow-medium);
            animation: slideDown 0.3s ease;
        }

        .flash-success {
            background: var(--success-color);
            color: white;
        }

        .flash-error {
            background: var(--danger-color);
            color: white;
        }

        @keyframes slideDown {
            from { transform: translate(-50%, -100%); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
        }

        .refresh-indicator {
            position: fixed;
            top: 90px;
            right: 20px;
            background: var(--success-color);
            color: white;
            padding: 10px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            z-index: 1001;
            display: none;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .orders-section {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                margin-top: 80px;
                padding: 0 15px;
            }
            
            .header-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
            
            .header-title h1 {
                font-size: 1.5rem;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .order-meta {
                flex-direction: column;
                gap: 5px;
                align-items: flex-start;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="delivery-header">
        <div class="header-content">
            <div class="header-title">
                <h1>🚚 Delivery Dashboard</h1>
                <div class="location-badge">
                    📍 <?php echo htmlspecialchars($location['store_name']); ?>
                </div>
            </div>
            <div class="header-actions">
                <div class="user-info">
                    Welcome, <?php echo htmlspecialchars(getCurrentUserName()); ?>
                </div>
                <a href="../../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </header>

    <!-- Flash Messages -->
    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('error')): ?>
    <div class="flash-message flash-error" id="flashMessage">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Auto-refresh indicator -->
    <div class="refresh-indicator" id="refreshIndicator">
        🔄 Auto-refreshing...
    </div>

    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <!-- Stats Dashboard -->
        <div class="dashboard-stats">
            <div class="stat-card available-orders">
                <div class="stat-icon">📦</div>
                <div class="stat-number"><?php echo $total_available; ?></div>
                <div class="stat-label">Available Orders</div>
            </div>
            
            <div class="stat-card assigned-orders">
                <div class="stat-icon">🚚</div>
                <div class="stat-number"><?php echo $total_assigned; ?></div>
                <div class="stat-label">My Deliveries</div>
            </div>
            
            <div class="stat-card avg-time">
                <div class="stat-icon">⏱️</div>
                <div class="stat-number"><?php echo ESTIMATED_DELIVERY_TIME; ?></div>
                <div class="stat-label">Avg Delivery (min)</div>
            </div>
            
            <div class="stat-card store-location">
                <div class="stat-icon">🏪</div>
                <div class="stat-number"><?php echo htmlspecialchars($location['city']); ?></div>
                <div class="stat-label">Store Location</div>
            </div>
        </div>

        <!-- Orders Section -->
        <div class="orders-section">
            <!-- Available Orders Column -->
            <div class="orders-column">
                <div class="column-header available-header">
                    📦 Ready for Delivery (<?php echo $total_available; ?>)
                </div>

                <?php if (empty($available_orders)): ?>
                <div class="empty-state">
                    <h3>🎉 No orders waiting</h3>
                    <p>All delivery orders have been assigned. Check back soon!</p>
                </div>
                <?php else: ?>
                    <?php foreach ($available_orders as $order): ?>
                    <div class="delivery-card available">
                        <!-- Order Header -->
                        <div class="order-header">
                            <div class="order-number">Order #<?php echo htmlspecialchars($order['order_number']); ?></div>
                            <div class="order-meta">
                                <div class="customer-info"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                <div class="order-time">
                                    ⏰ <?php echo $order['minutes_since_order']; ?> min ago
                                </div>
                            </div>
                            <div class="order-total"><?php echo formatPrice($order['total_amount']); ?></div>
                        </div>

                        <!-- Delivery Address -->
                        <div class="delivery-address">
                            <div class="address-header">
                                📍 Delivery Address
                            </div>
                            <div class="address-details">
                                <?php echo htmlspecialchars($order['delivery_address']); ?><br>
                                <?php echo htmlspecialchars($order['delivery_city'] . ', ' . $order['delivery_state'] . ' ' . $order['delivery_postal_code']); ?>
                            </div>
                            <div class="phone-number">
                                📞 <?php echo htmlspecialchars($order['phone']); ?>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <div class="order-items">
                            <div class="items-header">🍕 Order Items:</div>
                            <div class="item-list">
                                <?php foreach ($order['items'] as $item): ?>
                                <div class="item">
                                    <span><?php echo $item['quantity']; ?>x <?php echo htmlspecialchars($item['item_name']); ?></span>
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        <span class="badge">Custom</span>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Special Instructions -->
                        <?php if (!empty($order['special_instructions'])): ?>
                        <div class="special-instructions">
                            <h5>📝 Special Instructions:</h5>
                            <p><?php echo htmlspecialchars($order['special_instructions']); ?></p>
                        </div>
                        <?php endif; ?>

                        <!-- Actions -->
                        <div class="delivery-actions">
                            <form method="POST" class="action-form">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="action" value="assign_delivery">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                
                                <div class="action-buttons">
                                    <button type="submit" class="delivery-btn btn-assign">
                                        🚚 Take This Delivery
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Assigned Orders Column -->
            <div class="orders-column">
                <div class="column-header assigned-header">
                    🚚 My Deliveries (<?php echo $total_assigned; ?>)
                </div>

                <?php if (empty($assigned_orders)): ?>
                <div class="empty-state">
                    <h3>📝 No active deliveries</h3>
                    <p>You don't have any assigned deliveries right now.</p>
                </div>
                <?php else: ?>
                    <?php foreach ($assigned_orders as $order): ?>
                    <div class="delivery-card assigned">
                        <!-- Order Header -->
                        <div class="order-header">
                            <div class="order-number">Order #<?php echo htmlspecialchars($order['order_number']); ?></div>
                            <div class="order-meta">
                                <div class="customer-info"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                <div class="order-time">
                                    ⏰ Assigned <?php echo $order['minutes_since_assigned']; ?> min ago
                                </div>
                            </div>
                            <div class="order-total"><?php echo formatPrice($order['total_amount']); ?></div>
                        </div>

                        <!-- Delivery Status -->
                        <div class="delivery-status status-<?php echo $order['delivery_status']; ?>">
                            <?php if ($order['delivery_status'] === 'assigned'): ?>
                                🏠 Ready to Depart
                            <?php elseif ($order['delivery_status'] === 'departed'): ?>
                                🚗 En Route to Customer
                            <?php endif; ?>
                        </div>

                        <!-- Delivery Address -->
                        <div class="delivery-address">
                            <div class="address-header">
                                📍 Delivery Address
                            </div>
                            <div class="address-details">
                                <?php echo htmlspecialchars($order['delivery_address']); ?><br>
                                <?php echo htmlspecialchars($order['delivery_city'] . ', ' . $order['delivery_state'] . ' ' . $order['delivery_postal_code']); ?>
                            </div>
                            <div class="phone-number">
                                📞 <?php echo htmlspecialchars($order['phone']); ?>
                            </div>
                        </div>

                        <!-- Order Items -->
                        <div class="order-items">
                            <div class="items-header">🍕 Order Items:</div>
                            <div class="item-list">
                                <?php foreach ($order['items'] as $item): ?>
                                <div class="item">
                                    <span><?php echo $item['quantity']; ?>x <?php echo htmlspecialchars($item['item_name']); ?></span>
                                    <?php if ($item['item_type'] === 'custom'): ?>
                                        <span class="badge">Custom</span>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Special Instructions -->
                        <?php if (!empty($order['special_instructions'])): ?>
                        <div class="special-instructions">
                            <h5>📝 Special Instructions:</h5>
                            <p><?php echo htmlspecialchars($order['special_instructions']); ?></p>
                        </div>
                        <?php endif; ?>

                        <!-- Actions -->
                        <div class="delivery-actions">
                            <form method="POST" class="action-form">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                
                                <textarea name="notes" class="notes-input" placeholder="Add delivery notes (optional)..."></textarea>
                                
                                <div class="action-buttons">
                                    <?php if ($order['delivery_status'] === 'assigned'): ?>
                                        <button type="submit" name="action" value="depart_delivery" class="delivery-btn btn-depart">
                                            🚗 Mark as Departed
                                        </button>
                                    <?php endif; ?>
                                    
                                    <button type="submit" name="action" value="complete_delivery" class="delivery-btn btn-complete">
                                        ✅ Mark as Delivered
                                    </button>
                                    
                                    <button type="button" class="delivery-btn btn-failed" onclick="showFailureModal(<?php echo $order['order_id']; ?>)">
                                        ❌ Delivery Failed
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Delivery Failure Modal -->
    <div class="failure-modal" id="failureModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>⚠️ Mark Delivery as Failed</h3>
                <p>Please select a reason for the failed delivery:</p>
            </div>
            
            <form method="POST" id="failureForm">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="hidden" name="action" value="delivery_failed">
                <input type="hidden" name="order_id" id="failureOrderId" value="">
                
                <div class="failure-reasons">
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Customer not available" required>
                        <span>Customer not available</span>
                    </label>
                    
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Incorrect address" required>
                        <span>Incorrect or incomplete address</span>
                    </label>
                    
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Customer refused delivery" required>
                        <span>Customer refused delivery</span>
                    </label>
                    
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Vehicle breakdown" required>
                        <span>Vehicle breakdown</span>
                    </label>
                    
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Weather conditions" required>
                        <span>Unsafe weather conditions</span>
                    </label>
                    
                    <label class="failure-reason">
                        <input type="radio" name="failure_reason" value="Other" required>
                        <span>Other reason</span>
                    </label>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="modal-btn btn-cancel" onclick="hideFailureModal()">Cancel</button>
                    <button type="submit" class="modal-btn btn-confirm">Mark as Failed</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Auto-refresh functionality
    let refreshInterval;
    let isPageVisible = true;

    function startAutoRefresh() {
        refreshInterval = setInterval(() => {
            if (isPageVisible) {
                showRefreshIndicator();
                location.reload();
            }
        }, 30000); // Refresh every 30 seconds
    }

    function showRefreshIndicator() {
        const indicator = document.getElementById('refreshIndicator');
        indicator.style.display = 'block';
        setTimeout(() => {
            indicator.style.display = 'none';
        }, 2000);
    }

    // Handle page visibility changes
    document.addEventListener('visibilitychange', function() {
        isPageVisible = !document.hidden;
        
        if (isPageVisible) {
            startAutoRefresh();
        } else {
            clearInterval(refreshInterval);
        }
    });

    // Delivery failure modal functions
    function showFailureModal(orderId) {
        document.getElementById('failureOrderId').value = orderId;
        document.getElementById('failureModal').classList.add('active');
    }

    function hideFailureModal() {
        document.getElementById('failureModal').classList.remove('active');
        document.getElementById('failureForm').reset();
    }

    // Auto-hide flash messages
    document.addEventListener('DOMContentLoaded', function() {
        const flashMessage = document.getElementById('flashMessage');
        if (flashMessage) {
            setTimeout(() => {
                flashMessage.style.opacity = '0';
                setTimeout(() => flashMessage.remove(), 300);
            }, 5000);
        }

        // Start auto-refresh
        startAutoRefresh();

        // Add confirmation for critical actions
        const criticalButtons = document.querySelectorAll('.btn-complete, .btn-failed');
        criticalButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (this.classList.contains('btn-complete')) {
                    if (!confirm('Are you sure you want to mark this delivery as completed?')) {
                        e.preventDefault();
                    }
                }
            });
        });

        // Auto-update times
        updateElapsedTimes();
        setInterval(updateElapsedTimes, 60000); // Update every minute
    });

    function updateElapsedTimes() {
        const timeElements = document.querySelectorAll('.order-time');
        timeElements.forEach(element => {
            const timeText = element.textContent;
            const match = timeText.match(/(\d+) min ago/);
            if (match) {
                const minutes = parseInt(match[1]) + 1;
                element.innerHTML = element.innerHTML.replace(/\d+ min ago/, minutes + ' min ago');
            }
        });
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Press R to refresh manually
        if (e.key === 'r' || e.key === 'R') {
            if (!e.ctrlKey && !e.metaKey) {
                e.preventDefault();
                location.reload();
            }
        }
        
        // Press Escape to close modal
        if (e.key === 'Escape') {
            hideFailureModal();
        }
    });

    // Click outside modal to close
    document.getElementById('failureModal').addEventListener('click', function(e) {
        if (e.target === this) {
            hideFailureModal();
        }
    });

    // Form validation
    document.getElementById('failureForm').addEventListener('submit', function(e) {
        const selectedReason = document.querySelector('input[name="failure_reason"]:checked');
        if (!selectedReason) {
            e.preventDefault();
            alert('Please select a reason for the delivery failure.');
        }
    });

    // Add loading states to buttons
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.7';
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Processing...';
                
                // Reset after 5 seconds if form doesn't submit
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.style.opacity = '1';
                    submitBtn.textContent = originalText;
                }, 5000);
            }
        });
    });

    // Sound notification for new orders (if supported)
    function playNotificationSound() {
        try {
            // Simple beep sound using Web Audio API
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (e) {
            // Ignore errors if audio can't play
        }
    }

    function showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 90px;
            right: 20px;
            background: var(--success-color);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: var(--shadow-medium);
            z-index: 1002;
            animation: slideIn 0.3s ease;
            max-width: 300px;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        
        .delivery-btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none !important;
        }
        
        @media (prefers-reduced-motion: reduce) {
            .delivery-card,
            .stat-card,
            .delivery-btn {
                transition: none;
            }
            
            @keyframes slideIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
        }
    `;
    document.head.appendChild(style);
    </script>
</body>
</html>