<?php
// staff/kitchen/dashboard.php - Kitchen Staff Dashboard (FIXED VERSION)
require_once '../../includes/init.php';

// Check if user is logged in and is kitchen staff
if (!isLoggedIn() || !isEmployee()) {
    setFlashMessage('Please login with your staff credentials.', 'warning');
    redirect('../../login.php');
}

// Check if user has kitchen staff role
if (!hasRole('Kitchen Staff')) {
    setFlashMessage('Access denied. Kitchen staff only.', 'error');
    redirect('../../index.php');
}

// Get employee details
$employee_id = getCurrentUserId();
$employee_location = getUserLocation($conn);

// Get location details
$location_stmt = $conn->prepare("SELECT store_name, city FROM locations WHERE location_id = ?");
$location_stmt->bind_param("i", $employee_location);
$location_stmt->execute();
$location = $location_stmt->get_result()->fetch_assoc();

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'] ?? 0;
    $new_status = $_POST['new_status'] ?? 0;
    $notes = sanitizeInput($_POST['notes'] ?? '');
    
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlashMessage('Invalid form submission. Please try again.', 'error');
    } else {
        try {
            // FIX: Create variables for constants to pass by reference
            $pending_status = ORDER_STATUS_PENDING;
            $preparing_status = ORDER_STATUS_PREPARING;
            
            // Verify order belongs to this location and is valid for kitchen staff
            $verify_stmt = $conn->prepare("
                SELECT order_id, order_status_id, order_number 
                FROM orders 
                WHERE order_id = ? AND location_id = ? 
                AND order_status_id IN (?, ?)
            ");
            $verify_stmt->bind_param("iiii", $order_id, $employee_location, $pending_status, $preparing_status);
            $verify_stmt->execute();
            $order_check = $verify_stmt->get_result()->fetch_assoc();
            
            if (!$order_check) {
                setFlashMessage('Order not found or cannot be updated.', 'error');
            } else {
                // Validate status transition
                $current_status = $order_check['order_status_id'];
                $valid_transitions = [
                    ORDER_STATUS_PENDING => [ORDER_STATUS_PREPARING],
                    ORDER_STATUS_PREPARING => [ORDER_STATUS_READY]
                ];
                
                if (!isset($valid_transitions[$current_status]) || 
                    !in_array($new_status, $valid_transitions[$current_status])) {
                    setFlashMessage('Invalid status transition.', 'error');
                } else {
                    $conn->begin_transaction();
                    
                    // Update order status
                    $update_stmt = $conn->prepare("
                        UPDATE orders 
                        SET order_status_id = ?, updated_at = NOW() 
                        WHERE order_id = ?
                    ");
                    $update_stmt->bind_param("ii", $new_status, $order_id);
                    $update_stmt->execute();
                    
                    // Add to status history
                    $changed_by_type = 'employee';  // FIX: Variable instead of literal
                    $history_stmt = $conn->prepare("
                        INSERT INTO order_status_history 
                        (order_id, status_id, changed_by_type, changed_by_id, notes, created_at)
                        VALUES (?, ?, ?, ?, ?, NOW())
                    ");
                    $history_stmt->bind_param("iisis", $order_id, $new_status, $changed_by_type, $employee_id, $notes);
                    $history_stmt->execute();
                    
                    $conn->commit();
                    
                    $status_names = [
                        ORDER_STATUS_PREPARING => 'Preparing',
                        ORDER_STATUS_READY => 'Ready'
                    ];
                    
                    setFlashMessage(
                        'Order #' . $order_check['order_number'] . ' updated to ' . $status_names[$new_status], 
                        'success'
                    );
                }
            }
        } catch (Exception $e) {
            $conn->rollback();
            logError('Kitchen status update error: ' . $e->getMessage());
            setFlashMessage('Error updating order status. Please try again.', 'error');
        }
    }
}

// FIX: Create variables for constants to use in prepared statements
$pending_status = ORDER_STATUS_PENDING;
$preparing_status = ORDER_STATUS_PREPARING;

// Fetch orders for kitchen staff
$orders_sql = "
    SELECT 
        o.order_id,
        o.order_number,
        o.order_type,
        o.created_at,
        o.estimated_time,
        o.special_instructions,
        o.order_status_id,
        os.status_name,
        CONCAT(c.first_name, ' ', c.last_name) as customer_name,
        c.phone,
        TIMESTAMPDIFF(MINUTE, o.created_at, NOW()) as minutes_ago,
        CASE 
            WHEN o.estimated_time IS NOT NULL THEN
                TIMESTAMPDIFF(MINUTE, NOW(), o.estimated_time)
            ELSE NULL
        END as minutes_until_due
    FROM orders o
    JOIN customers c ON o.customer_id = c.customer_id
    JOIN order_statuses os ON o.order_status_id = os.status_id
    WHERE o.location_id = ?
    AND o.order_status_id IN (?, ?)
    ORDER BY 
        CASE o.order_status_id 
            WHEN ? THEN 1 
            WHEN ? THEN 2 
        END,
        o.created_at ASC
";

$stmt = $conn->prepare($orders_sql);
$stmt->bind_param("iiiii", 
    $employee_location, 
    $pending_status, 
    $preparing_status,
    $pending_status,
    $preparing_status
);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch order items for each order
foreach ($orders as &$order) {
    $items_stmt = $conn->prepare("
        SELECT 
            oi.*,
            CASE 
                WHEN oi.item_type = 'custom' THEN 'Custom Pizza'
                ELSE oi.item_name
            END as display_name
        FROM order_items oi
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id
    ");
    $items_stmt->bind_param("i", $order['order_id']);
    $items_stmt->execute();
    $order['items'] = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Get custom pizza details for custom items
    foreach ($order['items'] as &$item) {
        if ($item['item_type'] === 'custom') {
            $custom_stmt = $conn->prepare("
                SELECT 
                    cs.size_name,
                    ct.crust_name,
                    s.sauce_name,
                    ch.cheese_name,
                    cp.cheese_amount,
                    GROUP_CONCAT(i.ingredient_name SEPARATOR ', ') as toppings
                FROM custom_pizzas cp
                JOIN crust_sizes cs ON cp.size_id = cs.size_id
                JOIN crust_types ct ON cp.crust_type_id = ct.crust_type_id
                LEFT JOIN sauces s ON cp.sauce_id = s.sauce_id
                LEFT JOIN cheese_types ch ON cp.cheese_id = ch.cheese_id
                LEFT JOIN custom_pizza_toppings cpt ON cp.custom_pizza_id = cpt.custom_pizza_id
                LEFT JOIN ingredients i ON cpt.ingredient_id = i.ingredient_id
                WHERE cp.order_item_id = ?
                GROUP BY cp.custom_pizza_id
            ");
            $custom_stmt->bind_param("i", $item['order_item_id']);
            $custom_stmt->execute();
            $custom_details = $custom_stmt->get_result()->fetch_assoc();
            
            if ($custom_details) {
                $item['custom_details'] = $custom_details;
            }
        }
    }
}

// Generate CSRF token
$csrf_token = generateCSRFToken();

// Include header
$current_page = 'kitchen-dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kitchen Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../../assets/css/main.css">
    <style>
        :root {
            --primary-color: #d63031;
            --primary-dark: #c0392b;
            --text-dark: #2d3436;
            --text-light: #ffffff;
            --gray-light: #f5f6fa;
            --gray-medium: #dfe6e9;
            --gray-dark: #636e72;
            --success-color: #00b894;
            --warning-color: #fdcb6e;
            --urgent-color: #ff7675;
            --preparing-color: #74b9ff;
            --border-radius: 12px;
            --shadow-light: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-medium: 0 4px 20px rgba(0,0,0,0.15);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: var(--gray-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .kitchen-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: var(--text-light);
            padding: 20px 0;
            box-shadow: var(--shadow-medium);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-title h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .location-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 100px auto 50px;
            padding: 0 20px;
        }

        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: var(--gray-dark);
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .pending-orders .stat-number { color: var(--warning-color); }
        .preparing-orders .stat-number { color: var(--preparing-color); }
        .avg-time .stat-number { color: var(--success-color); }
        .urgent-orders .stat-number { color: var(--urgent-color); }

        .orders-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .orders-column {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .column-header {
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            font-weight: 700;
            font-size: 1.2rem;
        }

        .pending-header {
            background: linear-gradient(135deg, var(--warning-color) 0%, #e17055 100%);
            color: white;
        }

        .preparing-header {
            background: linear-gradient(135deg, var(--preparing-color) 0%, #0984e3 100%);
            color: white;
        }

        .order-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            overflow: hidden;
            transition: var(--transition);
            border-left: 5px solid var(--gray-medium);
        }

        .order-card.pending {
            border-left-color: var(--warning-color);
        }

        .order-card.preparing {
            border-left-color: var(--preparing-color);
        }

        .order-card.urgent {
            border-left-color: var(--urgent-color);
            animation: urgentPulse 2s infinite;
        }

        @keyframes urgentPulse {
            0%, 100% { box-shadow: var(--shadow-light); }
            50% { box-shadow: 0 4px 20px rgba(255, 118, 117, 0.3); }
        }

        .order-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-medium);
        }

        .order-number {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .order-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-dark);
        }

        .order-time {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .time-urgent {
            color: var(--urgent-color);
            font-weight: 600;
        }

        .order-type {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .type-delivery {
            background: #e3f2fd;
            color: #1976d2;
        }

        .type-pickup {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .order-items {
            padding: 20px;
        }

        .item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--gray-light);
        }

        .item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .item-details {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .item-customizations {
            font-size: 0.85rem;
            color: var(--gray-dark);
            line-height: 1.4;
        }

        .item-quantity {
            background: var(--primary-color);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .special-instructions {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 12px;
            border-radius: 6px;
            margin-top: 15px;
        }

        .special-instructions h5 {
            color: #856404;
            margin-bottom: 5px;
            font-size: 0.9rem;
        }

        .special-instructions p {
            color: #856404;
            font-size: 0.85rem;
            margin: 0;
        }

        .order-actions {
            padding: 20px;
            background: var(--gray-light);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .status-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
        }

        .btn-start {
            background: var(--preparing-color);
            color: white;
        }

        .btn-start:hover {
            background: #0984e3;
            transform: translateY(-1px);
        }

        .btn-ready {
            background: var(--success-color);
            color: white;
        }

        .btn-ready:hover {
            background: #00a085;
            transform: translateY(-1px);
        }

        .timer-display {
            text-align: center;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .timer-prep {
            color: var(--preparing-color);
        }

        .timer-due {
            color: var(--urgent-color);
        }

        .notes-input {
            width: 100%;
            padding: 8px;
            border: 1px solid var(--gray-medium);
            border-radius: 4px;
            font-size: 0.85rem;
            margin-bottom: 10px;
            resize: vertical;
            min-height: 60px;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-dark);
        }

        .empty-state h3 {
            margin-bottom: 10px;
        }

        .refresh-indicator {
            position: fixed;
            top: 90px;
            right: 20px;
            background: var(--success-color);
            color: white;
            padding: 10px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            box-shadow: var(--shadow-light);
            z-index: 999;
            display: none;
        }

        .refresh-indicator.active {
            display: block;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        /* Flash messages */
        .flash-message {
            position: fixed;
            top: 90px;
            left: 50%;
            transform: translateX(-50%);
            padding: 15px 25px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 1001;
            box-shadow: var(--shadow-medium);
            animation: slideDown 0.3s ease;
        }

        .flash-success {
            background: var(--success-color);
            color: white;
        }

        .flash-error {
            background: var(--urgent-color);
            color: white;
        }

        @keyframes slideDown {
            from { transform: translate(-50%, -100%); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .orders-section {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                margin-top: 80px;
                padding: 0 15px;
            }
            
            .header-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
            
            .header-title h1 {
                font-size: 1.5rem;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .order-meta {
                flex-direction: column;
                gap: 5px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Kitchen Header -->
    <div class="kitchen-header">
        <div class="header-content">
            <div class="header-title">
                <h1>👨‍🍳 Kitchen Dashboard</h1>
                <div class="location-badge">
                    <?php echo e($location['store_name']); ?> - <?php echo e($location['city']); ?>
                </div>
            </div>
            
            <div class="header-actions">
                <div class="user-info">
                    Welcome, <?php echo e(getCurrentUserName()); ?>
                </div>
                <a href="../../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if ($message = getFlashMessage('success')): ?>
    <div class="flash-message flash-success"><?php echo e($message); ?></div>
    <?php endif; ?>

    <?php if ($message = getFlashMessage('error')): ?>
    <div class="flash-message flash-error"><?php echo e($message); ?></div>
    <?php endif; ?>

    <!-- Refresh Indicator -->
    <div class="refresh-indicator" id="refreshIndicator">
        🔄 Checking for new orders...
    </div>

    <div class="dashboard-container">
        <!-- Dashboard Stats -->
        <div class="dashboard-stats">
            <?php
            $pending_count = 0;
            $preparing_count = 0;
            $urgent_count = 0;
            $total_prep_time = 0;
            
            foreach ($orders as $order) {
                if ($order['order_status_id'] == ORDER_STATUS_PENDING) {
                    $pending_count++;
                }
                if ($order['order_status_id'] == ORDER_STATUS_PREPARING) {
                    $preparing_count++;
                }
                if ($order['minutes_ago'] > ESTIMATED_PREP_TIME) {
                    $urgent_count++;
                }
                $total_prep_time += $order['minutes_ago'];
            }
            
            $avg_prep_time = count($orders) > 0 ? round($total_prep_time / count($orders)) : 0;
            ?>
            
            <div class="stat-card pending-orders">
                <div class="stat-icon">📋</div>
                <div class="stat-number"><?php echo $pending_count; ?></div>
                <div class="stat-label">Pending Orders</div>
            </div>
            
            <div class="stat-card preparing-orders">
                <div class="stat-icon">👨‍🍳</div>
                <div class="stat-number"><?php echo $preparing_count; ?></div>
                <div class="stat-label">Preparing</div>
            </div>
            
            <div class="stat-card avg-time">
                <div class="stat-icon">⏱️</div>
                <div class="stat-number"><?php echo $avg_prep_time; ?></div>
                <div class="stat-label">Avg Time (min)</div>
            </div>
            
            <div class="stat-card urgent-orders">
                <div class="stat-icon">🚨</div>
                <div class="stat-number"><?php echo $urgent_count; ?></div>
                <div class="stat-label">Urgent Orders</div>
            </div>
        </div>

        <!-- Orders Section -->
        <div class="orders-section">
            <!-- Pending Orders Column -->
            <div class="orders-column">
                <div class="column-header pending-header">
                    📋 Pending Orders (<?php echo $pending_count; ?>)
                </div>
                
                <?php 
                $pending_orders = array_filter($orders, function($order) {
                    return $order['order_status_id'] == ORDER_STATUS_PENDING;
                });
                ?>
                
                <?php if (empty($pending_orders)): ?>
                <div class="empty-state">
                    <h3>🎉 All caught up!</h3>
                    <p>No pending orders at the moment.</p>
                </div>
                <?php else: ?>
                    <?php foreach ($pending_orders as $order): ?>
                    <?php 
                    $is_urgent = $order['minutes_ago'] > ESTIMATED_PREP_TIME;
                    $card_class = $is_urgent ? 'order-card pending urgent' : 'order-card pending';
                    ?>
                    
                    <div class="<?php echo $card_class; ?>" data-order-id="<?php echo $order['order_id']; ?>">
                        <div class="order-header">
                            <div class="order-number">#<?php echo e($order['order_number']); ?></div>
                            <div class="order-meta">
                                <div class="order-time <?php echo $is_urgent ? 'time-urgent' : ''; ?>">
                                    ⏰ <?php echo $order['minutes_ago']; ?> min ago
                                    <?php if ($is_urgent): ?>
                                        <strong>(URGENT!)</strong>
                                    <?php endif; ?>
                                </div>
                                <div class="order-type <?php echo $order['order_type'] === 'delivery' ? 'type-delivery' : 'type-pickup'; ?>">
                                    <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="order-items">
                            <?php foreach ($order['items'] as $item): ?>
                            <div class="item">
                                <div class="item-details">
                                    <div class="item-name"><?php echo e($item['display_name']); ?></div>
                                    <?php if ($item['item_type'] === 'custom' && isset($item['custom_details'])): ?>
                                    <div class="item-customizations">
                                        <strong>Size:</strong> <?php echo e($item['custom_details']['size_name']); ?><br>
                                        <strong>Crust:</strong> <?php echo e($item['custom_details']['crust_name']); ?><br>
                                        <?php if ($item['custom_details']['sauce_name']): ?>
                                        <strong>Sauce:</strong> <?php echo e($item['custom_details']['sauce_name']); ?><br>
                                        <?php endif; ?>
                                        <?php if ($item['custom_details']['cheese_amount'] !== 'none'): ?>
                                        <strong>Cheese:</strong> 
                                        <?php echo e($item['custom_details']['cheese_name'] ?? 'Regular'); ?>
                                        <?php if ($item['custom_details']['cheese_amount'] === 'extra'): ?> (Extra)<?php endif; ?><br>
                                        <?php endif; ?>
                                        <?php if ($item['custom_details']['toppings']): ?>
                                        <strong>Toppings:</strong> <?php echo e($item['custom_details']['toppings']); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-quantity"><?php echo $item['quantity']; ?></div>
                            </div>
                            <?php endforeach; ?>
                            
                            <?php if (!empty($order['special_instructions'])): ?>
                            <div class="special-instructions">
                                <h5>📝 Special Instructions:</h5>
                                <p><?php echo e($order['special_instructions']); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="order-actions">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <input type="hidden" name="new_status" value="<?php echo ORDER_STATUS_PREPARING; ?>">
                                
                                <textarea name="notes" class="notes-input" placeholder="Add preparation notes (optional)..."></textarea>
                                <button type="submit" class="status-btn btn-start">
                                    🔥 Start Preparing
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Preparing Orders Column -->
            <div class="orders-column">
                <div class="column-header preparing-header">
                    👨‍🍳 Preparing Orders (<?php echo $preparing_count; ?>)
                </div>
                
                <?php 
                $preparing_orders = array_filter($orders, function($order) {
                    return $order['order_status_id'] == ORDER_STATUS_PREPARING;
                });
                ?>
                
                <?php if (empty($preparing_orders)): ?>
                <div class="empty-state">
                    <h3>🍕 Ready to cook!</h3>
                    <p>No orders currently being prepared.</p>
                </div>
                <?php else: ?>
                    <?php foreach ($preparing_orders as $order): ?>
                    <?php 
                    $is_urgent = $order['minutes_ago'] > ESTIMATED_PREP_TIME;
                    $card_class = $is_urgent ? 'order-card preparing urgent' : 'order-card preparing';
                    ?>
                    
                    <div class="<?php echo $card_class; ?>" data-order-id="<?php echo $order['order_id']; ?>">
                        <div class="order-header">
                            <div class="order-number">#<?php echo e($order['order_number']); ?></div>
                            <div class="order-meta">
                                <div class="order-time <?php echo $is_urgent ? 'time-urgent' : ''; ?>">
                                    ⏰ <?php echo $order['minutes_ago']; ?> min ago
                                    <?php if ($is_urgent): ?>
                                        <strong>(URGENT!)</strong>
                                    <?php endif; ?>
                                </div>
                                <div class="order-type <?php echo $order['order_type'] === 'delivery' ? 'type-delivery' : 'type-pickup'; ?>">
                                    <?php echo $order['order_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Pickup'; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="order-items">
                            <?php if ($order['minutes_until_due'] !== null): ?>
                            <div class="timer-display">
                                <?php if ($order['minutes_until_due'] > 0): ?>
                                    <span class="timer-prep">⏳ Due in <?php echo $order['minutes_until_due']; ?> minutes</span>
                                <?php else: ?>
                                    <span class="timer-due">🚨 OVERDUE by <?php echo abs($order['minutes_until_due']); ?> minutes!</span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php foreach ($order['items'] as $item): ?>
                            <div class="item">
                                <div class="item-details">
                                    <div class="item-name"><?php echo e($item['display_name']); ?></div>
                                    <?php if ($item['item_type'] === 'custom' && isset($item['custom_details'])): ?>
                                    <div class="item-customizations">
                                        <strong>Size:</strong> <?php echo e($item['custom_details']['size_name']); ?><br>
                                        <strong>Crust:</strong> <?php echo e($item['custom_details']['crust_name']); ?><br>
                                        <?php if ($item['custom_details']['sauce_name']): ?>
                                        <strong>Sauce:</strong> <?php echo e($item['custom_details']['sauce_name']); ?><br>
                                        <?php endif; ?>
                                        <?php if ($item['custom_details']['cheese_amount'] !== 'none'): ?>
                                        <strong>Cheese:</strong> 
                                        <?php echo e($item['custom_details']['cheese_name'] ?? 'Regular'); ?>
                                        <?php if ($item['custom_details']['cheese_amount'] === 'extra'): ?> (Extra)<?php endif; ?><br>
                                        <?php endif; ?>
                                        <?php if ($item['custom_details']['toppings']): ?>
                                        <strong>Toppings:</strong> <?php echo e($item['custom_details']['toppings']); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="item-quantity"><?php echo $item['quantity']; ?></div>
                            </div>
                            <?php endforeach; ?>
                            
                            <?php if (!empty($order['special_instructions'])): ?>
                            <div class="special-instructions">
                                <h5>📝 Special Instructions:</h5>
                                <p><?php echo e($order['special_instructions']); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="order-actions">
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <input type="hidden" name="new_status" value="<?php echo ORDER_STATUS_READY; ?>">
                                
                                <textarea name="notes" class="notes-input" placeholder="Order completion notes (optional)..."></textarea>
                                <button type="submit" class="status-btn btn-ready">
                                    ✅ Mark Ready
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-refresh every 30 seconds
            let refreshInterval;
            
            function startAutoRefresh() {
                refreshInterval = setInterval(function() {
                    showRefreshIndicator();
                    
                    // Check if any forms are being filled out
                    const activeElement = document.activeElement;
                    const isFormActive = activeElement && (
                        activeElement.tagName === 'TEXTAREA' || 
                        activeElement.tagName === 'INPUT' ||
                        activeElement.tagName === 'BUTTON'
                    );
                    
                    if (!isFormActive) {
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    }
                }, 30000); // 30 seconds
            }
            
            function showRefreshIndicator() {
                const indicator = document.getElementById('refreshIndicator');
                indicator.classList.add('active');
                
                setTimeout(function() {
                    indicator.classList.remove('active');
                }, 3000);
            }
            
            // Start auto-refresh
            startAutoRefresh();
            
            // Pause auto-refresh when page is not visible
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    clearInterval(refreshInterval);
                } else {
                    startAutoRefresh();
                }
            });
            
            // Manual refresh with keyboard shortcut
            document.addEventListener('keydown', function(e) {
                if (e.key === 'r' && e.ctrlKey) {
                    e.preventDefault();
                    showRefreshIndicator();
                    setTimeout(() => window.location.reload(), 500);
                }
                
                // Quick action shortcuts
                if (e.key === '1' && e.ctrlKey) {
                    // Start preparing first pending order
                    e.preventDefault();
                    const firstPendingBtn = document.querySelector('.pending .btn-start');
                    if (firstPendingBtn) {
                        firstPendingBtn.click();
                    }
                }
                
                if (e.key === '2' && e.ctrlKey) {
                    // Mark first preparing order as ready
                    e.preventDefault();
                    const firstReadyBtn = document.querySelector('.preparing .btn-ready');
                    if (firstReadyBtn) {
                        firstReadyBtn.click();
                    }
                }
            });
            
            // Form submission handling
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const button = this.querySelector('button[type="submit"]');
                    const originalText = button.textContent;
                    
                    // Show loading state
                    button.disabled = true;
                    button.style.opacity = '0.7';
                    button.textContent = 'Updating...';
                    
                    // If form fails to submit (validation), reset button
                    setTimeout(() => {
                        button.disabled = false;
                        button.style.opacity = '1';
                        button.textContent = originalText;
                    }, 5000);
                });
            });
            
            // Auto-hide flash messages
            const flashMessages = document.querySelectorAll('.flash-message');
            flashMessages.forEach(message => {
                setTimeout(() => {
                    message.style.opacity = '0';
                    setTimeout(() => message.remove(), 300);
                }, 4000);
            });
            
            // Sound notification for urgent orders (optional)
            const urgentOrders = document.querySelectorAll('.urgent');
            if (urgentOrders.length > 0) {
                console.log(`${urgentOrders.length} urgent orders need attention!`);
            }
            
            // Highlight overdue orders
            setInterval(() => {
                document.querySelectorAll('.timer-due').forEach(timer => {
                    timer.style.animation = 'none';
                    setTimeout(() => {
                        timer.style.animation = 'urgentPulse 1s infinite';
                    }, 10);
                });
            }, 5000);
        });
        
        // Global functions for potential external use
        window.KitchenDashboard = {
            refreshNow: function() {
                document.getElementById('refreshIndicator').classList.add('active');
                setTimeout(() => window.location.reload(), 500);
            },
            
            getOrderCount: function() {
                return {
                    pending: <?php echo $pending_count; ?>,
                    preparing: <?php echo $preparing_count; ?>,
                    urgent: <?php echo $urgent_count; ?>
                };
            }
        };
    </script>
</body>
</html>