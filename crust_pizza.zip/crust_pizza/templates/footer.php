 <!-- Footer -->
    <footer class="footer" id="contact" style="margin-top: 20px;">
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-section">
                    <h3>Crust Pizza</h3>
                    <p>Serving gourmet pizza since 2001. Fresh ingredients, innovative flavors, and exceptional service delivered right to your door.</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <p><a href="menu.php">Order Online</a></p>
                    <p><a href="#">Store Locations</a></p>
                    <p><a href="#">Careers</a></p>
                </div>
                <div class="footer-section">
                    <h3>Customer Service</h3>
                    <p><a href="#">Contact Us</a></p>
                    <p><a href="#">FAQ</a></p>
                    <p><a href="order-tracking.php">Track Your Order</a></p>
                    <p><a href="#">Feedback</a></p>
                </div>
                <div class="footer-section">
                    <h3>Connect With Us</h3>
                    <p>📞 1-800-CRUST-PIZZA</p>
                    <p>📧 hello@crustpizza.com</p>
                    <p>📍 Find your nearest location</p>
                    <p>🕒 Mon-Sun: 4AM - 11PM</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Crust Pizza. All rights reserved. | Privacy Policy | Terms of Service</p>
                <p>&copy; Sshiva Bhandari, Prajwal Rana, Sandip Limbu, Mohammad Ziyad Khan</p>

            </div>
        </div>
    </footer>
