<?php
// templates/header.php - Updated header template
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include necessary files if not already included
if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}
if (!function_exists('isLoggedIn')) {
    require_once __DIR__ . '/../includes/auth.php';
}

$is_logged_in = isLoggedIn();
$username = getCurrentUserName();
$user_type = getCurrentUserType();

// Get cart count if customer is logged in
$cart_count = 0;
if ($is_logged_in && $user_type === USER_TYPE_CUSTOMER) {
    if (isset($_SESSION[SESSION_CART]) && is_array($_SESSION[SESSION_CART])) {
        $cart_count = array_sum(array_column($_SESSION[SESSION_CART], 'quantity'));
    }
}

// Determine active page
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Header -->
<header class="header" id="header">
    <div class="header-content">
        <a href="/" class="logo">
            🍕 <?php echo SITE_NAME; ?>
        </a>
        
        <nav>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a class="nav-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $current_page == 'menu.php' ? 'active' : ''; ?>" href="menu.php">Menu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $current_page == 'builder.php' ? 'active' : ''; ?>" href="builder.php">Build Pizza</a>
                </li>
                
                
                <?php if ($is_logged_in): ?>
                    <?php if ($user_type === USER_TYPE_CUSTOMER): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'cart.php' ? 'active' : ''; ?>" href="cart.php">
                            Cart <?php if ($cart_count > 0): ?><span class="cart-badge"><?php echo $cart_count; ?></span><?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo strpos($current_page, 'orders') !== false ? 'active' : ''; ?>" href="customer/orders.php">My Orders</a>
                    </li>
                    <?php elseif ($user_type === USER_TYPE_EMPLOYEE): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../staff/<?php echo strtolower(str_replace(' ', '-', $_SESSION['role_name'] ?? '')); ?>/dashboard.php">Dashboard</a>
                    </li>
                    <?php elseif ($user_type === USER_TYPE_ADMIN): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/dashboard.php">Admin Panel</a>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </nav>
        
        <div class="auth-buttons" id="auth-buttons">
            <?php if ($is_logged_in): ?>
                <a class="nav-link disabled" href="customer/profile.php">Hi, <?php echo htmlspecialchars($username); ?></a>
                <a class="btn btn-outline" href="logout.php">Logout</a>
            <?php else: ?>
                <a class="btn btn-outline <?php echo $current_page == 'login.php' ? 'active' : ''; ?>" href="login.php">Login</a>
                <a class="btn btn-primary <?php echo $current_page == 'signup.php' ? 'active' : ''; ?>" href="signup.php">Sign Up</a>
            <?php endif; ?>
        </div>
        
        <!-- Mobile menu toggle -->
        <button class="mobile-menu-toggle" id="mobileMenuToggle">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</header>

<style>
/* Header Styles */
.header {
    position: sticky;
    top: 0;
    z-index: 100;
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(10px);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.cart-badge {
    background: #d63031;
    color: white;
    border-radius: 10px;
    padding: 2px 6px;
    font-size: 0.75rem;
    margin-left: 5px;
    font-weight: 600;
}

.nav-link.disabled {
    color: #636e72;
    cursor: default;
    margin-right: 15px;
}

/* Mobile menu toggle */
.mobile-menu-toggle {
    display: none;
    flex-direction: column;
    justify-content: space-around;
    width: 30px;
    height: 25px;
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 0;
}

.mobile-menu-toggle span {
    width: 100%;
    height: 3px;
    background: #2d3436;
    border-radius: 2px;
    transition: all 0.3s ease;
}

.mobile-menu-toggle.active span:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}

.mobile-menu-toggle.active span:nth-child(2) {
    opacity: 0;
}

.mobile-menu-toggle.active span:nth-child(3) {
    transform: rotate(-45deg) translate(7px, -6px);
}

/* Responsive */
@media (max-width: 768px) {
    .mobile-menu-toggle {
        display: flex;
    }
    
    .nav-menu {
        position: fixed;
        left: -100%;
        top: 70px;
        flex-direction: column;
        background-color: white;
        width: 100%;
        text-align: center;
        transition: 0.3s;
        box-shadow: 0 10px 27px rgba(0, 0, 0, 0.05);
        padding: 20px 0;
    }
    
    .nav-menu.active {
        left: 0;
    }
    
    .nav-item {
        margin: 15px 0;
    }
    
    .auth-buttons {
        margin-top: 20px;
    }
}
</style>

<script>
// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
});
</script>